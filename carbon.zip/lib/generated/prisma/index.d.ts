
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model Customers
 * 
 */
export type Customers = $Result.DefaultSelection<Prisma.$CustomersPayload>
/**
 * Model HistoryCalculator
 * 
 */
export type HistoryCalculator = $Result.DefaultSelection<Prisma.$HistoryCalculatorPayload>
/**
 * Model Organization
 * 
 */
export type Organization = $Result.DefaultSelection<Prisma.$OrganizationPayload>
/**
 * Model CarBrands
 * 
 */
export type CarBrands = $Result.DefaultSelection<Prisma.$CarBrandsPayload>
/**
 * Model CarModels
 * 
 */
export type CarModels = $Result.DefaultSelection<Prisma.$CarModelsPayload>
/**
 * Model MotorcycleBrands
 * 
 */
export type MotorcycleBrands = $Result.DefaultSelection<Prisma.$MotorcycleBrandsPayload>
/**
 * Model MotorcycleModels
 * 
 */
export type MotorcycleModels = $Result.DefaultSelection<Prisma.$MotorcycleModelsPayload>
/**
 * Model PublicTransportTypes
 * 
 */
export type PublicTransportTypes = $Result.DefaultSelection<Prisma.$PublicTransportTypesPayload>
/**
 * Model AirBrands
 * 
 */
export type AirBrands = $Result.DefaultSelection<Prisma.$AirBrandsPayload>
/**
 * Model AirModels
 * 
 */
export type AirModels = $Result.DefaultSelection<Prisma.$AirModelsPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const AirOilTypes: {
  JET: 'JET',
  SAF: 'SAF',
  AVGAS_100: 'AVGAS_100'
};

export type AirOilTypes = (typeof AirOilTypes)[keyof typeof AirOilTypes]


export const CarOilTypes: {
  DIESEL_91: 'DIESEL_91',
  DIESEL_95: 'DIESEL_95',
  DIESEL_97: 'DIESEL_97',
  ALPHA_X: 'ALPHA_X',
  E20: 'E20',
  E85: 'E85',
  B5PLUS: 'B5PLUS'
};

export type CarOilTypes = (typeof CarOilTypes)[keyof typeof CarOilTypes]


export const MotorBikeOilTypes: {
  GASOHOL_95: 'GASOHOL_95',
  GASOHOL_91: 'GASOHOL_91',
  GASOHOL_97: 'GASOHOL_97',
  GASOHOL_E20: 'GASOHOL_E20',
  GASOHOL_E85: 'GASOHOL_E85'
};

export type MotorBikeOilTypes = (typeof MotorBikeOilTypes)[keyof typeof MotorBikeOilTypes]

}

export type AirOilTypes = $Enums.AirOilTypes

export const AirOilTypes: typeof $Enums.AirOilTypes

export type CarOilTypes = $Enums.CarOilTypes

export const CarOilTypes: typeof $Enums.CarOilTypes

export type MotorBikeOilTypes = $Enums.MotorBikeOilTypes

export const MotorBikeOilTypes: typeof $Enums.MotorBikeOilTypes

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Customers
 * const customers = await prisma.customers.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Customers
   * const customers = await prisma.customers.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.customers`: Exposes CRUD operations for the **Customers** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Customers
    * const customers = await prisma.customers.findMany()
    * ```
    */
  get customers(): Prisma.CustomersDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.historyCalculator`: Exposes CRUD operations for the **HistoryCalculator** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more HistoryCalculators
    * const historyCalculators = await prisma.historyCalculator.findMany()
    * ```
    */
  get historyCalculator(): Prisma.HistoryCalculatorDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.organization`: Exposes CRUD operations for the **Organization** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Organizations
    * const organizations = await prisma.organization.findMany()
    * ```
    */
  get organization(): Prisma.OrganizationDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.carBrands`: Exposes CRUD operations for the **CarBrands** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more CarBrands
    * const carBrands = await prisma.carBrands.findMany()
    * ```
    */
  get carBrands(): Prisma.CarBrandsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.carModels`: Exposes CRUD operations for the **CarModels** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more CarModels
    * const carModels = await prisma.carModels.findMany()
    * ```
    */
  get carModels(): Prisma.CarModelsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.motorcycleBrands`: Exposes CRUD operations for the **MotorcycleBrands** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more MotorcycleBrands
    * const motorcycleBrands = await prisma.motorcycleBrands.findMany()
    * ```
    */
  get motorcycleBrands(): Prisma.MotorcycleBrandsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.motorcycleModels`: Exposes CRUD operations for the **MotorcycleModels** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more MotorcycleModels
    * const motorcycleModels = await prisma.motorcycleModels.findMany()
    * ```
    */
  get motorcycleModels(): Prisma.MotorcycleModelsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.publicTransportTypes`: Exposes CRUD operations for the **PublicTransportTypes** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PublicTransportTypes
    * const publicTransportTypes = await prisma.publicTransportTypes.findMany()
    * ```
    */
  get publicTransportTypes(): Prisma.PublicTransportTypesDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.airBrands`: Exposes CRUD operations for the **AirBrands** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AirBrands
    * const airBrands = await prisma.airBrands.findMany()
    * ```
    */
  get airBrands(): Prisma.AirBrandsDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.airModels`: Exposes CRUD operations for the **AirModels** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AirModels
    * const airModels = await prisma.airModels.findMany()
    * ```
    */
  get airModels(): Prisma.AirModelsDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.8.2
   * Query Engine version: 2060c79ba17c6bb9f5823312b6f6b7f4a845738e
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    Customers: 'Customers',
    HistoryCalculator: 'HistoryCalculator',
    Organization: 'Organization',
    CarBrands: 'CarBrands',
    CarModels: 'CarModels',
    MotorcycleBrands: 'MotorcycleBrands',
    MotorcycleModels: 'MotorcycleModels',
    PublicTransportTypes: 'PublicTransportTypes',
    AirBrands: 'AirBrands',
    AirModels: 'AirModels'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "customers" | "historyCalculator" | "organization" | "carBrands" | "carModels" | "motorcycleBrands" | "motorcycleModels" | "publicTransportTypes" | "airBrands" | "airModels"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      Customers: {
        payload: Prisma.$CustomersPayload<ExtArgs>
        fields: Prisma.CustomersFieldRefs
        operations: {
          findUnique: {
            args: Prisma.CustomersFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CustomersPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.CustomersFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CustomersPayload>
          }
          findFirst: {
            args: Prisma.CustomersFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CustomersPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.CustomersFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CustomersPayload>
          }
          findMany: {
            args: Prisma.CustomersFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CustomersPayload>[]
          }
          create: {
            args: Prisma.CustomersCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CustomersPayload>
          }
          createMany: {
            args: Prisma.CustomersCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.CustomersCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CustomersPayload>[]
          }
          delete: {
            args: Prisma.CustomersDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CustomersPayload>
          }
          update: {
            args: Prisma.CustomersUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CustomersPayload>
          }
          deleteMany: {
            args: Prisma.CustomersDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.CustomersUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.CustomersUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CustomersPayload>[]
          }
          upsert: {
            args: Prisma.CustomersUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CustomersPayload>
          }
          aggregate: {
            args: Prisma.CustomersAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCustomers>
          }
          groupBy: {
            args: Prisma.CustomersGroupByArgs<ExtArgs>
            result: $Utils.Optional<CustomersGroupByOutputType>[]
          }
          count: {
            args: Prisma.CustomersCountArgs<ExtArgs>
            result: $Utils.Optional<CustomersCountAggregateOutputType> | number
          }
        }
      }
      HistoryCalculator: {
        payload: Prisma.$HistoryCalculatorPayload<ExtArgs>
        fields: Prisma.HistoryCalculatorFieldRefs
        operations: {
          findUnique: {
            args: Prisma.HistoryCalculatorFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryCalculatorPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.HistoryCalculatorFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryCalculatorPayload>
          }
          findFirst: {
            args: Prisma.HistoryCalculatorFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryCalculatorPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.HistoryCalculatorFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryCalculatorPayload>
          }
          findMany: {
            args: Prisma.HistoryCalculatorFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryCalculatorPayload>[]
          }
          create: {
            args: Prisma.HistoryCalculatorCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryCalculatorPayload>
          }
          createMany: {
            args: Prisma.HistoryCalculatorCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.HistoryCalculatorCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryCalculatorPayload>[]
          }
          delete: {
            args: Prisma.HistoryCalculatorDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryCalculatorPayload>
          }
          update: {
            args: Prisma.HistoryCalculatorUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryCalculatorPayload>
          }
          deleteMany: {
            args: Prisma.HistoryCalculatorDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.HistoryCalculatorUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.HistoryCalculatorUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryCalculatorPayload>[]
          }
          upsert: {
            args: Prisma.HistoryCalculatorUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$HistoryCalculatorPayload>
          }
          aggregate: {
            args: Prisma.HistoryCalculatorAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateHistoryCalculator>
          }
          groupBy: {
            args: Prisma.HistoryCalculatorGroupByArgs<ExtArgs>
            result: $Utils.Optional<HistoryCalculatorGroupByOutputType>[]
          }
          count: {
            args: Prisma.HistoryCalculatorCountArgs<ExtArgs>
            result: $Utils.Optional<HistoryCalculatorCountAggregateOutputType> | number
          }
        }
      }
      Organization: {
        payload: Prisma.$OrganizationPayload<ExtArgs>
        fields: Prisma.OrganizationFieldRefs
        operations: {
          findUnique: {
            args: Prisma.OrganizationFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrganizationPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.OrganizationFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrganizationPayload>
          }
          findFirst: {
            args: Prisma.OrganizationFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrganizationPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.OrganizationFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrganizationPayload>
          }
          findMany: {
            args: Prisma.OrganizationFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrganizationPayload>[]
          }
          create: {
            args: Prisma.OrganizationCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrganizationPayload>
          }
          createMany: {
            args: Prisma.OrganizationCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.OrganizationCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrganizationPayload>[]
          }
          delete: {
            args: Prisma.OrganizationDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrganizationPayload>
          }
          update: {
            args: Prisma.OrganizationUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrganizationPayload>
          }
          deleteMany: {
            args: Prisma.OrganizationDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.OrganizationUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.OrganizationUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrganizationPayload>[]
          }
          upsert: {
            args: Prisma.OrganizationUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$OrganizationPayload>
          }
          aggregate: {
            args: Prisma.OrganizationAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateOrganization>
          }
          groupBy: {
            args: Prisma.OrganizationGroupByArgs<ExtArgs>
            result: $Utils.Optional<OrganizationGroupByOutputType>[]
          }
          count: {
            args: Prisma.OrganizationCountArgs<ExtArgs>
            result: $Utils.Optional<OrganizationCountAggregateOutputType> | number
          }
        }
      }
      CarBrands: {
        payload: Prisma.$CarBrandsPayload<ExtArgs>
        fields: Prisma.CarBrandsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.CarBrandsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarBrandsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.CarBrandsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarBrandsPayload>
          }
          findFirst: {
            args: Prisma.CarBrandsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarBrandsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.CarBrandsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarBrandsPayload>
          }
          findMany: {
            args: Prisma.CarBrandsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarBrandsPayload>[]
          }
          create: {
            args: Prisma.CarBrandsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarBrandsPayload>
          }
          createMany: {
            args: Prisma.CarBrandsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.CarBrandsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarBrandsPayload>[]
          }
          delete: {
            args: Prisma.CarBrandsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarBrandsPayload>
          }
          update: {
            args: Prisma.CarBrandsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarBrandsPayload>
          }
          deleteMany: {
            args: Prisma.CarBrandsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.CarBrandsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.CarBrandsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarBrandsPayload>[]
          }
          upsert: {
            args: Prisma.CarBrandsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarBrandsPayload>
          }
          aggregate: {
            args: Prisma.CarBrandsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCarBrands>
          }
          groupBy: {
            args: Prisma.CarBrandsGroupByArgs<ExtArgs>
            result: $Utils.Optional<CarBrandsGroupByOutputType>[]
          }
          count: {
            args: Prisma.CarBrandsCountArgs<ExtArgs>
            result: $Utils.Optional<CarBrandsCountAggregateOutputType> | number
          }
        }
      }
      CarModels: {
        payload: Prisma.$CarModelsPayload<ExtArgs>
        fields: Prisma.CarModelsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.CarModelsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarModelsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.CarModelsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarModelsPayload>
          }
          findFirst: {
            args: Prisma.CarModelsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarModelsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.CarModelsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarModelsPayload>
          }
          findMany: {
            args: Prisma.CarModelsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarModelsPayload>[]
          }
          create: {
            args: Prisma.CarModelsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarModelsPayload>
          }
          createMany: {
            args: Prisma.CarModelsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.CarModelsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarModelsPayload>[]
          }
          delete: {
            args: Prisma.CarModelsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarModelsPayload>
          }
          update: {
            args: Prisma.CarModelsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarModelsPayload>
          }
          deleteMany: {
            args: Prisma.CarModelsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.CarModelsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.CarModelsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarModelsPayload>[]
          }
          upsert: {
            args: Prisma.CarModelsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CarModelsPayload>
          }
          aggregate: {
            args: Prisma.CarModelsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCarModels>
          }
          groupBy: {
            args: Prisma.CarModelsGroupByArgs<ExtArgs>
            result: $Utils.Optional<CarModelsGroupByOutputType>[]
          }
          count: {
            args: Prisma.CarModelsCountArgs<ExtArgs>
            result: $Utils.Optional<CarModelsCountAggregateOutputType> | number
          }
        }
      }
      MotorcycleBrands: {
        payload: Prisma.$MotorcycleBrandsPayload<ExtArgs>
        fields: Prisma.MotorcycleBrandsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.MotorcycleBrandsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleBrandsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.MotorcycleBrandsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleBrandsPayload>
          }
          findFirst: {
            args: Prisma.MotorcycleBrandsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleBrandsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.MotorcycleBrandsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleBrandsPayload>
          }
          findMany: {
            args: Prisma.MotorcycleBrandsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleBrandsPayload>[]
          }
          create: {
            args: Prisma.MotorcycleBrandsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleBrandsPayload>
          }
          createMany: {
            args: Prisma.MotorcycleBrandsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.MotorcycleBrandsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleBrandsPayload>[]
          }
          delete: {
            args: Prisma.MotorcycleBrandsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleBrandsPayload>
          }
          update: {
            args: Prisma.MotorcycleBrandsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleBrandsPayload>
          }
          deleteMany: {
            args: Prisma.MotorcycleBrandsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.MotorcycleBrandsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.MotorcycleBrandsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleBrandsPayload>[]
          }
          upsert: {
            args: Prisma.MotorcycleBrandsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleBrandsPayload>
          }
          aggregate: {
            args: Prisma.MotorcycleBrandsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateMotorcycleBrands>
          }
          groupBy: {
            args: Prisma.MotorcycleBrandsGroupByArgs<ExtArgs>
            result: $Utils.Optional<MotorcycleBrandsGroupByOutputType>[]
          }
          count: {
            args: Prisma.MotorcycleBrandsCountArgs<ExtArgs>
            result: $Utils.Optional<MotorcycleBrandsCountAggregateOutputType> | number
          }
        }
      }
      MotorcycleModels: {
        payload: Prisma.$MotorcycleModelsPayload<ExtArgs>
        fields: Prisma.MotorcycleModelsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.MotorcycleModelsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleModelsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.MotorcycleModelsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleModelsPayload>
          }
          findFirst: {
            args: Prisma.MotorcycleModelsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleModelsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.MotorcycleModelsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleModelsPayload>
          }
          findMany: {
            args: Prisma.MotorcycleModelsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleModelsPayload>[]
          }
          create: {
            args: Prisma.MotorcycleModelsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleModelsPayload>
          }
          createMany: {
            args: Prisma.MotorcycleModelsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.MotorcycleModelsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleModelsPayload>[]
          }
          delete: {
            args: Prisma.MotorcycleModelsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleModelsPayload>
          }
          update: {
            args: Prisma.MotorcycleModelsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleModelsPayload>
          }
          deleteMany: {
            args: Prisma.MotorcycleModelsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.MotorcycleModelsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.MotorcycleModelsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleModelsPayload>[]
          }
          upsert: {
            args: Prisma.MotorcycleModelsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MotorcycleModelsPayload>
          }
          aggregate: {
            args: Prisma.MotorcycleModelsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateMotorcycleModels>
          }
          groupBy: {
            args: Prisma.MotorcycleModelsGroupByArgs<ExtArgs>
            result: $Utils.Optional<MotorcycleModelsGroupByOutputType>[]
          }
          count: {
            args: Prisma.MotorcycleModelsCountArgs<ExtArgs>
            result: $Utils.Optional<MotorcycleModelsCountAggregateOutputType> | number
          }
        }
      }
      PublicTransportTypes: {
        payload: Prisma.$PublicTransportTypesPayload<ExtArgs>
        fields: Prisma.PublicTransportTypesFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PublicTransportTypesFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PublicTransportTypesPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PublicTransportTypesFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PublicTransportTypesPayload>
          }
          findFirst: {
            args: Prisma.PublicTransportTypesFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PublicTransportTypesPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PublicTransportTypesFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PublicTransportTypesPayload>
          }
          findMany: {
            args: Prisma.PublicTransportTypesFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PublicTransportTypesPayload>[]
          }
          create: {
            args: Prisma.PublicTransportTypesCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PublicTransportTypesPayload>
          }
          createMany: {
            args: Prisma.PublicTransportTypesCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PublicTransportTypesCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PublicTransportTypesPayload>[]
          }
          delete: {
            args: Prisma.PublicTransportTypesDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PublicTransportTypesPayload>
          }
          update: {
            args: Prisma.PublicTransportTypesUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PublicTransportTypesPayload>
          }
          deleteMany: {
            args: Prisma.PublicTransportTypesDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PublicTransportTypesUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PublicTransportTypesUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PublicTransportTypesPayload>[]
          }
          upsert: {
            args: Prisma.PublicTransportTypesUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PublicTransportTypesPayload>
          }
          aggregate: {
            args: Prisma.PublicTransportTypesAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePublicTransportTypes>
          }
          groupBy: {
            args: Prisma.PublicTransportTypesGroupByArgs<ExtArgs>
            result: $Utils.Optional<PublicTransportTypesGroupByOutputType>[]
          }
          count: {
            args: Prisma.PublicTransportTypesCountArgs<ExtArgs>
            result: $Utils.Optional<PublicTransportTypesCountAggregateOutputType> | number
          }
        }
      }
      AirBrands: {
        payload: Prisma.$AirBrandsPayload<ExtArgs>
        fields: Prisma.AirBrandsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AirBrandsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirBrandsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AirBrandsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirBrandsPayload>
          }
          findFirst: {
            args: Prisma.AirBrandsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirBrandsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AirBrandsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirBrandsPayload>
          }
          findMany: {
            args: Prisma.AirBrandsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirBrandsPayload>[]
          }
          create: {
            args: Prisma.AirBrandsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirBrandsPayload>
          }
          createMany: {
            args: Prisma.AirBrandsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.AirBrandsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirBrandsPayload>[]
          }
          delete: {
            args: Prisma.AirBrandsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirBrandsPayload>
          }
          update: {
            args: Prisma.AirBrandsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirBrandsPayload>
          }
          deleteMany: {
            args: Prisma.AirBrandsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AirBrandsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.AirBrandsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirBrandsPayload>[]
          }
          upsert: {
            args: Prisma.AirBrandsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirBrandsPayload>
          }
          aggregate: {
            args: Prisma.AirBrandsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAirBrands>
          }
          groupBy: {
            args: Prisma.AirBrandsGroupByArgs<ExtArgs>
            result: $Utils.Optional<AirBrandsGroupByOutputType>[]
          }
          count: {
            args: Prisma.AirBrandsCountArgs<ExtArgs>
            result: $Utils.Optional<AirBrandsCountAggregateOutputType> | number
          }
        }
      }
      AirModels: {
        payload: Prisma.$AirModelsPayload<ExtArgs>
        fields: Prisma.AirModelsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AirModelsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirModelsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AirModelsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirModelsPayload>
          }
          findFirst: {
            args: Prisma.AirModelsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirModelsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AirModelsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirModelsPayload>
          }
          findMany: {
            args: Prisma.AirModelsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirModelsPayload>[]
          }
          create: {
            args: Prisma.AirModelsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirModelsPayload>
          }
          createMany: {
            args: Prisma.AirModelsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.AirModelsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirModelsPayload>[]
          }
          delete: {
            args: Prisma.AirModelsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirModelsPayload>
          }
          update: {
            args: Prisma.AirModelsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirModelsPayload>
          }
          deleteMany: {
            args: Prisma.AirModelsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AirModelsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.AirModelsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirModelsPayload>[]
          }
          upsert: {
            args: Prisma.AirModelsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AirModelsPayload>
          }
          aggregate: {
            args: Prisma.AirModelsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAirModels>
          }
          groupBy: {
            args: Prisma.AirModelsGroupByArgs<ExtArgs>
            result: $Utils.Optional<AirModelsGroupByOutputType>[]
          }
          count: {
            args: Prisma.AirModelsCountArgs<ExtArgs>
            result: $Utils.Optional<AirModelsCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    customers?: CustomersOmit
    historyCalculator?: HistoryCalculatorOmit
    organization?: OrganizationOmit
    carBrands?: CarBrandsOmit
    carModels?: CarModelsOmit
    motorcycleBrands?: MotorcycleBrandsOmit
    motorcycleModels?: MotorcycleModelsOmit
    publicTransportTypes?: PublicTransportTypesOmit
    airBrands?: AirBrandsOmit
    airModels?: AirModelsOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type CustomersCountOutputType
   */

  export type CustomersCountOutputType = {
    HistoryCalculator: number
    org_adminOf: number
    org_memberOf: number
  }

  export type CustomersCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    HistoryCalculator?: boolean | CustomersCountOutputTypeCountHistoryCalculatorArgs
    org_adminOf?: boolean | CustomersCountOutputTypeCountOrg_adminOfArgs
    org_memberOf?: boolean | CustomersCountOutputTypeCountOrg_memberOfArgs
  }

  // Custom InputTypes
  /**
   * CustomersCountOutputType without action
   */
  export type CustomersCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CustomersCountOutputType
     */
    select?: CustomersCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * CustomersCountOutputType without action
   */
  export type CustomersCountOutputTypeCountHistoryCalculatorArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: HistoryCalculatorWhereInput
  }

  /**
   * CustomersCountOutputType without action
   */
  export type CustomersCountOutputTypeCountOrg_adminOfArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: OrganizationWhereInput
  }

  /**
   * CustomersCountOutputType without action
   */
  export type CustomersCountOutputTypeCountOrg_memberOfArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: OrganizationWhereInput
  }


  /**
   * Count Type OrganizationCountOutputType
   */

  export type OrganizationCountOutputType = {
    org_admins: number
    org_members: number
  }

  export type OrganizationCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    org_admins?: boolean | OrganizationCountOutputTypeCountOrg_adminsArgs
    org_members?: boolean | OrganizationCountOutputTypeCountOrg_membersArgs
  }

  // Custom InputTypes
  /**
   * OrganizationCountOutputType without action
   */
  export type OrganizationCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OrganizationCountOutputType
     */
    select?: OrganizationCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * OrganizationCountOutputType without action
   */
  export type OrganizationCountOutputTypeCountOrg_adminsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CustomersWhereInput
  }

  /**
   * OrganizationCountOutputType without action
   */
  export type OrganizationCountOutputTypeCountOrg_membersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CustomersWhereInput
  }


  /**
   * Count Type CarBrandsCountOutputType
   */

  export type CarBrandsCountOutputType = {
    CarModels: number
  }

  export type CarBrandsCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    CarModels?: boolean | CarBrandsCountOutputTypeCountCarModelsArgs
  }

  // Custom InputTypes
  /**
   * CarBrandsCountOutputType without action
   */
  export type CarBrandsCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrandsCountOutputType
     */
    select?: CarBrandsCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * CarBrandsCountOutputType without action
   */
  export type CarBrandsCountOutputTypeCountCarModelsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CarModelsWhereInput
  }


  /**
   * Count Type MotorcycleBrandsCountOutputType
   */

  export type MotorcycleBrandsCountOutputType = {
    MotorcycleModels: number
  }

  export type MotorcycleBrandsCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    MotorcycleModels?: boolean | MotorcycleBrandsCountOutputTypeCountMotorcycleModelsArgs
  }

  // Custom InputTypes
  /**
   * MotorcycleBrandsCountOutputType without action
   */
  export type MotorcycleBrandsCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrandsCountOutputType
     */
    select?: MotorcycleBrandsCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * MotorcycleBrandsCountOutputType without action
   */
  export type MotorcycleBrandsCountOutputTypeCountMotorcycleModelsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MotorcycleModelsWhereInput
  }


  /**
   * Count Type AirBrandsCountOutputType
   */

  export type AirBrandsCountOutputType = {
    AirModels: number
  }

  export type AirBrandsCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    AirModels?: boolean | AirBrandsCountOutputTypeCountAirModelsArgs
  }

  // Custom InputTypes
  /**
   * AirBrandsCountOutputType without action
   */
  export type AirBrandsCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrandsCountOutputType
     */
    select?: AirBrandsCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * AirBrandsCountOutputType without action
   */
  export type AirBrandsCountOutputTypeCountAirModelsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AirModelsWhereInput
  }


  /**
   * Models
   */

  /**
   * Model Customers
   */

  export type AggregateCustomers = {
    _count: CustomersCountAggregateOutputType | null
    _avg: CustomersAvgAggregateOutputType | null
    _sum: CustomersSumAggregateOutputType | null
    _min: CustomersMinAggregateOutputType | null
    _max: CustomersMaxAggregateOutputType | null
  }

  export type CustomersAvgAggregateOutputType = {
    id: number | null
    organizationId: number | null
  }

  export type CustomersSumAggregateOutputType = {
    id: number | null
    organizationId: number | null
  }

  export type CustomersMinAggregateOutputType = {
    id: number | null
    username: string | null
    email: string | null
    password: string | null
    phone: string | null
    address: string | null
    city: string | null
    state: string | null
    zipCode: string | null
    province: string | null
    isActive: boolean | null
    isVerified: boolean | null
    lastLogin: Date | null
    profilePicture: string | null
    organizationId: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type CustomersMaxAggregateOutputType = {
    id: number | null
    username: string | null
    email: string | null
    password: string | null
    phone: string | null
    address: string | null
    city: string | null
    state: string | null
    zipCode: string | null
    province: string | null
    isActive: boolean | null
    isVerified: boolean | null
    lastLogin: Date | null
    profilePicture: string | null
    organizationId: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type CustomersCountAggregateOutputType = {
    id: number
    username: number
    email: number
    password: number
    phone: number
    address: number
    city: number
    state: number
    zipCode: number
    province: number
    isActive: number
    isVerified: number
    lastLogin: number
    profilePicture: number
    organizationId: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type CustomersAvgAggregateInputType = {
    id?: true
    organizationId?: true
  }

  export type CustomersSumAggregateInputType = {
    id?: true
    organizationId?: true
  }

  export type CustomersMinAggregateInputType = {
    id?: true
    username?: true
    email?: true
    password?: true
    phone?: true
    address?: true
    city?: true
    state?: true
    zipCode?: true
    province?: true
    isActive?: true
    isVerified?: true
    lastLogin?: true
    profilePicture?: true
    organizationId?: true
    createdAt?: true
    updatedAt?: true
  }

  export type CustomersMaxAggregateInputType = {
    id?: true
    username?: true
    email?: true
    password?: true
    phone?: true
    address?: true
    city?: true
    state?: true
    zipCode?: true
    province?: true
    isActive?: true
    isVerified?: true
    lastLogin?: true
    profilePicture?: true
    organizationId?: true
    createdAt?: true
    updatedAt?: true
  }

  export type CustomersCountAggregateInputType = {
    id?: true
    username?: true
    email?: true
    password?: true
    phone?: true
    address?: true
    city?: true
    state?: true
    zipCode?: true
    province?: true
    isActive?: true
    isVerified?: true
    lastLogin?: true
    profilePicture?: true
    organizationId?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type CustomersAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Customers to aggregate.
     */
    where?: CustomersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Customers to fetch.
     */
    orderBy?: CustomersOrderByWithRelationInput | CustomersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CustomersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Customers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Customers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Customers
    **/
    _count?: true | CustomersCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CustomersAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CustomersSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CustomersMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CustomersMaxAggregateInputType
  }

  export type GetCustomersAggregateType<T extends CustomersAggregateArgs> = {
        [P in keyof T & keyof AggregateCustomers]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCustomers[P]>
      : GetScalarType<T[P], AggregateCustomers[P]>
  }




  export type CustomersGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CustomersWhereInput
    orderBy?: CustomersOrderByWithAggregationInput | CustomersOrderByWithAggregationInput[]
    by: CustomersScalarFieldEnum[] | CustomersScalarFieldEnum
    having?: CustomersScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CustomersCountAggregateInputType | true
    _avg?: CustomersAvgAggregateInputType
    _sum?: CustomersSumAggregateInputType
    _min?: CustomersMinAggregateInputType
    _max?: CustomersMaxAggregateInputType
  }

  export type CustomersGroupByOutputType = {
    id: number
    username: string
    email: string
    password: string | null
    phone: string | null
    address: string | null
    city: string | null
    state: string | null
    zipCode: string | null
    province: string | null
    isActive: boolean
    isVerified: boolean
    lastLogin: Date | null
    profilePicture: string | null
    organizationId: number | null
    createdAt: Date
    updatedAt: Date
    _count: CustomersCountAggregateOutputType | null
    _avg: CustomersAvgAggregateOutputType | null
    _sum: CustomersSumAggregateOutputType | null
    _min: CustomersMinAggregateOutputType | null
    _max: CustomersMaxAggregateOutputType | null
  }

  type GetCustomersGroupByPayload<T extends CustomersGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CustomersGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CustomersGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CustomersGroupByOutputType[P]>
            : GetScalarType<T[P], CustomersGroupByOutputType[P]>
        }
      >
    >


  export type CustomersSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    username?: boolean
    email?: boolean
    password?: boolean
    phone?: boolean
    address?: boolean
    city?: boolean
    state?: boolean
    zipCode?: boolean
    province?: boolean
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: boolean
    profilePicture?: boolean
    organizationId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    HistoryCalculator?: boolean | Customers$HistoryCalculatorArgs<ExtArgs>
    org_adminOf?: boolean | Customers$org_adminOfArgs<ExtArgs>
    org_memberOf?: boolean | Customers$org_memberOfArgs<ExtArgs>
    _count?: boolean | CustomersCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["customers"]>

  export type CustomersSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    username?: boolean
    email?: boolean
    password?: boolean
    phone?: boolean
    address?: boolean
    city?: boolean
    state?: boolean
    zipCode?: boolean
    province?: boolean
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: boolean
    profilePicture?: boolean
    organizationId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["customers"]>

  export type CustomersSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    username?: boolean
    email?: boolean
    password?: boolean
    phone?: boolean
    address?: boolean
    city?: boolean
    state?: boolean
    zipCode?: boolean
    province?: boolean
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: boolean
    profilePicture?: boolean
    organizationId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["customers"]>

  export type CustomersSelectScalar = {
    id?: boolean
    username?: boolean
    email?: boolean
    password?: boolean
    phone?: boolean
    address?: boolean
    city?: boolean
    state?: boolean
    zipCode?: boolean
    province?: boolean
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: boolean
    profilePicture?: boolean
    organizationId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type CustomersOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "username" | "email" | "password" | "phone" | "address" | "city" | "state" | "zipCode" | "province" | "isActive" | "isVerified" | "lastLogin" | "profilePicture" | "organizationId" | "createdAt" | "updatedAt", ExtArgs["result"]["customers"]>
  export type CustomersInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    HistoryCalculator?: boolean | Customers$HistoryCalculatorArgs<ExtArgs>
    org_adminOf?: boolean | Customers$org_adminOfArgs<ExtArgs>
    org_memberOf?: boolean | Customers$org_memberOfArgs<ExtArgs>
    _count?: boolean | CustomersCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type CustomersIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type CustomersIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $CustomersPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Customers"
    objects: {
      HistoryCalculator: Prisma.$HistoryCalculatorPayload<ExtArgs>[]
      org_adminOf: Prisma.$OrganizationPayload<ExtArgs>[]
      org_memberOf: Prisma.$OrganizationPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      username: string
      email: string
      password: string | null
      phone: string | null
      address: string | null
      city: string | null
      state: string | null
      zipCode: string | null
      province: string | null
      isActive: boolean
      isVerified: boolean
      lastLogin: Date | null
      profilePicture: string | null
      organizationId: number | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["customers"]>
    composites: {}
  }

  type CustomersGetPayload<S extends boolean | null | undefined | CustomersDefaultArgs> = $Result.GetResult<Prisma.$CustomersPayload, S>

  type CustomersCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<CustomersFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CustomersCountAggregateInputType | true
    }

  export interface CustomersDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Customers'], meta: { name: 'Customers' } }
    /**
     * Find zero or one Customers that matches the filter.
     * @param {CustomersFindUniqueArgs} args - Arguments to find a Customers
     * @example
     * // Get one Customers
     * const customers = await prisma.customers.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CustomersFindUniqueArgs>(args: SelectSubset<T, CustomersFindUniqueArgs<ExtArgs>>): Prisma__CustomersClient<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Customers that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CustomersFindUniqueOrThrowArgs} args - Arguments to find a Customers
     * @example
     * // Get one Customers
     * const customers = await prisma.customers.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CustomersFindUniqueOrThrowArgs>(args: SelectSubset<T, CustomersFindUniqueOrThrowArgs<ExtArgs>>): Prisma__CustomersClient<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Customers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CustomersFindFirstArgs} args - Arguments to find a Customers
     * @example
     * // Get one Customers
     * const customers = await prisma.customers.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CustomersFindFirstArgs>(args?: SelectSubset<T, CustomersFindFirstArgs<ExtArgs>>): Prisma__CustomersClient<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Customers that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CustomersFindFirstOrThrowArgs} args - Arguments to find a Customers
     * @example
     * // Get one Customers
     * const customers = await prisma.customers.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CustomersFindFirstOrThrowArgs>(args?: SelectSubset<T, CustomersFindFirstOrThrowArgs<ExtArgs>>): Prisma__CustomersClient<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Customers that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CustomersFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Customers
     * const customers = await prisma.customers.findMany()
     * 
     * // Get first 10 Customers
     * const customers = await prisma.customers.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const customersWithIdOnly = await prisma.customers.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends CustomersFindManyArgs>(args?: SelectSubset<T, CustomersFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Customers.
     * @param {CustomersCreateArgs} args - Arguments to create a Customers.
     * @example
     * // Create one Customers
     * const Customers = await prisma.customers.create({
     *   data: {
     *     // ... data to create a Customers
     *   }
     * })
     * 
     */
    create<T extends CustomersCreateArgs>(args: SelectSubset<T, CustomersCreateArgs<ExtArgs>>): Prisma__CustomersClient<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Customers.
     * @param {CustomersCreateManyArgs} args - Arguments to create many Customers.
     * @example
     * // Create many Customers
     * const customers = await prisma.customers.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends CustomersCreateManyArgs>(args?: SelectSubset<T, CustomersCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Customers and returns the data saved in the database.
     * @param {CustomersCreateManyAndReturnArgs} args - Arguments to create many Customers.
     * @example
     * // Create many Customers
     * const customers = await prisma.customers.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Customers and only return the `id`
     * const customersWithIdOnly = await prisma.customers.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends CustomersCreateManyAndReturnArgs>(args?: SelectSubset<T, CustomersCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Customers.
     * @param {CustomersDeleteArgs} args - Arguments to delete one Customers.
     * @example
     * // Delete one Customers
     * const Customers = await prisma.customers.delete({
     *   where: {
     *     // ... filter to delete one Customers
     *   }
     * })
     * 
     */
    delete<T extends CustomersDeleteArgs>(args: SelectSubset<T, CustomersDeleteArgs<ExtArgs>>): Prisma__CustomersClient<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Customers.
     * @param {CustomersUpdateArgs} args - Arguments to update one Customers.
     * @example
     * // Update one Customers
     * const customers = await prisma.customers.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends CustomersUpdateArgs>(args: SelectSubset<T, CustomersUpdateArgs<ExtArgs>>): Prisma__CustomersClient<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Customers.
     * @param {CustomersDeleteManyArgs} args - Arguments to filter Customers to delete.
     * @example
     * // Delete a few Customers
     * const { count } = await prisma.customers.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends CustomersDeleteManyArgs>(args?: SelectSubset<T, CustomersDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Customers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CustomersUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Customers
     * const customers = await prisma.customers.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends CustomersUpdateManyArgs>(args: SelectSubset<T, CustomersUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Customers and returns the data updated in the database.
     * @param {CustomersUpdateManyAndReturnArgs} args - Arguments to update many Customers.
     * @example
     * // Update many Customers
     * const customers = await prisma.customers.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Customers and only return the `id`
     * const customersWithIdOnly = await prisma.customers.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends CustomersUpdateManyAndReturnArgs>(args: SelectSubset<T, CustomersUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Customers.
     * @param {CustomersUpsertArgs} args - Arguments to update or create a Customers.
     * @example
     * // Update or create a Customers
     * const customers = await prisma.customers.upsert({
     *   create: {
     *     // ... data to create a Customers
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Customers we want to update
     *   }
     * })
     */
    upsert<T extends CustomersUpsertArgs>(args: SelectSubset<T, CustomersUpsertArgs<ExtArgs>>): Prisma__CustomersClient<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Customers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CustomersCountArgs} args - Arguments to filter Customers to count.
     * @example
     * // Count the number of Customers
     * const count = await prisma.customers.count({
     *   where: {
     *     // ... the filter for the Customers we want to count
     *   }
     * })
    **/
    count<T extends CustomersCountArgs>(
      args?: Subset<T, CustomersCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CustomersCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Customers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CustomersAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CustomersAggregateArgs>(args: Subset<T, CustomersAggregateArgs>): Prisma.PrismaPromise<GetCustomersAggregateType<T>>

    /**
     * Group by Customers.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CustomersGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CustomersGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CustomersGroupByArgs['orderBy'] }
        : { orderBy?: CustomersGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CustomersGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCustomersGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Customers model
   */
  readonly fields: CustomersFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Customers.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__CustomersClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    HistoryCalculator<T extends Customers$HistoryCalculatorArgs<ExtArgs> = {}>(args?: Subset<T, Customers$HistoryCalculatorArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$HistoryCalculatorPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    org_adminOf<T extends Customers$org_adminOfArgs<ExtArgs> = {}>(args?: Subset<T, Customers$org_adminOfArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    org_memberOf<T extends Customers$org_memberOfArgs<ExtArgs> = {}>(args?: Subset<T, Customers$org_memberOfArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Customers model
   */
  interface CustomersFieldRefs {
    readonly id: FieldRef<"Customers", 'Int'>
    readonly username: FieldRef<"Customers", 'String'>
    readonly email: FieldRef<"Customers", 'String'>
    readonly password: FieldRef<"Customers", 'String'>
    readonly phone: FieldRef<"Customers", 'String'>
    readonly address: FieldRef<"Customers", 'String'>
    readonly city: FieldRef<"Customers", 'String'>
    readonly state: FieldRef<"Customers", 'String'>
    readonly zipCode: FieldRef<"Customers", 'String'>
    readonly province: FieldRef<"Customers", 'String'>
    readonly isActive: FieldRef<"Customers", 'Boolean'>
    readonly isVerified: FieldRef<"Customers", 'Boolean'>
    readonly lastLogin: FieldRef<"Customers", 'DateTime'>
    readonly profilePicture: FieldRef<"Customers", 'String'>
    readonly organizationId: FieldRef<"Customers", 'Int'>
    readonly createdAt: FieldRef<"Customers", 'DateTime'>
    readonly updatedAt: FieldRef<"Customers", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Customers findUnique
   */
  export type CustomersFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CustomersInclude<ExtArgs> | null
    /**
     * Filter, which Customers to fetch.
     */
    where: CustomersWhereUniqueInput
  }

  /**
   * Customers findUniqueOrThrow
   */
  export type CustomersFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CustomersInclude<ExtArgs> | null
    /**
     * Filter, which Customers to fetch.
     */
    where: CustomersWhereUniqueInput
  }

  /**
   * Customers findFirst
   */
  export type CustomersFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CustomersInclude<ExtArgs> | null
    /**
     * Filter, which Customers to fetch.
     */
    where?: CustomersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Customers to fetch.
     */
    orderBy?: CustomersOrderByWithRelationInput | CustomersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Customers.
     */
    cursor?: CustomersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Customers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Customers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Customers.
     */
    distinct?: CustomersScalarFieldEnum | CustomersScalarFieldEnum[]
  }

  /**
   * Customers findFirstOrThrow
   */
  export type CustomersFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CustomersInclude<ExtArgs> | null
    /**
     * Filter, which Customers to fetch.
     */
    where?: CustomersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Customers to fetch.
     */
    orderBy?: CustomersOrderByWithRelationInput | CustomersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Customers.
     */
    cursor?: CustomersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Customers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Customers.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Customers.
     */
    distinct?: CustomersScalarFieldEnum | CustomersScalarFieldEnum[]
  }

  /**
   * Customers findMany
   */
  export type CustomersFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CustomersInclude<ExtArgs> | null
    /**
     * Filter, which Customers to fetch.
     */
    where?: CustomersWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Customers to fetch.
     */
    orderBy?: CustomersOrderByWithRelationInput | CustomersOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Customers.
     */
    cursor?: CustomersWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Customers from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Customers.
     */
    skip?: number
    distinct?: CustomersScalarFieldEnum | CustomersScalarFieldEnum[]
  }

  /**
   * Customers create
   */
  export type CustomersCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CustomersInclude<ExtArgs> | null
    /**
     * The data needed to create a Customers.
     */
    data: XOR<CustomersCreateInput, CustomersUncheckedCreateInput>
  }

  /**
   * Customers createMany
   */
  export type CustomersCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Customers.
     */
    data: CustomersCreateManyInput | CustomersCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Customers createManyAndReturn
   */
  export type CustomersCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * The data used to create many Customers.
     */
    data: CustomersCreateManyInput | CustomersCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Customers update
   */
  export type CustomersUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CustomersInclude<ExtArgs> | null
    /**
     * The data needed to update a Customers.
     */
    data: XOR<CustomersUpdateInput, CustomersUncheckedUpdateInput>
    /**
     * Choose, which Customers to update.
     */
    where: CustomersWhereUniqueInput
  }

  /**
   * Customers updateMany
   */
  export type CustomersUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Customers.
     */
    data: XOR<CustomersUpdateManyMutationInput, CustomersUncheckedUpdateManyInput>
    /**
     * Filter which Customers to update
     */
    where?: CustomersWhereInput
    /**
     * Limit how many Customers to update.
     */
    limit?: number
  }

  /**
   * Customers updateManyAndReturn
   */
  export type CustomersUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * The data used to update Customers.
     */
    data: XOR<CustomersUpdateManyMutationInput, CustomersUncheckedUpdateManyInput>
    /**
     * Filter which Customers to update
     */
    where?: CustomersWhereInput
    /**
     * Limit how many Customers to update.
     */
    limit?: number
  }

  /**
   * Customers upsert
   */
  export type CustomersUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CustomersInclude<ExtArgs> | null
    /**
     * The filter to search for the Customers to update in case it exists.
     */
    where: CustomersWhereUniqueInput
    /**
     * In case the Customers found by the `where` argument doesn't exist, create a new Customers with this data.
     */
    create: XOR<CustomersCreateInput, CustomersUncheckedCreateInput>
    /**
     * In case the Customers was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CustomersUpdateInput, CustomersUncheckedUpdateInput>
  }

  /**
   * Customers delete
   */
  export type CustomersDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CustomersInclude<ExtArgs> | null
    /**
     * Filter which Customers to delete.
     */
    where: CustomersWhereUniqueInput
  }

  /**
   * Customers deleteMany
   */
  export type CustomersDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Customers to delete
     */
    where?: CustomersWhereInput
    /**
     * Limit how many Customers to delete.
     */
    limit?: number
  }

  /**
   * Customers.HistoryCalculator
   */
  export type Customers$HistoryCalculatorArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorInclude<ExtArgs> | null
    where?: HistoryCalculatorWhereInput
    orderBy?: HistoryCalculatorOrderByWithRelationInput | HistoryCalculatorOrderByWithRelationInput[]
    cursor?: HistoryCalculatorWhereUniqueInput
    take?: number
    skip?: number
    distinct?: HistoryCalculatorScalarFieldEnum | HistoryCalculatorScalarFieldEnum[]
  }

  /**
   * Customers.org_adminOf
   */
  export type Customers$org_adminOfArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrganizationInclude<ExtArgs> | null
    where?: OrganizationWhereInput
    orderBy?: OrganizationOrderByWithRelationInput | OrganizationOrderByWithRelationInput[]
    cursor?: OrganizationWhereUniqueInput
    take?: number
    skip?: number
    distinct?: OrganizationScalarFieldEnum | OrganizationScalarFieldEnum[]
  }

  /**
   * Customers.org_memberOf
   */
  export type Customers$org_memberOfArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrganizationInclude<ExtArgs> | null
    where?: OrganizationWhereInput
    orderBy?: OrganizationOrderByWithRelationInput | OrganizationOrderByWithRelationInput[]
    cursor?: OrganizationWhereUniqueInput
    take?: number
    skip?: number
    distinct?: OrganizationScalarFieldEnum | OrganizationScalarFieldEnum[]
  }

  /**
   * Customers without action
   */
  export type CustomersDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CustomersInclude<ExtArgs> | null
  }


  /**
   * Model HistoryCalculator
   */

  export type AggregateHistoryCalculator = {
    _count: HistoryCalculatorCountAggregateOutputType | null
    _avg: HistoryCalculatorAvgAggregateOutputType | null
    _sum: HistoryCalculatorSumAggregateOutputType | null
    _min: HistoryCalculatorMinAggregateOutputType | null
    _max: HistoryCalculatorMaxAggregateOutputType | null
  }

  export type HistoryCalculatorAvgAggregateOutputType = {
    id: number | null
    customerId: number | null
    result: number | null
  }

  export type HistoryCalculatorSumAggregateOutputType = {
    id: number | null
    customerId: number | null
    result: number | null
  }

  export type HistoryCalculatorMinAggregateOutputType = {
    id: number | null
    customerId: number | null
    calculation: string | null
    result: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type HistoryCalculatorMaxAggregateOutputType = {
    id: number | null
    customerId: number | null
    calculation: string | null
    result: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type HistoryCalculatorCountAggregateOutputType = {
    id: number
    customerId: number
    calculation: number
    result: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type HistoryCalculatorAvgAggregateInputType = {
    id?: true
    customerId?: true
    result?: true
  }

  export type HistoryCalculatorSumAggregateInputType = {
    id?: true
    customerId?: true
    result?: true
  }

  export type HistoryCalculatorMinAggregateInputType = {
    id?: true
    customerId?: true
    calculation?: true
    result?: true
    createdAt?: true
    updatedAt?: true
  }

  export type HistoryCalculatorMaxAggregateInputType = {
    id?: true
    customerId?: true
    calculation?: true
    result?: true
    createdAt?: true
    updatedAt?: true
  }

  export type HistoryCalculatorCountAggregateInputType = {
    id?: true
    customerId?: true
    calculation?: true
    result?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type HistoryCalculatorAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which HistoryCalculator to aggregate.
     */
    where?: HistoryCalculatorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of HistoryCalculators to fetch.
     */
    orderBy?: HistoryCalculatorOrderByWithRelationInput | HistoryCalculatorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: HistoryCalculatorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` HistoryCalculators from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` HistoryCalculators.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned HistoryCalculators
    **/
    _count?: true | HistoryCalculatorCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: HistoryCalculatorAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: HistoryCalculatorSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: HistoryCalculatorMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: HistoryCalculatorMaxAggregateInputType
  }

  export type GetHistoryCalculatorAggregateType<T extends HistoryCalculatorAggregateArgs> = {
        [P in keyof T & keyof AggregateHistoryCalculator]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateHistoryCalculator[P]>
      : GetScalarType<T[P], AggregateHistoryCalculator[P]>
  }




  export type HistoryCalculatorGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: HistoryCalculatorWhereInput
    orderBy?: HistoryCalculatorOrderByWithAggregationInput | HistoryCalculatorOrderByWithAggregationInput[]
    by: HistoryCalculatorScalarFieldEnum[] | HistoryCalculatorScalarFieldEnum
    having?: HistoryCalculatorScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: HistoryCalculatorCountAggregateInputType | true
    _avg?: HistoryCalculatorAvgAggregateInputType
    _sum?: HistoryCalculatorSumAggregateInputType
    _min?: HistoryCalculatorMinAggregateInputType
    _max?: HistoryCalculatorMaxAggregateInputType
  }

  export type HistoryCalculatorGroupByOutputType = {
    id: number
    customerId: number
    calculation: string
    result: number
    createdAt: Date
    updatedAt: Date
    _count: HistoryCalculatorCountAggregateOutputType | null
    _avg: HistoryCalculatorAvgAggregateOutputType | null
    _sum: HistoryCalculatorSumAggregateOutputType | null
    _min: HistoryCalculatorMinAggregateOutputType | null
    _max: HistoryCalculatorMaxAggregateOutputType | null
  }

  type GetHistoryCalculatorGroupByPayload<T extends HistoryCalculatorGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<HistoryCalculatorGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof HistoryCalculatorGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], HistoryCalculatorGroupByOutputType[P]>
            : GetScalarType<T[P], HistoryCalculatorGroupByOutputType[P]>
        }
      >
    >


  export type HistoryCalculatorSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    customerId?: boolean
    calculation?: boolean
    result?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    customer?: boolean | CustomersDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["historyCalculator"]>

  export type HistoryCalculatorSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    customerId?: boolean
    calculation?: boolean
    result?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    customer?: boolean | CustomersDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["historyCalculator"]>

  export type HistoryCalculatorSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    customerId?: boolean
    calculation?: boolean
    result?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    customer?: boolean | CustomersDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["historyCalculator"]>

  export type HistoryCalculatorSelectScalar = {
    id?: boolean
    customerId?: boolean
    calculation?: boolean
    result?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type HistoryCalculatorOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "customerId" | "calculation" | "result" | "createdAt" | "updatedAt", ExtArgs["result"]["historyCalculator"]>
  export type HistoryCalculatorInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | CustomersDefaultArgs<ExtArgs>
  }
  export type HistoryCalculatorIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | CustomersDefaultArgs<ExtArgs>
  }
  export type HistoryCalculatorIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    customer?: boolean | CustomersDefaultArgs<ExtArgs>
  }

  export type $HistoryCalculatorPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "HistoryCalculator"
    objects: {
      customer: Prisma.$CustomersPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      customerId: number
      calculation: string
      result: number
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["historyCalculator"]>
    composites: {}
  }

  type HistoryCalculatorGetPayload<S extends boolean | null | undefined | HistoryCalculatorDefaultArgs> = $Result.GetResult<Prisma.$HistoryCalculatorPayload, S>

  type HistoryCalculatorCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<HistoryCalculatorFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: HistoryCalculatorCountAggregateInputType | true
    }

  export interface HistoryCalculatorDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['HistoryCalculator'], meta: { name: 'HistoryCalculator' } }
    /**
     * Find zero or one HistoryCalculator that matches the filter.
     * @param {HistoryCalculatorFindUniqueArgs} args - Arguments to find a HistoryCalculator
     * @example
     * // Get one HistoryCalculator
     * const historyCalculator = await prisma.historyCalculator.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends HistoryCalculatorFindUniqueArgs>(args: SelectSubset<T, HistoryCalculatorFindUniqueArgs<ExtArgs>>): Prisma__HistoryCalculatorClient<$Result.GetResult<Prisma.$HistoryCalculatorPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one HistoryCalculator that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {HistoryCalculatorFindUniqueOrThrowArgs} args - Arguments to find a HistoryCalculator
     * @example
     * // Get one HistoryCalculator
     * const historyCalculator = await prisma.historyCalculator.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends HistoryCalculatorFindUniqueOrThrowArgs>(args: SelectSubset<T, HistoryCalculatorFindUniqueOrThrowArgs<ExtArgs>>): Prisma__HistoryCalculatorClient<$Result.GetResult<Prisma.$HistoryCalculatorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first HistoryCalculator that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryCalculatorFindFirstArgs} args - Arguments to find a HistoryCalculator
     * @example
     * // Get one HistoryCalculator
     * const historyCalculator = await prisma.historyCalculator.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends HistoryCalculatorFindFirstArgs>(args?: SelectSubset<T, HistoryCalculatorFindFirstArgs<ExtArgs>>): Prisma__HistoryCalculatorClient<$Result.GetResult<Prisma.$HistoryCalculatorPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first HistoryCalculator that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryCalculatorFindFirstOrThrowArgs} args - Arguments to find a HistoryCalculator
     * @example
     * // Get one HistoryCalculator
     * const historyCalculator = await prisma.historyCalculator.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends HistoryCalculatorFindFirstOrThrowArgs>(args?: SelectSubset<T, HistoryCalculatorFindFirstOrThrowArgs<ExtArgs>>): Prisma__HistoryCalculatorClient<$Result.GetResult<Prisma.$HistoryCalculatorPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more HistoryCalculators that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryCalculatorFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all HistoryCalculators
     * const historyCalculators = await prisma.historyCalculator.findMany()
     * 
     * // Get first 10 HistoryCalculators
     * const historyCalculators = await prisma.historyCalculator.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const historyCalculatorWithIdOnly = await prisma.historyCalculator.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends HistoryCalculatorFindManyArgs>(args?: SelectSubset<T, HistoryCalculatorFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$HistoryCalculatorPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a HistoryCalculator.
     * @param {HistoryCalculatorCreateArgs} args - Arguments to create a HistoryCalculator.
     * @example
     * // Create one HistoryCalculator
     * const HistoryCalculator = await prisma.historyCalculator.create({
     *   data: {
     *     // ... data to create a HistoryCalculator
     *   }
     * })
     * 
     */
    create<T extends HistoryCalculatorCreateArgs>(args: SelectSubset<T, HistoryCalculatorCreateArgs<ExtArgs>>): Prisma__HistoryCalculatorClient<$Result.GetResult<Prisma.$HistoryCalculatorPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many HistoryCalculators.
     * @param {HistoryCalculatorCreateManyArgs} args - Arguments to create many HistoryCalculators.
     * @example
     * // Create many HistoryCalculators
     * const historyCalculator = await prisma.historyCalculator.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends HistoryCalculatorCreateManyArgs>(args?: SelectSubset<T, HistoryCalculatorCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many HistoryCalculators and returns the data saved in the database.
     * @param {HistoryCalculatorCreateManyAndReturnArgs} args - Arguments to create many HistoryCalculators.
     * @example
     * // Create many HistoryCalculators
     * const historyCalculator = await prisma.historyCalculator.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many HistoryCalculators and only return the `id`
     * const historyCalculatorWithIdOnly = await prisma.historyCalculator.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends HistoryCalculatorCreateManyAndReturnArgs>(args?: SelectSubset<T, HistoryCalculatorCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$HistoryCalculatorPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a HistoryCalculator.
     * @param {HistoryCalculatorDeleteArgs} args - Arguments to delete one HistoryCalculator.
     * @example
     * // Delete one HistoryCalculator
     * const HistoryCalculator = await prisma.historyCalculator.delete({
     *   where: {
     *     // ... filter to delete one HistoryCalculator
     *   }
     * })
     * 
     */
    delete<T extends HistoryCalculatorDeleteArgs>(args: SelectSubset<T, HistoryCalculatorDeleteArgs<ExtArgs>>): Prisma__HistoryCalculatorClient<$Result.GetResult<Prisma.$HistoryCalculatorPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one HistoryCalculator.
     * @param {HistoryCalculatorUpdateArgs} args - Arguments to update one HistoryCalculator.
     * @example
     * // Update one HistoryCalculator
     * const historyCalculator = await prisma.historyCalculator.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends HistoryCalculatorUpdateArgs>(args: SelectSubset<T, HistoryCalculatorUpdateArgs<ExtArgs>>): Prisma__HistoryCalculatorClient<$Result.GetResult<Prisma.$HistoryCalculatorPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more HistoryCalculators.
     * @param {HistoryCalculatorDeleteManyArgs} args - Arguments to filter HistoryCalculators to delete.
     * @example
     * // Delete a few HistoryCalculators
     * const { count } = await prisma.historyCalculator.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends HistoryCalculatorDeleteManyArgs>(args?: SelectSubset<T, HistoryCalculatorDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more HistoryCalculators.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryCalculatorUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many HistoryCalculators
     * const historyCalculator = await prisma.historyCalculator.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends HistoryCalculatorUpdateManyArgs>(args: SelectSubset<T, HistoryCalculatorUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more HistoryCalculators and returns the data updated in the database.
     * @param {HistoryCalculatorUpdateManyAndReturnArgs} args - Arguments to update many HistoryCalculators.
     * @example
     * // Update many HistoryCalculators
     * const historyCalculator = await prisma.historyCalculator.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more HistoryCalculators and only return the `id`
     * const historyCalculatorWithIdOnly = await prisma.historyCalculator.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends HistoryCalculatorUpdateManyAndReturnArgs>(args: SelectSubset<T, HistoryCalculatorUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$HistoryCalculatorPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one HistoryCalculator.
     * @param {HistoryCalculatorUpsertArgs} args - Arguments to update or create a HistoryCalculator.
     * @example
     * // Update or create a HistoryCalculator
     * const historyCalculator = await prisma.historyCalculator.upsert({
     *   create: {
     *     // ... data to create a HistoryCalculator
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the HistoryCalculator we want to update
     *   }
     * })
     */
    upsert<T extends HistoryCalculatorUpsertArgs>(args: SelectSubset<T, HistoryCalculatorUpsertArgs<ExtArgs>>): Prisma__HistoryCalculatorClient<$Result.GetResult<Prisma.$HistoryCalculatorPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of HistoryCalculators.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryCalculatorCountArgs} args - Arguments to filter HistoryCalculators to count.
     * @example
     * // Count the number of HistoryCalculators
     * const count = await prisma.historyCalculator.count({
     *   where: {
     *     // ... the filter for the HistoryCalculators we want to count
     *   }
     * })
    **/
    count<T extends HistoryCalculatorCountArgs>(
      args?: Subset<T, HistoryCalculatorCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], HistoryCalculatorCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a HistoryCalculator.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryCalculatorAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends HistoryCalculatorAggregateArgs>(args: Subset<T, HistoryCalculatorAggregateArgs>): Prisma.PrismaPromise<GetHistoryCalculatorAggregateType<T>>

    /**
     * Group by HistoryCalculator.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {HistoryCalculatorGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends HistoryCalculatorGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: HistoryCalculatorGroupByArgs['orderBy'] }
        : { orderBy?: HistoryCalculatorGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, HistoryCalculatorGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetHistoryCalculatorGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the HistoryCalculator model
   */
  readonly fields: HistoryCalculatorFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for HistoryCalculator.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__HistoryCalculatorClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    customer<T extends CustomersDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CustomersDefaultArgs<ExtArgs>>): Prisma__CustomersClient<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the HistoryCalculator model
   */
  interface HistoryCalculatorFieldRefs {
    readonly id: FieldRef<"HistoryCalculator", 'Int'>
    readonly customerId: FieldRef<"HistoryCalculator", 'Int'>
    readonly calculation: FieldRef<"HistoryCalculator", 'String'>
    readonly result: FieldRef<"HistoryCalculator", 'Float'>
    readonly createdAt: FieldRef<"HistoryCalculator", 'DateTime'>
    readonly updatedAt: FieldRef<"HistoryCalculator", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * HistoryCalculator findUnique
   */
  export type HistoryCalculatorFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorInclude<ExtArgs> | null
    /**
     * Filter, which HistoryCalculator to fetch.
     */
    where: HistoryCalculatorWhereUniqueInput
  }

  /**
   * HistoryCalculator findUniqueOrThrow
   */
  export type HistoryCalculatorFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorInclude<ExtArgs> | null
    /**
     * Filter, which HistoryCalculator to fetch.
     */
    where: HistoryCalculatorWhereUniqueInput
  }

  /**
   * HistoryCalculator findFirst
   */
  export type HistoryCalculatorFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorInclude<ExtArgs> | null
    /**
     * Filter, which HistoryCalculator to fetch.
     */
    where?: HistoryCalculatorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of HistoryCalculators to fetch.
     */
    orderBy?: HistoryCalculatorOrderByWithRelationInput | HistoryCalculatorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for HistoryCalculators.
     */
    cursor?: HistoryCalculatorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` HistoryCalculators from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` HistoryCalculators.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of HistoryCalculators.
     */
    distinct?: HistoryCalculatorScalarFieldEnum | HistoryCalculatorScalarFieldEnum[]
  }

  /**
   * HistoryCalculator findFirstOrThrow
   */
  export type HistoryCalculatorFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorInclude<ExtArgs> | null
    /**
     * Filter, which HistoryCalculator to fetch.
     */
    where?: HistoryCalculatorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of HistoryCalculators to fetch.
     */
    orderBy?: HistoryCalculatorOrderByWithRelationInput | HistoryCalculatorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for HistoryCalculators.
     */
    cursor?: HistoryCalculatorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` HistoryCalculators from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` HistoryCalculators.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of HistoryCalculators.
     */
    distinct?: HistoryCalculatorScalarFieldEnum | HistoryCalculatorScalarFieldEnum[]
  }

  /**
   * HistoryCalculator findMany
   */
  export type HistoryCalculatorFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorInclude<ExtArgs> | null
    /**
     * Filter, which HistoryCalculators to fetch.
     */
    where?: HistoryCalculatorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of HistoryCalculators to fetch.
     */
    orderBy?: HistoryCalculatorOrderByWithRelationInput | HistoryCalculatorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing HistoryCalculators.
     */
    cursor?: HistoryCalculatorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` HistoryCalculators from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` HistoryCalculators.
     */
    skip?: number
    distinct?: HistoryCalculatorScalarFieldEnum | HistoryCalculatorScalarFieldEnum[]
  }

  /**
   * HistoryCalculator create
   */
  export type HistoryCalculatorCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorInclude<ExtArgs> | null
    /**
     * The data needed to create a HistoryCalculator.
     */
    data: XOR<HistoryCalculatorCreateInput, HistoryCalculatorUncheckedCreateInput>
  }

  /**
   * HistoryCalculator createMany
   */
  export type HistoryCalculatorCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many HistoryCalculators.
     */
    data: HistoryCalculatorCreateManyInput | HistoryCalculatorCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * HistoryCalculator createManyAndReturn
   */
  export type HistoryCalculatorCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * The data used to create many HistoryCalculators.
     */
    data: HistoryCalculatorCreateManyInput | HistoryCalculatorCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * HistoryCalculator update
   */
  export type HistoryCalculatorUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorInclude<ExtArgs> | null
    /**
     * The data needed to update a HistoryCalculator.
     */
    data: XOR<HistoryCalculatorUpdateInput, HistoryCalculatorUncheckedUpdateInput>
    /**
     * Choose, which HistoryCalculator to update.
     */
    where: HistoryCalculatorWhereUniqueInput
  }

  /**
   * HistoryCalculator updateMany
   */
  export type HistoryCalculatorUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update HistoryCalculators.
     */
    data: XOR<HistoryCalculatorUpdateManyMutationInput, HistoryCalculatorUncheckedUpdateManyInput>
    /**
     * Filter which HistoryCalculators to update
     */
    where?: HistoryCalculatorWhereInput
    /**
     * Limit how many HistoryCalculators to update.
     */
    limit?: number
  }

  /**
   * HistoryCalculator updateManyAndReturn
   */
  export type HistoryCalculatorUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * The data used to update HistoryCalculators.
     */
    data: XOR<HistoryCalculatorUpdateManyMutationInput, HistoryCalculatorUncheckedUpdateManyInput>
    /**
     * Filter which HistoryCalculators to update
     */
    where?: HistoryCalculatorWhereInput
    /**
     * Limit how many HistoryCalculators to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * HistoryCalculator upsert
   */
  export type HistoryCalculatorUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorInclude<ExtArgs> | null
    /**
     * The filter to search for the HistoryCalculator to update in case it exists.
     */
    where: HistoryCalculatorWhereUniqueInput
    /**
     * In case the HistoryCalculator found by the `where` argument doesn't exist, create a new HistoryCalculator with this data.
     */
    create: XOR<HistoryCalculatorCreateInput, HistoryCalculatorUncheckedCreateInput>
    /**
     * In case the HistoryCalculator was found with the provided `where` argument, update it with this data.
     */
    update: XOR<HistoryCalculatorUpdateInput, HistoryCalculatorUncheckedUpdateInput>
  }

  /**
   * HistoryCalculator delete
   */
  export type HistoryCalculatorDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorInclude<ExtArgs> | null
    /**
     * Filter which HistoryCalculator to delete.
     */
    where: HistoryCalculatorWhereUniqueInput
  }

  /**
   * HistoryCalculator deleteMany
   */
  export type HistoryCalculatorDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which HistoryCalculators to delete
     */
    where?: HistoryCalculatorWhereInput
    /**
     * Limit how many HistoryCalculators to delete.
     */
    limit?: number
  }

  /**
   * HistoryCalculator without action
   */
  export type HistoryCalculatorDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the HistoryCalculator
     */
    select?: HistoryCalculatorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the HistoryCalculator
     */
    omit?: HistoryCalculatorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: HistoryCalculatorInclude<ExtArgs> | null
  }


  /**
   * Model Organization
   */

  export type AggregateOrganization = {
    _count: OrganizationCountAggregateOutputType | null
    _avg: OrganizationAvgAggregateOutputType | null
    _sum: OrganizationSumAggregateOutputType | null
    _min: OrganizationMinAggregateOutputType | null
    _max: OrganizationMaxAggregateOutputType | null
  }

  export type OrganizationAvgAggregateOutputType = {
    id: number | null
  }

  export type OrganizationSumAggregateOutputType = {
    id: number | null
  }

  export type OrganizationMinAggregateOutputType = {
    id: number | null
    org_name: string | null
    org_email: string | null
    org_phone: string | null
    org_address: string | null
    org_city: string | null
    org_state: string | null
    org_zipCode: string | null
    org_province: string | null
    org_logo: string | null
    org_password: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type OrganizationMaxAggregateOutputType = {
    id: number | null
    org_name: string | null
    org_email: string | null
    org_phone: string | null
    org_address: string | null
    org_city: string | null
    org_state: string | null
    org_zipCode: string | null
    org_province: string | null
    org_logo: string | null
    org_password: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type OrganizationCountAggregateOutputType = {
    id: number
    org_name: number
    org_email: number
    org_phone: number
    org_address: number
    org_city: number
    org_state: number
    org_zipCode: number
    org_province: number
    org_logo: number
    org_password: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type OrganizationAvgAggregateInputType = {
    id?: true
  }

  export type OrganizationSumAggregateInputType = {
    id?: true
  }

  export type OrganizationMinAggregateInputType = {
    id?: true
    org_name?: true
    org_email?: true
    org_phone?: true
    org_address?: true
    org_city?: true
    org_state?: true
    org_zipCode?: true
    org_province?: true
    org_logo?: true
    org_password?: true
    createdAt?: true
    updatedAt?: true
  }

  export type OrganizationMaxAggregateInputType = {
    id?: true
    org_name?: true
    org_email?: true
    org_phone?: true
    org_address?: true
    org_city?: true
    org_state?: true
    org_zipCode?: true
    org_province?: true
    org_logo?: true
    org_password?: true
    createdAt?: true
    updatedAt?: true
  }

  export type OrganizationCountAggregateInputType = {
    id?: true
    org_name?: true
    org_email?: true
    org_phone?: true
    org_address?: true
    org_city?: true
    org_state?: true
    org_zipCode?: true
    org_province?: true
    org_logo?: true
    org_password?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type OrganizationAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Organization to aggregate.
     */
    where?: OrganizationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Organizations to fetch.
     */
    orderBy?: OrganizationOrderByWithRelationInput | OrganizationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: OrganizationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Organizations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Organizations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Organizations
    **/
    _count?: true | OrganizationCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: OrganizationAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: OrganizationSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: OrganizationMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: OrganizationMaxAggregateInputType
  }

  export type GetOrganizationAggregateType<T extends OrganizationAggregateArgs> = {
        [P in keyof T & keyof AggregateOrganization]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateOrganization[P]>
      : GetScalarType<T[P], AggregateOrganization[P]>
  }




  export type OrganizationGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: OrganizationWhereInput
    orderBy?: OrganizationOrderByWithAggregationInput | OrganizationOrderByWithAggregationInput[]
    by: OrganizationScalarFieldEnum[] | OrganizationScalarFieldEnum
    having?: OrganizationScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: OrganizationCountAggregateInputType | true
    _avg?: OrganizationAvgAggregateInputType
    _sum?: OrganizationSumAggregateInputType
    _min?: OrganizationMinAggregateInputType
    _max?: OrganizationMaxAggregateInputType
  }

  export type OrganizationGroupByOutputType = {
    id: number
    org_name: string
    org_email: string
    org_phone: string | null
    org_address: string | null
    org_city: string | null
    org_state: string | null
    org_zipCode: string | null
    org_province: string | null
    org_logo: string | null
    org_password: string | null
    createdAt: Date
    updatedAt: Date
    _count: OrganizationCountAggregateOutputType | null
    _avg: OrganizationAvgAggregateOutputType | null
    _sum: OrganizationSumAggregateOutputType | null
    _min: OrganizationMinAggregateOutputType | null
    _max: OrganizationMaxAggregateOutputType | null
  }

  type GetOrganizationGroupByPayload<T extends OrganizationGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<OrganizationGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof OrganizationGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], OrganizationGroupByOutputType[P]>
            : GetScalarType<T[P], OrganizationGroupByOutputType[P]>
        }
      >
    >


  export type OrganizationSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    org_name?: boolean
    org_email?: boolean
    org_phone?: boolean
    org_address?: boolean
    org_city?: boolean
    org_state?: boolean
    org_zipCode?: boolean
    org_province?: boolean
    org_logo?: boolean
    org_password?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    org_admins?: boolean | Organization$org_adminsArgs<ExtArgs>
    org_members?: boolean | Organization$org_membersArgs<ExtArgs>
    _count?: boolean | OrganizationCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["organization"]>

  export type OrganizationSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    org_name?: boolean
    org_email?: boolean
    org_phone?: boolean
    org_address?: boolean
    org_city?: boolean
    org_state?: boolean
    org_zipCode?: boolean
    org_province?: boolean
    org_logo?: boolean
    org_password?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["organization"]>

  export type OrganizationSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    org_name?: boolean
    org_email?: boolean
    org_phone?: boolean
    org_address?: boolean
    org_city?: boolean
    org_state?: boolean
    org_zipCode?: boolean
    org_province?: boolean
    org_logo?: boolean
    org_password?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["organization"]>

  export type OrganizationSelectScalar = {
    id?: boolean
    org_name?: boolean
    org_email?: boolean
    org_phone?: boolean
    org_address?: boolean
    org_city?: boolean
    org_state?: boolean
    org_zipCode?: boolean
    org_province?: boolean
    org_logo?: boolean
    org_password?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type OrganizationOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "org_name" | "org_email" | "org_phone" | "org_address" | "org_city" | "org_state" | "org_zipCode" | "org_province" | "org_logo" | "org_password" | "createdAt" | "updatedAt", ExtArgs["result"]["organization"]>
  export type OrganizationInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    org_admins?: boolean | Organization$org_adminsArgs<ExtArgs>
    org_members?: boolean | Organization$org_membersArgs<ExtArgs>
    _count?: boolean | OrganizationCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type OrganizationIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type OrganizationIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $OrganizationPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Organization"
    objects: {
      org_admins: Prisma.$CustomersPayload<ExtArgs>[]
      org_members: Prisma.$CustomersPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      org_name: string
      org_email: string
      org_phone: string | null
      org_address: string | null
      org_city: string | null
      org_state: string | null
      org_zipCode: string | null
      org_province: string | null
      org_logo: string | null
      org_password: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["organization"]>
    composites: {}
  }

  type OrganizationGetPayload<S extends boolean | null | undefined | OrganizationDefaultArgs> = $Result.GetResult<Prisma.$OrganizationPayload, S>

  type OrganizationCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<OrganizationFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: OrganizationCountAggregateInputType | true
    }

  export interface OrganizationDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Organization'], meta: { name: 'Organization' } }
    /**
     * Find zero or one Organization that matches the filter.
     * @param {OrganizationFindUniqueArgs} args - Arguments to find a Organization
     * @example
     * // Get one Organization
     * const organization = await prisma.organization.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends OrganizationFindUniqueArgs>(args: SelectSubset<T, OrganizationFindUniqueArgs<ExtArgs>>): Prisma__OrganizationClient<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Organization that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {OrganizationFindUniqueOrThrowArgs} args - Arguments to find a Organization
     * @example
     * // Get one Organization
     * const organization = await prisma.organization.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends OrganizationFindUniqueOrThrowArgs>(args: SelectSubset<T, OrganizationFindUniqueOrThrowArgs<ExtArgs>>): Prisma__OrganizationClient<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Organization that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrganizationFindFirstArgs} args - Arguments to find a Organization
     * @example
     * // Get one Organization
     * const organization = await prisma.organization.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends OrganizationFindFirstArgs>(args?: SelectSubset<T, OrganizationFindFirstArgs<ExtArgs>>): Prisma__OrganizationClient<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Organization that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrganizationFindFirstOrThrowArgs} args - Arguments to find a Organization
     * @example
     * // Get one Organization
     * const organization = await prisma.organization.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends OrganizationFindFirstOrThrowArgs>(args?: SelectSubset<T, OrganizationFindFirstOrThrowArgs<ExtArgs>>): Prisma__OrganizationClient<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Organizations that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrganizationFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Organizations
     * const organizations = await prisma.organization.findMany()
     * 
     * // Get first 10 Organizations
     * const organizations = await prisma.organization.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const organizationWithIdOnly = await prisma.organization.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends OrganizationFindManyArgs>(args?: SelectSubset<T, OrganizationFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Organization.
     * @param {OrganizationCreateArgs} args - Arguments to create a Organization.
     * @example
     * // Create one Organization
     * const Organization = await prisma.organization.create({
     *   data: {
     *     // ... data to create a Organization
     *   }
     * })
     * 
     */
    create<T extends OrganizationCreateArgs>(args: SelectSubset<T, OrganizationCreateArgs<ExtArgs>>): Prisma__OrganizationClient<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Organizations.
     * @param {OrganizationCreateManyArgs} args - Arguments to create many Organizations.
     * @example
     * // Create many Organizations
     * const organization = await prisma.organization.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends OrganizationCreateManyArgs>(args?: SelectSubset<T, OrganizationCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Organizations and returns the data saved in the database.
     * @param {OrganizationCreateManyAndReturnArgs} args - Arguments to create many Organizations.
     * @example
     * // Create many Organizations
     * const organization = await prisma.organization.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Organizations and only return the `id`
     * const organizationWithIdOnly = await prisma.organization.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends OrganizationCreateManyAndReturnArgs>(args?: SelectSubset<T, OrganizationCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Organization.
     * @param {OrganizationDeleteArgs} args - Arguments to delete one Organization.
     * @example
     * // Delete one Organization
     * const Organization = await prisma.organization.delete({
     *   where: {
     *     // ... filter to delete one Organization
     *   }
     * })
     * 
     */
    delete<T extends OrganizationDeleteArgs>(args: SelectSubset<T, OrganizationDeleteArgs<ExtArgs>>): Prisma__OrganizationClient<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Organization.
     * @param {OrganizationUpdateArgs} args - Arguments to update one Organization.
     * @example
     * // Update one Organization
     * const organization = await prisma.organization.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends OrganizationUpdateArgs>(args: SelectSubset<T, OrganizationUpdateArgs<ExtArgs>>): Prisma__OrganizationClient<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Organizations.
     * @param {OrganizationDeleteManyArgs} args - Arguments to filter Organizations to delete.
     * @example
     * // Delete a few Organizations
     * const { count } = await prisma.organization.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends OrganizationDeleteManyArgs>(args?: SelectSubset<T, OrganizationDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Organizations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrganizationUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Organizations
     * const organization = await prisma.organization.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends OrganizationUpdateManyArgs>(args: SelectSubset<T, OrganizationUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Organizations and returns the data updated in the database.
     * @param {OrganizationUpdateManyAndReturnArgs} args - Arguments to update many Organizations.
     * @example
     * // Update many Organizations
     * const organization = await prisma.organization.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Organizations and only return the `id`
     * const organizationWithIdOnly = await prisma.organization.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends OrganizationUpdateManyAndReturnArgs>(args: SelectSubset<T, OrganizationUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Organization.
     * @param {OrganizationUpsertArgs} args - Arguments to update or create a Organization.
     * @example
     * // Update or create a Organization
     * const organization = await prisma.organization.upsert({
     *   create: {
     *     // ... data to create a Organization
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Organization we want to update
     *   }
     * })
     */
    upsert<T extends OrganizationUpsertArgs>(args: SelectSubset<T, OrganizationUpsertArgs<ExtArgs>>): Prisma__OrganizationClient<$Result.GetResult<Prisma.$OrganizationPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Organizations.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrganizationCountArgs} args - Arguments to filter Organizations to count.
     * @example
     * // Count the number of Organizations
     * const count = await prisma.organization.count({
     *   where: {
     *     // ... the filter for the Organizations we want to count
     *   }
     * })
    **/
    count<T extends OrganizationCountArgs>(
      args?: Subset<T, OrganizationCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], OrganizationCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Organization.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrganizationAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends OrganizationAggregateArgs>(args: Subset<T, OrganizationAggregateArgs>): Prisma.PrismaPromise<GetOrganizationAggregateType<T>>

    /**
     * Group by Organization.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OrganizationGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends OrganizationGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: OrganizationGroupByArgs['orderBy'] }
        : { orderBy?: OrganizationGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, OrganizationGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetOrganizationGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Organization model
   */
  readonly fields: OrganizationFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Organization.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__OrganizationClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    org_admins<T extends Organization$org_adminsArgs<ExtArgs> = {}>(args?: Subset<T, Organization$org_adminsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    org_members<T extends Organization$org_membersArgs<ExtArgs> = {}>(args?: Subset<T, Organization$org_membersArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CustomersPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Organization model
   */
  interface OrganizationFieldRefs {
    readonly id: FieldRef<"Organization", 'Int'>
    readonly org_name: FieldRef<"Organization", 'String'>
    readonly org_email: FieldRef<"Organization", 'String'>
    readonly org_phone: FieldRef<"Organization", 'String'>
    readonly org_address: FieldRef<"Organization", 'String'>
    readonly org_city: FieldRef<"Organization", 'String'>
    readonly org_state: FieldRef<"Organization", 'String'>
    readonly org_zipCode: FieldRef<"Organization", 'String'>
    readonly org_province: FieldRef<"Organization", 'String'>
    readonly org_logo: FieldRef<"Organization", 'String'>
    readonly org_password: FieldRef<"Organization", 'String'>
    readonly createdAt: FieldRef<"Organization", 'DateTime'>
    readonly updatedAt: FieldRef<"Organization", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Organization findUnique
   */
  export type OrganizationFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrganizationInclude<ExtArgs> | null
    /**
     * Filter, which Organization to fetch.
     */
    where: OrganizationWhereUniqueInput
  }

  /**
   * Organization findUniqueOrThrow
   */
  export type OrganizationFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrganizationInclude<ExtArgs> | null
    /**
     * Filter, which Organization to fetch.
     */
    where: OrganizationWhereUniqueInput
  }

  /**
   * Organization findFirst
   */
  export type OrganizationFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrganizationInclude<ExtArgs> | null
    /**
     * Filter, which Organization to fetch.
     */
    where?: OrganizationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Organizations to fetch.
     */
    orderBy?: OrganizationOrderByWithRelationInput | OrganizationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Organizations.
     */
    cursor?: OrganizationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Organizations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Organizations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Organizations.
     */
    distinct?: OrganizationScalarFieldEnum | OrganizationScalarFieldEnum[]
  }

  /**
   * Organization findFirstOrThrow
   */
  export type OrganizationFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrganizationInclude<ExtArgs> | null
    /**
     * Filter, which Organization to fetch.
     */
    where?: OrganizationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Organizations to fetch.
     */
    orderBy?: OrganizationOrderByWithRelationInput | OrganizationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Organizations.
     */
    cursor?: OrganizationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Organizations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Organizations.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Organizations.
     */
    distinct?: OrganizationScalarFieldEnum | OrganizationScalarFieldEnum[]
  }

  /**
   * Organization findMany
   */
  export type OrganizationFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrganizationInclude<ExtArgs> | null
    /**
     * Filter, which Organizations to fetch.
     */
    where?: OrganizationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Organizations to fetch.
     */
    orderBy?: OrganizationOrderByWithRelationInput | OrganizationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Organizations.
     */
    cursor?: OrganizationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Organizations from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Organizations.
     */
    skip?: number
    distinct?: OrganizationScalarFieldEnum | OrganizationScalarFieldEnum[]
  }

  /**
   * Organization create
   */
  export type OrganizationCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrganizationInclude<ExtArgs> | null
    /**
     * The data needed to create a Organization.
     */
    data: XOR<OrganizationCreateInput, OrganizationUncheckedCreateInput>
  }

  /**
   * Organization createMany
   */
  export type OrganizationCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Organizations.
     */
    data: OrganizationCreateManyInput | OrganizationCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Organization createManyAndReturn
   */
  export type OrganizationCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * The data used to create many Organizations.
     */
    data: OrganizationCreateManyInput | OrganizationCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Organization update
   */
  export type OrganizationUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrganizationInclude<ExtArgs> | null
    /**
     * The data needed to update a Organization.
     */
    data: XOR<OrganizationUpdateInput, OrganizationUncheckedUpdateInput>
    /**
     * Choose, which Organization to update.
     */
    where: OrganizationWhereUniqueInput
  }

  /**
   * Organization updateMany
   */
  export type OrganizationUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Organizations.
     */
    data: XOR<OrganizationUpdateManyMutationInput, OrganizationUncheckedUpdateManyInput>
    /**
     * Filter which Organizations to update
     */
    where?: OrganizationWhereInput
    /**
     * Limit how many Organizations to update.
     */
    limit?: number
  }

  /**
   * Organization updateManyAndReturn
   */
  export type OrganizationUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * The data used to update Organizations.
     */
    data: XOR<OrganizationUpdateManyMutationInput, OrganizationUncheckedUpdateManyInput>
    /**
     * Filter which Organizations to update
     */
    where?: OrganizationWhereInput
    /**
     * Limit how many Organizations to update.
     */
    limit?: number
  }

  /**
   * Organization upsert
   */
  export type OrganizationUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrganizationInclude<ExtArgs> | null
    /**
     * The filter to search for the Organization to update in case it exists.
     */
    where: OrganizationWhereUniqueInput
    /**
     * In case the Organization found by the `where` argument doesn't exist, create a new Organization with this data.
     */
    create: XOR<OrganizationCreateInput, OrganizationUncheckedCreateInput>
    /**
     * In case the Organization was found with the provided `where` argument, update it with this data.
     */
    update: XOR<OrganizationUpdateInput, OrganizationUncheckedUpdateInput>
  }

  /**
   * Organization delete
   */
  export type OrganizationDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrganizationInclude<ExtArgs> | null
    /**
     * Filter which Organization to delete.
     */
    where: OrganizationWhereUniqueInput
  }

  /**
   * Organization deleteMany
   */
  export type OrganizationDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Organizations to delete
     */
    where?: OrganizationWhereInput
    /**
     * Limit how many Organizations to delete.
     */
    limit?: number
  }

  /**
   * Organization.org_admins
   */
  export type Organization$org_adminsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CustomersInclude<ExtArgs> | null
    where?: CustomersWhereInput
    orderBy?: CustomersOrderByWithRelationInput | CustomersOrderByWithRelationInput[]
    cursor?: CustomersWhereUniqueInput
    take?: number
    skip?: number
    distinct?: CustomersScalarFieldEnum | CustomersScalarFieldEnum[]
  }

  /**
   * Organization.org_members
   */
  export type Organization$org_membersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Customers
     */
    select?: CustomersSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Customers
     */
    omit?: CustomersOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CustomersInclude<ExtArgs> | null
    where?: CustomersWhereInput
    orderBy?: CustomersOrderByWithRelationInput | CustomersOrderByWithRelationInput[]
    cursor?: CustomersWhereUniqueInput
    take?: number
    skip?: number
    distinct?: CustomersScalarFieldEnum | CustomersScalarFieldEnum[]
  }

  /**
   * Organization without action
   */
  export type OrganizationDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Organization
     */
    select?: OrganizationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Organization
     */
    omit?: OrganizationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: OrganizationInclude<ExtArgs> | null
  }


  /**
   * Model CarBrands
   */

  export type AggregateCarBrands = {
    _count: CarBrandsCountAggregateOutputType | null
    _avg: CarBrandsAvgAggregateOutputType | null
    _sum: CarBrandsSumAggregateOutputType | null
    _min: CarBrandsMinAggregateOutputType | null
    _max: CarBrandsMaxAggregateOutputType | null
  }

  export type CarBrandsAvgAggregateOutputType = {
    id: number | null
  }

  export type CarBrandsSumAggregateOutputType = {
    id: number | null
  }

  export type CarBrandsMinAggregateOutputType = {
    id: number | null
    name: string | null
    country: string | null
    description: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type CarBrandsMaxAggregateOutputType = {
    id: number | null
    name: string | null
    country: string | null
    description: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type CarBrandsCountAggregateOutputType = {
    id: number
    name: number
    country: number
    description: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type CarBrandsAvgAggregateInputType = {
    id?: true
  }

  export type CarBrandsSumAggregateInputType = {
    id?: true
  }

  export type CarBrandsMinAggregateInputType = {
    id?: true
    name?: true
    country?: true
    description?: true
    createdAt?: true
    updatedAt?: true
  }

  export type CarBrandsMaxAggregateInputType = {
    id?: true
    name?: true
    country?: true
    description?: true
    createdAt?: true
    updatedAt?: true
  }

  export type CarBrandsCountAggregateInputType = {
    id?: true
    name?: true
    country?: true
    description?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type CarBrandsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CarBrands to aggregate.
     */
    where?: CarBrandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CarBrands to fetch.
     */
    orderBy?: CarBrandsOrderByWithRelationInput | CarBrandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CarBrandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CarBrands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CarBrands.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned CarBrands
    **/
    _count?: true | CarBrandsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CarBrandsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CarBrandsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CarBrandsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CarBrandsMaxAggregateInputType
  }

  export type GetCarBrandsAggregateType<T extends CarBrandsAggregateArgs> = {
        [P in keyof T & keyof AggregateCarBrands]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCarBrands[P]>
      : GetScalarType<T[P], AggregateCarBrands[P]>
  }




  export type CarBrandsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CarBrandsWhereInput
    orderBy?: CarBrandsOrderByWithAggregationInput | CarBrandsOrderByWithAggregationInput[]
    by: CarBrandsScalarFieldEnum[] | CarBrandsScalarFieldEnum
    having?: CarBrandsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CarBrandsCountAggregateInputType | true
    _avg?: CarBrandsAvgAggregateInputType
    _sum?: CarBrandsSumAggregateInputType
    _min?: CarBrandsMinAggregateInputType
    _max?: CarBrandsMaxAggregateInputType
  }

  export type CarBrandsGroupByOutputType = {
    id: number
    name: string
    country: string | null
    description: string | null
    createdAt: Date
    updatedAt: Date
    _count: CarBrandsCountAggregateOutputType | null
    _avg: CarBrandsAvgAggregateOutputType | null
    _sum: CarBrandsSumAggregateOutputType | null
    _min: CarBrandsMinAggregateOutputType | null
    _max: CarBrandsMaxAggregateOutputType | null
  }

  type GetCarBrandsGroupByPayload<T extends CarBrandsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CarBrandsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CarBrandsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CarBrandsGroupByOutputType[P]>
            : GetScalarType<T[P], CarBrandsGroupByOutputType[P]>
        }
      >
    >


  export type CarBrandsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    country?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    CarModels?: boolean | CarBrands$CarModelsArgs<ExtArgs>
    _count?: boolean | CarBrandsCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["carBrands"]>

  export type CarBrandsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    country?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["carBrands"]>

  export type CarBrandsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    country?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["carBrands"]>

  export type CarBrandsSelectScalar = {
    id?: boolean
    name?: boolean
    country?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type CarBrandsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "country" | "description" | "createdAt" | "updatedAt", ExtArgs["result"]["carBrands"]>
  export type CarBrandsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    CarModels?: boolean | CarBrands$CarModelsArgs<ExtArgs>
    _count?: boolean | CarBrandsCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type CarBrandsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type CarBrandsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $CarBrandsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "CarBrands"
    objects: {
      CarModels: Prisma.$CarModelsPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      country: string | null
      description: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["carBrands"]>
    composites: {}
  }

  type CarBrandsGetPayload<S extends boolean | null | undefined | CarBrandsDefaultArgs> = $Result.GetResult<Prisma.$CarBrandsPayload, S>

  type CarBrandsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<CarBrandsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CarBrandsCountAggregateInputType | true
    }

  export interface CarBrandsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['CarBrands'], meta: { name: 'CarBrands' } }
    /**
     * Find zero or one CarBrands that matches the filter.
     * @param {CarBrandsFindUniqueArgs} args - Arguments to find a CarBrands
     * @example
     * // Get one CarBrands
     * const carBrands = await prisma.carBrands.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CarBrandsFindUniqueArgs>(args: SelectSubset<T, CarBrandsFindUniqueArgs<ExtArgs>>): Prisma__CarBrandsClient<$Result.GetResult<Prisma.$CarBrandsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one CarBrands that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CarBrandsFindUniqueOrThrowArgs} args - Arguments to find a CarBrands
     * @example
     * // Get one CarBrands
     * const carBrands = await prisma.carBrands.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CarBrandsFindUniqueOrThrowArgs>(args: SelectSubset<T, CarBrandsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__CarBrandsClient<$Result.GetResult<Prisma.$CarBrandsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CarBrands that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarBrandsFindFirstArgs} args - Arguments to find a CarBrands
     * @example
     * // Get one CarBrands
     * const carBrands = await prisma.carBrands.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CarBrandsFindFirstArgs>(args?: SelectSubset<T, CarBrandsFindFirstArgs<ExtArgs>>): Prisma__CarBrandsClient<$Result.GetResult<Prisma.$CarBrandsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CarBrands that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarBrandsFindFirstOrThrowArgs} args - Arguments to find a CarBrands
     * @example
     * // Get one CarBrands
     * const carBrands = await prisma.carBrands.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CarBrandsFindFirstOrThrowArgs>(args?: SelectSubset<T, CarBrandsFindFirstOrThrowArgs<ExtArgs>>): Prisma__CarBrandsClient<$Result.GetResult<Prisma.$CarBrandsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more CarBrands that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarBrandsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all CarBrands
     * const carBrands = await prisma.carBrands.findMany()
     * 
     * // Get first 10 CarBrands
     * const carBrands = await prisma.carBrands.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const carBrandsWithIdOnly = await prisma.carBrands.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends CarBrandsFindManyArgs>(args?: SelectSubset<T, CarBrandsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CarBrandsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a CarBrands.
     * @param {CarBrandsCreateArgs} args - Arguments to create a CarBrands.
     * @example
     * // Create one CarBrands
     * const CarBrands = await prisma.carBrands.create({
     *   data: {
     *     // ... data to create a CarBrands
     *   }
     * })
     * 
     */
    create<T extends CarBrandsCreateArgs>(args: SelectSubset<T, CarBrandsCreateArgs<ExtArgs>>): Prisma__CarBrandsClient<$Result.GetResult<Prisma.$CarBrandsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many CarBrands.
     * @param {CarBrandsCreateManyArgs} args - Arguments to create many CarBrands.
     * @example
     * // Create many CarBrands
     * const carBrands = await prisma.carBrands.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends CarBrandsCreateManyArgs>(args?: SelectSubset<T, CarBrandsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many CarBrands and returns the data saved in the database.
     * @param {CarBrandsCreateManyAndReturnArgs} args - Arguments to create many CarBrands.
     * @example
     * // Create many CarBrands
     * const carBrands = await prisma.carBrands.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many CarBrands and only return the `id`
     * const carBrandsWithIdOnly = await prisma.carBrands.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends CarBrandsCreateManyAndReturnArgs>(args?: SelectSubset<T, CarBrandsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CarBrandsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a CarBrands.
     * @param {CarBrandsDeleteArgs} args - Arguments to delete one CarBrands.
     * @example
     * // Delete one CarBrands
     * const CarBrands = await prisma.carBrands.delete({
     *   where: {
     *     // ... filter to delete one CarBrands
     *   }
     * })
     * 
     */
    delete<T extends CarBrandsDeleteArgs>(args: SelectSubset<T, CarBrandsDeleteArgs<ExtArgs>>): Prisma__CarBrandsClient<$Result.GetResult<Prisma.$CarBrandsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one CarBrands.
     * @param {CarBrandsUpdateArgs} args - Arguments to update one CarBrands.
     * @example
     * // Update one CarBrands
     * const carBrands = await prisma.carBrands.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends CarBrandsUpdateArgs>(args: SelectSubset<T, CarBrandsUpdateArgs<ExtArgs>>): Prisma__CarBrandsClient<$Result.GetResult<Prisma.$CarBrandsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more CarBrands.
     * @param {CarBrandsDeleteManyArgs} args - Arguments to filter CarBrands to delete.
     * @example
     * // Delete a few CarBrands
     * const { count } = await prisma.carBrands.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends CarBrandsDeleteManyArgs>(args?: SelectSubset<T, CarBrandsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CarBrands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarBrandsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many CarBrands
     * const carBrands = await prisma.carBrands.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends CarBrandsUpdateManyArgs>(args: SelectSubset<T, CarBrandsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CarBrands and returns the data updated in the database.
     * @param {CarBrandsUpdateManyAndReturnArgs} args - Arguments to update many CarBrands.
     * @example
     * // Update many CarBrands
     * const carBrands = await prisma.carBrands.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more CarBrands and only return the `id`
     * const carBrandsWithIdOnly = await prisma.carBrands.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends CarBrandsUpdateManyAndReturnArgs>(args: SelectSubset<T, CarBrandsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CarBrandsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one CarBrands.
     * @param {CarBrandsUpsertArgs} args - Arguments to update or create a CarBrands.
     * @example
     * // Update or create a CarBrands
     * const carBrands = await prisma.carBrands.upsert({
     *   create: {
     *     // ... data to create a CarBrands
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the CarBrands we want to update
     *   }
     * })
     */
    upsert<T extends CarBrandsUpsertArgs>(args: SelectSubset<T, CarBrandsUpsertArgs<ExtArgs>>): Prisma__CarBrandsClient<$Result.GetResult<Prisma.$CarBrandsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of CarBrands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarBrandsCountArgs} args - Arguments to filter CarBrands to count.
     * @example
     * // Count the number of CarBrands
     * const count = await prisma.carBrands.count({
     *   where: {
     *     // ... the filter for the CarBrands we want to count
     *   }
     * })
    **/
    count<T extends CarBrandsCountArgs>(
      args?: Subset<T, CarBrandsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CarBrandsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a CarBrands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarBrandsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CarBrandsAggregateArgs>(args: Subset<T, CarBrandsAggregateArgs>): Prisma.PrismaPromise<GetCarBrandsAggregateType<T>>

    /**
     * Group by CarBrands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarBrandsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CarBrandsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CarBrandsGroupByArgs['orderBy'] }
        : { orderBy?: CarBrandsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CarBrandsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCarBrandsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the CarBrands model
   */
  readonly fields: CarBrandsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for CarBrands.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__CarBrandsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    CarModels<T extends CarBrands$CarModelsArgs<ExtArgs> = {}>(args?: Subset<T, CarBrands$CarModelsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CarModelsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the CarBrands model
   */
  interface CarBrandsFieldRefs {
    readonly id: FieldRef<"CarBrands", 'Int'>
    readonly name: FieldRef<"CarBrands", 'String'>
    readonly country: FieldRef<"CarBrands", 'String'>
    readonly description: FieldRef<"CarBrands", 'String'>
    readonly createdAt: FieldRef<"CarBrands", 'DateTime'>
    readonly updatedAt: FieldRef<"CarBrands", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * CarBrands findUnique
   */
  export type CarBrandsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrands
     */
    select?: CarBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarBrands
     */
    omit?: CarBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarBrandsInclude<ExtArgs> | null
    /**
     * Filter, which CarBrands to fetch.
     */
    where: CarBrandsWhereUniqueInput
  }

  /**
   * CarBrands findUniqueOrThrow
   */
  export type CarBrandsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrands
     */
    select?: CarBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarBrands
     */
    omit?: CarBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarBrandsInclude<ExtArgs> | null
    /**
     * Filter, which CarBrands to fetch.
     */
    where: CarBrandsWhereUniqueInput
  }

  /**
   * CarBrands findFirst
   */
  export type CarBrandsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrands
     */
    select?: CarBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarBrands
     */
    omit?: CarBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarBrandsInclude<ExtArgs> | null
    /**
     * Filter, which CarBrands to fetch.
     */
    where?: CarBrandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CarBrands to fetch.
     */
    orderBy?: CarBrandsOrderByWithRelationInput | CarBrandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CarBrands.
     */
    cursor?: CarBrandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CarBrands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CarBrands.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CarBrands.
     */
    distinct?: CarBrandsScalarFieldEnum | CarBrandsScalarFieldEnum[]
  }

  /**
   * CarBrands findFirstOrThrow
   */
  export type CarBrandsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrands
     */
    select?: CarBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarBrands
     */
    omit?: CarBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarBrandsInclude<ExtArgs> | null
    /**
     * Filter, which CarBrands to fetch.
     */
    where?: CarBrandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CarBrands to fetch.
     */
    orderBy?: CarBrandsOrderByWithRelationInput | CarBrandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CarBrands.
     */
    cursor?: CarBrandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CarBrands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CarBrands.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CarBrands.
     */
    distinct?: CarBrandsScalarFieldEnum | CarBrandsScalarFieldEnum[]
  }

  /**
   * CarBrands findMany
   */
  export type CarBrandsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrands
     */
    select?: CarBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarBrands
     */
    omit?: CarBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarBrandsInclude<ExtArgs> | null
    /**
     * Filter, which CarBrands to fetch.
     */
    where?: CarBrandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CarBrands to fetch.
     */
    orderBy?: CarBrandsOrderByWithRelationInput | CarBrandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing CarBrands.
     */
    cursor?: CarBrandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CarBrands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CarBrands.
     */
    skip?: number
    distinct?: CarBrandsScalarFieldEnum | CarBrandsScalarFieldEnum[]
  }

  /**
   * CarBrands create
   */
  export type CarBrandsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrands
     */
    select?: CarBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarBrands
     */
    omit?: CarBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarBrandsInclude<ExtArgs> | null
    /**
     * The data needed to create a CarBrands.
     */
    data: XOR<CarBrandsCreateInput, CarBrandsUncheckedCreateInput>
  }

  /**
   * CarBrands createMany
   */
  export type CarBrandsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many CarBrands.
     */
    data: CarBrandsCreateManyInput | CarBrandsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * CarBrands createManyAndReturn
   */
  export type CarBrandsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrands
     */
    select?: CarBrandsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the CarBrands
     */
    omit?: CarBrandsOmit<ExtArgs> | null
    /**
     * The data used to create many CarBrands.
     */
    data: CarBrandsCreateManyInput | CarBrandsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * CarBrands update
   */
  export type CarBrandsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrands
     */
    select?: CarBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarBrands
     */
    omit?: CarBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarBrandsInclude<ExtArgs> | null
    /**
     * The data needed to update a CarBrands.
     */
    data: XOR<CarBrandsUpdateInput, CarBrandsUncheckedUpdateInput>
    /**
     * Choose, which CarBrands to update.
     */
    where: CarBrandsWhereUniqueInput
  }

  /**
   * CarBrands updateMany
   */
  export type CarBrandsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update CarBrands.
     */
    data: XOR<CarBrandsUpdateManyMutationInput, CarBrandsUncheckedUpdateManyInput>
    /**
     * Filter which CarBrands to update
     */
    where?: CarBrandsWhereInput
    /**
     * Limit how many CarBrands to update.
     */
    limit?: number
  }

  /**
   * CarBrands updateManyAndReturn
   */
  export type CarBrandsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrands
     */
    select?: CarBrandsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the CarBrands
     */
    omit?: CarBrandsOmit<ExtArgs> | null
    /**
     * The data used to update CarBrands.
     */
    data: XOR<CarBrandsUpdateManyMutationInput, CarBrandsUncheckedUpdateManyInput>
    /**
     * Filter which CarBrands to update
     */
    where?: CarBrandsWhereInput
    /**
     * Limit how many CarBrands to update.
     */
    limit?: number
  }

  /**
   * CarBrands upsert
   */
  export type CarBrandsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrands
     */
    select?: CarBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarBrands
     */
    omit?: CarBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarBrandsInclude<ExtArgs> | null
    /**
     * The filter to search for the CarBrands to update in case it exists.
     */
    where: CarBrandsWhereUniqueInput
    /**
     * In case the CarBrands found by the `where` argument doesn't exist, create a new CarBrands with this data.
     */
    create: XOR<CarBrandsCreateInput, CarBrandsUncheckedCreateInput>
    /**
     * In case the CarBrands was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CarBrandsUpdateInput, CarBrandsUncheckedUpdateInput>
  }

  /**
   * CarBrands delete
   */
  export type CarBrandsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrands
     */
    select?: CarBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarBrands
     */
    omit?: CarBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarBrandsInclude<ExtArgs> | null
    /**
     * Filter which CarBrands to delete.
     */
    where: CarBrandsWhereUniqueInput
  }

  /**
   * CarBrands deleteMany
   */
  export type CarBrandsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CarBrands to delete
     */
    where?: CarBrandsWhereInput
    /**
     * Limit how many CarBrands to delete.
     */
    limit?: number
  }

  /**
   * CarBrands.CarModels
   */
  export type CarBrands$CarModelsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsInclude<ExtArgs> | null
    where?: CarModelsWhereInput
    orderBy?: CarModelsOrderByWithRelationInput | CarModelsOrderByWithRelationInput[]
    cursor?: CarModelsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: CarModelsScalarFieldEnum | CarModelsScalarFieldEnum[]
  }

  /**
   * CarBrands without action
   */
  export type CarBrandsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarBrands
     */
    select?: CarBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarBrands
     */
    omit?: CarBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarBrandsInclude<ExtArgs> | null
  }


  /**
   * Model CarModels
   */

  export type AggregateCarModels = {
    _count: CarModelsCountAggregateOutputType | null
    _avg: CarModelsAvgAggregateOutputType | null
    _sum: CarModelsSumAggregateOutputType | null
    _min: CarModelsMinAggregateOutputType | null
    _max: CarModelsMaxAggregateOutputType | null
  }

  export type CarModelsAvgAggregateOutputType = {
    id: number | null
    brandId: number | null
    oil_carbon_per_unit: number | null
    electric_carbon_per_unit: number | null
    cubic_centimeter: number | null
  }

  export type CarModelsSumAggregateOutputType = {
    id: number | null
    brandId: number | null
    oil_carbon_per_unit: number | null
    electric_carbon_per_unit: number | null
    cubic_centimeter: number | null
  }

  export type CarModelsMinAggregateOutputType = {
    id: number | null
    brandId: number | null
    name: string | null
    description: string | null
    power_type: string | null
    oil_carbon_per_unit: number | null
    electric_carbon_per_unit: number | null
    cubic_centimeter: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type CarModelsMaxAggregateOutputType = {
    id: number | null
    brandId: number | null
    name: string | null
    description: string | null
    power_type: string | null
    oil_carbon_per_unit: number | null
    electric_carbon_per_unit: number | null
    cubic_centimeter: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type CarModelsCountAggregateOutputType = {
    id: number
    brandId: number
    name: number
    description: number
    power_type: number
    oil_type: number
    oil_carbon_per_unit: number
    electric_carbon_per_unit: number
    cubic_centimeter: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type CarModelsAvgAggregateInputType = {
    id?: true
    brandId?: true
    oil_carbon_per_unit?: true
    electric_carbon_per_unit?: true
    cubic_centimeter?: true
  }

  export type CarModelsSumAggregateInputType = {
    id?: true
    brandId?: true
    oil_carbon_per_unit?: true
    electric_carbon_per_unit?: true
    cubic_centimeter?: true
  }

  export type CarModelsMinAggregateInputType = {
    id?: true
    brandId?: true
    name?: true
    description?: true
    power_type?: true
    oil_carbon_per_unit?: true
    electric_carbon_per_unit?: true
    cubic_centimeter?: true
    createdAt?: true
    updatedAt?: true
  }

  export type CarModelsMaxAggregateInputType = {
    id?: true
    brandId?: true
    name?: true
    description?: true
    power_type?: true
    oil_carbon_per_unit?: true
    electric_carbon_per_unit?: true
    cubic_centimeter?: true
    createdAt?: true
    updatedAt?: true
  }

  export type CarModelsCountAggregateInputType = {
    id?: true
    brandId?: true
    name?: true
    description?: true
    power_type?: true
    oil_type?: true
    oil_carbon_per_unit?: true
    electric_carbon_per_unit?: true
    cubic_centimeter?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type CarModelsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CarModels to aggregate.
     */
    where?: CarModelsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CarModels to fetch.
     */
    orderBy?: CarModelsOrderByWithRelationInput | CarModelsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CarModelsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CarModels from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CarModels.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned CarModels
    **/
    _count?: true | CarModelsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CarModelsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CarModelsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CarModelsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CarModelsMaxAggregateInputType
  }

  export type GetCarModelsAggregateType<T extends CarModelsAggregateArgs> = {
        [P in keyof T & keyof AggregateCarModels]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCarModels[P]>
      : GetScalarType<T[P], AggregateCarModels[P]>
  }




  export type CarModelsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CarModelsWhereInput
    orderBy?: CarModelsOrderByWithAggregationInput | CarModelsOrderByWithAggregationInput[]
    by: CarModelsScalarFieldEnum[] | CarModelsScalarFieldEnum
    having?: CarModelsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CarModelsCountAggregateInputType | true
    _avg?: CarModelsAvgAggregateInputType
    _sum?: CarModelsSumAggregateInputType
    _min?: CarModelsMinAggregateInputType
    _max?: CarModelsMaxAggregateInputType
  }

  export type CarModelsGroupByOutputType = {
    id: number
    brandId: number
    name: string
    description: string | null
    power_type: string | null
    oil_type: $Enums.CarOilTypes[]
    oil_carbon_per_unit: number | null
    electric_carbon_per_unit: number | null
    cubic_centimeter: number | null
    createdAt: Date
    updatedAt: Date
    _count: CarModelsCountAggregateOutputType | null
    _avg: CarModelsAvgAggregateOutputType | null
    _sum: CarModelsSumAggregateOutputType | null
    _min: CarModelsMinAggregateOutputType | null
    _max: CarModelsMaxAggregateOutputType | null
  }

  type GetCarModelsGroupByPayload<T extends CarModelsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CarModelsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CarModelsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CarModelsGroupByOutputType[P]>
            : GetScalarType<T[P], CarModelsGroupByOutputType[P]>
        }
      >
    >


  export type CarModelsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    brandId?: boolean
    name?: boolean
    description?: boolean
    power_type?: boolean
    oil_type?: boolean
    oil_carbon_per_unit?: boolean
    electric_carbon_per_unit?: boolean
    cubic_centimeter?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    brand?: boolean | CarBrandsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["carModels"]>

  export type CarModelsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    brandId?: boolean
    name?: boolean
    description?: boolean
    power_type?: boolean
    oil_type?: boolean
    oil_carbon_per_unit?: boolean
    electric_carbon_per_unit?: boolean
    cubic_centimeter?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    brand?: boolean | CarBrandsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["carModels"]>

  export type CarModelsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    brandId?: boolean
    name?: boolean
    description?: boolean
    power_type?: boolean
    oil_type?: boolean
    oil_carbon_per_unit?: boolean
    electric_carbon_per_unit?: boolean
    cubic_centimeter?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    brand?: boolean | CarBrandsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["carModels"]>

  export type CarModelsSelectScalar = {
    id?: boolean
    brandId?: boolean
    name?: boolean
    description?: boolean
    power_type?: boolean
    oil_type?: boolean
    oil_carbon_per_unit?: boolean
    electric_carbon_per_unit?: boolean
    cubic_centimeter?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type CarModelsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "brandId" | "name" | "description" | "power_type" | "oil_type" | "oil_carbon_per_unit" | "electric_carbon_per_unit" | "cubic_centimeter" | "createdAt" | "updatedAt", ExtArgs["result"]["carModels"]>
  export type CarModelsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    brand?: boolean | CarBrandsDefaultArgs<ExtArgs>
  }
  export type CarModelsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    brand?: boolean | CarBrandsDefaultArgs<ExtArgs>
  }
  export type CarModelsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    brand?: boolean | CarBrandsDefaultArgs<ExtArgs>
  }

  export type $CarModelsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "CarModels"
    objects: {
      brand: Prisma.$CarBrandsPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      brandId: number
      name: string
      description: string | null
      power_type: string | null
      oil_type: $Enums.CarOilTypes[]
      oil_carbon_per_unit: number | null
      electric_carbon_per_unit: number | null
      cubic_centimeter: number | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["carModels"]>
    composites: {}
  }

  type CarModelsGetPayload<S extends boolean | null | undefined | CarModelsDefaultArgs> = $Result.GetResult<Prisma.$CarModelsPayload, S>

  type CarModelsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<CarModelsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CarModelsCountAggregateInputType | true
    }

  export interface CarModelsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['CarModels'], meta: { name: 'CarModels' } }
    /**
     * Find zero or one CarModels that matches the filter.
     * @param {CarModelsFindUniqueArgs} args - Arguments to find a CarModels
     * @example
     * // Get one CarModels
     * const carModels = await prisma.carModels.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CarModelsFindUniqueArgs>(args: SelectSubset<T, CarModelsFindUniqueArgs<ExtArgs>>): Prisma__CarModelsClient<$Result.GetResult<Prisma.$CarModelsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one CarModels that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CarModelsFindUniqueOrThrowArgs} args - Arguments to find a CarModels
     * @example
     * // Get one CarModels
     * const carModels = await prisma.carModels.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CarModelsFindUniqueOrThrowArgs>(args: SelectSubset<T, CarModelsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__CarModelsClient<$Result.GetResult<Prisma.$CarModelsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CarModels that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarModelsFindFirstArgs} args - Arguments to find a CarModels
     * @example
     * // Get one CarModels
     * const carModels = await prisma.carModels.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CarModelsFindFirstArgs>(args?: SelectSubset<T, CarModelsFindFirstArgs<ExtArgs>>): Prisma__CarModelsClient<$Result.GetResult<Prisma.$CarModelsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CarModels that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarModelsFindFirstOrThrowArgs} args - Arguments to find a CarModels
     * @example
     * // Get one CarModels
     * const carModels = await prisma.carModels.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CarModelsFindFirstOrThrowArgs>(args?: SelectSubset<T, CarModelsFindFirstOrThrowArgs<ExtArgs>>): Prisma__CarModelsClient<$Result.GetResult<Prisma.$CarModelsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more CarModels that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarModelsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all CarModels
     * const carModels = await prisma.carModels.findMany()
     * 
     * // Get first 10 CarModels
     * const carModels = await prisma.carModels.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const carModelsWithIdOnly = await prisma.carModels.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends CarModelsFindManyArgs>(args?: SelectSubset<T, CarModelsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CarModelsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a CarModels.
     * @param {CarModelsCreateArgs} args - Arguments to create a CarModels.
     * @example
     * // Create one CarModels
     * const CarModels = await prisma.carModels.create({
     *   data: {
     *     // ... data to create a CarModels
     *   }
     * })
     * 
     */
    create<T extends CarModelsCreateArgs>(args: SelectSubset<T, CarModelsCreateArgs<ExtArgs>>): Prisma__CarModelsClient<$Result.GetResult<Prisma.$CarModelsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many CarModels.
     * @param {CarModelsCreateManyArgs} args - Arguments to create many CarModels.
     * @example
     * // Create many CarModels
     * const carModels = await prisma.carModels.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends CarModelsCreateManyArgs>(args?: SelectSubset<T, CarModelsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many CarModels and returns the data saved in the database.
     * @param {CarModelsCreateManyAndReturnArgs} args - Arguments to create many CarModels.
     * @example
     * // Create many CarModels
     * const carModels = await prisma.carModels.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many CarModels and only return the `id`
     * const carModelsWithIdOnly = await prisma.carModels.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends CarModelsCreateManyAndReturnArgs>(args?: SelectSubset<T, CarModelsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CarModelsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a CarModels.
     * @param {CarModelsDeleteArgs} args - Arguments to delete one CarModels.
     * @example
     * // Delete one CarModels
     * const CarModels = await prisma.carModels.delete({
     *   where: {
     *     // ... filter to delete one CarModels
     *   }
     * })
     * 
     */
    delete<T extends CarModelsDeleteArgs>(args: SelectSubset<T, CarModelsDeleteArgs<ExtArgs>>): Prisma__CarModelsClient<$Result.GetResult<Prisma.$CarModelsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one CarModels.
     * @param {CarModelsUpdateArgs} args - Arguments to update one CarModels.
     * @example
     * // Update one CarModels
     * const carModels = await prisma.carModels.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends CarModelsUpdateArgs>(args: SelectSubset<T, CarModelsUpdateArgs<ExtArgs>>): Prisma__CarModelsClient<$Result.GetResult<Prisma.$CarModelsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more CarModels.
     * @param {CarModelsDeleteManyArgs} args - Arguments to filter CarModels to delete.
     * @example
     * // Delete a few CarModels
     * const { count } = await prisma.carModels.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends CarModelsDeleteManyArgs>(args?: SelectSubset<T, CarModelsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CarModels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarModelsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many CarModels
     * const carModels = await prisma.carModels.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends CarModelsUpdateManyArgs>(args: SelectSubset<T, CarModelsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CarModels and returns the data updated in the database.
     * @param {CarModelsUpdateManyAndReturnArgs} args - Arguments to update many CarModels.
     * @example
     * // Update many CarModels
     * const carModels = await prisma.carModels.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more CarModels and only return the `id`
     * const carModelsWithIdOnly = await prisma.carModels.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends CarModelsUpdateManyAndReturnArgs>(args: SelectSubset<T, CarModelsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CarModelsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one CarModels.
     * @param {CarModelsUpsertArgs} args - Arguments to update or create a CarModels.
     * @example
     * // Update or create a CarModels
     * const carModels = await prisma.carModels.upsert({
     *   create: {
     *     // ... data to create a CarModels
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the CarModels we want to update
     *   }
     * })
     */
    upsert<T extends CarModelsUpsertArgs>(args: SelectSubset<T, CarModelsUpsertArgs<ExtArgs>>): Prisma__CarModelsClient<$Result.GetResult<Prisma.$CarModelsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of CarModels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarModelsCountArgs} args - Arguments to filter CarModels to count.
     * @example
     * // Count the number of CarModels
     * const count = await prisma.carModels.count({
     *   where: {
     *     // ... the filter for the CarModels we want to count
     *   }
     * })
    **/
    count<T extends CarModelsCountArgs>(
      args?: Subset<T, CarModelsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CarModelsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a CarModels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarModelsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CarModelsAggregateArgs>(args: Subset<T, CarModelsAggregateArgs>): Prisma.PrismaPromise<GetCarModelsAggregateType<T>>

    /**
     * Group by CarModels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CarModelsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CarModelsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CarModelsGroupByArgs['orderBy'] }
        : { orderBy?: CarModelsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CarModelsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCarModelsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the CarModels model
   */
  readonly fields: CarModelsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for CarModels.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__CarModelsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    brand<T extends CarBrandsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CarBrandsDefaultArgs<ExtArgs>>): Prisma__CarBrandsClient<$Result.GetResult<Prisma.$CarBrandsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the CarModels model
   */
  interface CarModelsFieldRefs {
    readonly id: FieldRef<"CarModels", 'Int'>
    readonly brandId: FieldRef<"CarModels", 'Int'>
    readonly name: FieldRef<"CarModels", 'String'>
    readonly description: FieldRef<"CarModels", 'String'>
    readonly power_type: FieldRef<"CarModels", 'String'>
    readonly oil_type: FieldRef<"CarModels", 'CarOilTypes[]'>
    readonly oil_carbon_per_unit: FieldRef<"CarModels", 'Float'>
    readonly electric_carbon_per_unit: FieldRef<"CarModels", 'Float'>
    readonly cubic_centimeter: FieldRef<"CarModels", 'Int'>
    readonly createdAt: FieldRef<"CarModels", 'DateTime'>
    readonly updatedAt: FieldRef<"CarModels", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * CarModels findUnique
   */
  export type CarModelsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsInclude<ExtArgs> | null
    /**
     * Filter, which CarModels to fetch.
     */
    where: CarModelsWhereUniqueInput
  }

  /**
   * CarModels findUniqueOrThrow
   */
  export type CarModelsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsInclude<ExtArgs> | null
    /**
     * Filter, which CarModels to fetch.
     */
    where: CarModelsWhereUniqueInput
  }

  /**
   * CarModels findFirst
   */
  export type CarModelsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsInclude<ExtArgs> | null
    /**
     * Filter, which CarModels to fetch.
     */
    where?: CarModelsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CarModels to fetch.
     */
    orderBy?: CarModelsOrderByWithRelationInput | CarModelsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CarModels.
     */
    cursor?: CarModelsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CarModels from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CarModels.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CarModels.
     */
    distinct?: CarModelsScalarFieldEnum | CarModelsScalarFieldEnum[]
  }

  /**
   * CarModels findFirstOrThrow
   */
  export type CarModelsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsInclude<ExtArgs> | null
    /**
     * Filter, which CarModels to fetch.
     */
    where?: CarModelsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CarModels to fetch.
     */
    orderBy?: CarModelsOrderByWithRelationInput | CarModelsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CarModels.
     */
    cursor?: CarModelsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CarModels from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CarModels.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CarModels.
     */
    distinct?: CarModelsScalarFieldEnum | CarModelsScalarFieldEnum[]
  }

  /**
   * CarModels findMany
   */
  export type CarModelsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsInclude<ExtArgs> | null
    /**
     * Filter, which CarModels to fetch.
     */
    where?: CarModelsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CarModels to fetch.
     */
    orderBy?: CarModelsOrderByWithRelationInput | CarModelsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing CarModels.
     */
    cursor?: CarModelsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CarModels from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CarModels.
     */
    skip?: number
    distinct?: CarModelsScalarFieldEnum | CarModelsScalarFieldEnum[]
  }

  /**
   * CarModels create
   */
  export type CarModelsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsInclude<ExtArgs> | null
    /**
     * The data needed to create a CarModels.
     */
    data: XOR<CarModelsCreateInput, CarModelsUncheckedCreateInput>
  }

  /**
   * CarModels createMany
   */
  export type CarModelsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many CarModels.
     */
    data: CarModelsCreateManyInput | CarModelsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * CarModels createManyAndReturn
   */
  export type CarModelsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * The data used to create many CarModels.
     */
    data: CarModelsCreateManyInput | CarModelsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * CarModels update
   */
  export type CarModelsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsInclude<ExtArgs> | null
    /**
     * The data needed to update a CarModels.
     */
    data: XOR<CarModelsUpdateInput, CarModelsUncheckedUpdateInput>
    /**
     * Choose, which CarModels to update.
     */
    where: CarModelsWhereUniqueInput
  }

  /**
   * CarModels updateMany
   */
  export type CarModelsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update CarModels.
     */
    data: XOR<CarModelsUpdateManyMutationInput, CarModelsUncheckedUpdateManyInput>
    /**
     * Filter which CarModels to update
     */
    where?: CarModelsWhereInput
    /**
     * Limit how many CarModels to update.
     */
    limit?: number
  }

  /**
   * CarModels updateManyAndReturn
   */
  export type CarModelsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * The data used to update CarModels.
     */
    data: XOR<CarModelsUpdateManyMutationInput, CarModelsUncheckedUpdateManyInput>
    /**
     * Filter which CarModels to update
     */
    where?: CarModelsWhereInput
    /**
     * Limit how many CarModels to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * CarModels upsert
   */
  export type CarModelsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsInclude<ExtArgs> | null
    /**
     * The filter to search for the CarModels to update in case it exists.
     */
    where: CarModelsWhereUniqueInput
    /**
     * In case the CarModels found by the `where` argument doesn't exist, create a new CarModels with this data.
     */
    create: XOR<CarModelsCreateInput, CarModelsUncheckedCreateInput>
    /**
     * In case the CarModels was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CarModelsUpdateInput, CarModelsUncheckedUpdateInput>
  }

  /**
   * CarModels delete
   */
  export type CarModelsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsInclude<ExtArgs> | null
    /**
     * Filter which CarModels to delete.
     */
    where: CarModelsWhereUniqueInput
  }

  /**
   * CarModels deleteMany
   */
  export type CarModelsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CarModels to delete
     */
    where?: CarModelsWhereInput
    /**
     * Limit how many CarModels to delete.
     */
    limit?: number
  }

  /**
   * CarModels without action
   */
  export type CarModelsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CarModels
     */
    select?: CarModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CarModels
     */
    omit?: CarModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CarModelsInclude<ExtArgs> | null
  }


  /**
   * Model MotorcycleBrands
   */

  export type AggregateMotorcycleBrands = {
    _count: MotorcycleBrandsCountAggregateOutputType | null
    _avg: MotorcycleBrandsAvgAggregateOutputType | null
    _sum: MotorcycleBrandsSumAggregateOutputType | null
    _min: MotorcycleBrandsMinAggregateOutputType | null
    _max: MotorcycleBrandsMaxAggregateOutputType | null
  }

  export type MotorcycleBrandsAvgAggregateOutputType = {
    id: number | null
  }

  export type MotorcycleBrandsSumAggregateOutputType = {
    id: number | null
  }

  export type MotorcycleBrandsMinAggregateOutputType = {
    id: number | null
    name: string | null
    country: string | null
    description: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type MotorcycleBrandsMaxAggregateOutputType = {
    id: number | null
    name: string | null
    country: string | null
    description: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type MotorcycleBrandsCountAggregateOutputType = {
    id: number
    name: number
    country: number
    description: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type MotorcycleBrandsAvgAggregateInputType = {
    id?: true
  }

  export type MotorcycleBrandsSumAggregateInputType = {
    id?: true
  }

  export type MotorcycleBrandsMinAggregateInputType = {
    id?: true
    name?: true
    country?: true
    description?: true
    createdAt?: true
    updatedAt?: true
  }

  export type MotorcycleBrandsMaxAggregateInputType = {
    id?: true
    name?: true
    country?: true
    description?: true
    createdAt?: true
    updatedAt?: true
  }

  export type MotorcycleBrandsCountAggregateInputType = {
    id?: true
    name?: true
    country?: true
    description?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type MotorcycleBrandsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MotorcycleBrands to aggregate.
     */
    where?: MotorcycleBrandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MotorcycleBrands to fetch.
     */
    orderBy?: MotorcycleBrandsOrderByWithRelationInput | MotorcycleBrandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MotorcycleBrandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MotorcycleBrands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MotorcycleBrands.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned MotorcycleBrands
    **/
    _count?: true | MotorcycleBrandsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MotorcycleBrandsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MotorcycleBrandsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MotorcycleBrandsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MotorcycleBrandsMaxAggregateInputType
  }

  export type GetMotorcycleBrandsAggregateType<T extends MotorcycleBrandsAggregateArgs> = {
        [P in keyof T & keyof AggregateMotorcycleBrands]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMotorcycleBrands[P]>
      : GetScalarType<T[P], AggregateMotorcycleBrands[P]>
  }




  export type MotorcycleBrandsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MotorcycleBrandsWhereInput
    orderBy?: MotorcycleBrandsOrderByWithAggregationInput | MotorcycleBrandsOrderByWithAggregationInput[]
    by: MotorcycleBrandsScalarFieldEnum[] | MotorcycleBrandsScalarFieldEnum
    having?: MotorcycleBrandsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MotorcycleBrandsCountAggregateInputType | true
    _avg?: MotorcycleBrandsAvgAggregateInputType
    _sum?: MotorcycleBrandsSumAggregateInputType
    _min?: MotorcycleBrandsMinAggregateInputType
    _max?: MotorcycleBrandsMaxAggregateInputType
  }

  export type MotorcycleBrandsGroupByOutputType = {
    id: number
    name: string
    country: string | null
    description: string | null
    createdAt: Date
    updatedAt: Date
    _count: MotorcycleBrandsCountAggregateOutputType | null
    _avg: MotorcycleBrandsAvgAggregateOutputType | null
    _sum: MotorcycleBrandsSumAggregateOutputType | null
    _min: MotorcycleBrandsMinAggregateOutputType | null
    _max: MotorcycleBrandsMaxAggregateOutputType | null
  }

  type GetMotorcycleBrandsGroupByPayload<T extends MotorcycleBrandsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MotorcycleBrandsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MotorcycleBrandsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MotorcycleBrandsGroupByOutputType[P]>
            : GetScalarType<T[P], MotorcycleBrandsGroupByOutputType[P]>
        }
      >
    >


  export type MotorcycleBrandsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    country?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    MotorcycleModels?: boolean | MotorcycleBrands$MotorcycleModelsArgs<ExtArgs>
    _count?: boolean | MotorcycleBrandsCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["motorcycleBrands"]>

  export type MotorcycleBrandsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    country?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["motorcycleBrands"]>

  export type MotorcycleBrandsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    country?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["motorcycleBrands"]>

  export type MotorcycleBrandsSelectScalar = {
    id?: boolean
    name?: boolean
    country?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type MotorcycleBrandsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "country" | "description" | "createdAt" | "updatedAt", ExtArgs["result"]["motorcycleBrands"]>
  export type MotorcycleBrandsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    MotorcycleModels?: boolean | MotorcycleBrands$MotorcycleModelsArgs<ExtArgs>
    _count?: boolean | MotorcycleBrandsCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type MotorcycleBrandsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type MotorcycleBrandsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $MotorcycleBrandsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "MotorcycleBrands"
    objects: {
      MotorcycleModels: Prisma.$MotorcycleModelsPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      country: string | null
      description: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["motorcycleBrands"]>
    composites: {}
  }

  type MotorcycleBrandsGetPayload<S extends boolean | null | undefined | MotorcycleBrandsDefaultArgs> = $Result.GetResult<Prisma.$MotorcycleBrandsPayload, S>

  type MotorcycleBrandsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<MotorcycleBrandsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: MotorcycleBrandsCountAggregateInputType | true
    }

  export interface MotorcycleBrandsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['MotorcycleBrands'], meta: { name: 'MotorcycleBrands' } }
    /**
     * Find zero or one MotorcycleBrands that matches the filter.
     * @param {MotorcycleBrandsFindUniqueArgs} args - Arguments to find a MotorcycleBrands
     * @example
     * // Get one MotorcycleBrands
     * const motorcycleBrands = await prisma.motorcycleBrands.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends MotorcycleBrandsFindUniqueArgs>(args: SelectSubset<T, MotorcycleBrandsFindUniqueArgs<ExtArgs>>): Prisma__MotorcycleBrandsClient<$Result.GetResult<Prisma.$MotorcycleBrandsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one MotorcycleBrands that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {MotorcycleBrandsFindUniqueOrThrowArgs} args - Arguments to find a MotorcycleBrands
     * @example
     * // Get one MotorcycleBrands
     * const motorcycleBrands = await prisma.motorcycleBrands.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends MotorcycleBrandsFindUniqueOrThrowArgs>(args: SelectSubset<T, MotorcycleBrandsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__MotorcycleBrandsClient<$Result.GetResult<Prisma.$MotorcycleBrandsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MotorcycleBrands that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleBrandsFindFirstArgs} args - Arguments to find a MotorcycleBrands
     * @example
     * // Get one MotorcycleBrands
     * const motorcycleBrands = await prisma.motorcycleBrands.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends MotorcycleBrandsFindFirstArgs>(args?: SelectSubset<T, MotorcycleBrandsFindFirstArgs<ExtArgs>>): Prisma__MotorcycleBrandsClient<$Result.GetResult<Prisma.$MotorcycleBrandsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MotorcycleBrands that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleBrandsFindFirstOrThrowArgs} args - Arguments to find a MotorcycleBrands
     * @example
     * // Get one MotorcycleBrands
     * const motorcycleBrands = await prisma.motorcycleBrands.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends MotorcycleBrandsFindFirstOrThrowArgs>(args?: SelectSubset<T, MotorcycleBrandsFindFirstOrThrowArgs<ExtArgs>>): Prisma__MotorcycleBrandsClient<$Result.GetResult<Prisma.$MotorcycleBrandsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more MotorcycleBrands that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleBrandsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all MotorcycleBrands
     * const motorcycleBrands = await prisma.motorcycleBrands.findMany()
     * 
     * // Get first 10 MotorcycleBrands
     * const motorcycleBrands = await prisma.motorcycleBrands.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const motorcycleBrandsWithIdOnly = await prisma.motorcycleBrands.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends MotorcycleBrandsFindManyArgs>(args?: SelectSubset<T, MotorcycleBrandsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MotorcycleBrandsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a MotorcycleBrands.
     * @param {MotorcycleBrandsCreateArgs} args - Arguments to create a MotorcycleBrands.
     * @example
     * // Create one MotorcycleBrands
     * const MotorcycleBrands = await prisma.motorcycleBrands.create({
     *   data: {
     *     // ... data to create a MotorcycleBrands
     *   }
     * })
     * 
     */
    create<T extends MotorcycleBrandsCreateArgs>(args: SelectSubset<T, MotorcycleBrandsCreateArgs<ExtArgs>>): Prisma__MotorcycleBrandsClient<$Result.GetResult<Prisma.$MotorcycleBrandsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many MotorcycleBrands.
     * @param {MotorcycleBrandsCreateManyArgs} args - Arguments to create many MotorcycleBrands.
     * @example
     * // Create many MotorcycleBrands
     * const motorcycleBrands = await prisma.motorcycleBrands.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends MotorcycleBrandsCreateManyArgs>(args?: SelectSubset<T, MotorcycleBrandsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many MotorcycleBrands and returns the data saved in the database.
     * @param {MotorcycleBrandsCreateManyAndReturnArgs} args - Arguments to create many MotorcycleBrands.
     * @example
     * // Create many MotorcycleBrands
     * const motorcycleBrands = await prisma.motorcycleBrands.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many MotorcycleBrands and only return the `id`
     * const motorcycleBrandsWithIdOnly = await prisma.motorcycleBrands.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends MotorcycleBrandsCreateManyAndReturnArgs>(args?: SelectSubset<T, MotorcycleBrandsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MotorcycleBrandsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a MotorcycleBrands.
     * @param {MotorcycleBrandsDeleteArgs} args - Arguments to delete one MotorcycleBrands.
     * @example
     * // Delete one MotorcycleBrands
     * const MotorcycleBrands = await prisma.motorcycleBrands.delete({
     *   where: {
     *     // ... filter to delete one MotorcycleBrands
     *   }
     * })
     * 
     */
    delete<T extends MotorcycleBrandsDeleteArgs>(args: SelectSubset<T, MotorcycleBrandsDeleteArgs<ExtArgs>>): Prisma__MotorcycleBrandsClient<$Result.GetResult<Prisma.$MotorcycleBrandsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one MotorcycleBrands.
     * @param {MotorcycleBrandsUpdateArgs} args - Arguments to update one MotorcycleBrands.
     * @example
     * // Update one MotorcycleBrands
     * const motorcycleBrands = await prisma.motorcycleBrands.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends MotorcycleBrandsUpdateArgs>(args: SelectSubset<T, MotorcycleBrandsUpdateArgs<ExtArgs>>): Prisma__MotorcycleBrandsClient<$Result.GetResult<Prisma.$MotorcycleBrandsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more MotorcycleBrands.
     * @param {MotorcycleBrandsDeleteManyArgs} args - Arguments to filter MotorcycleBrands to delete.
     * @example
     * // Delete a few MotorcycleBrands
     * const { count } = await prisma.motorcycleBrands.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends MotorcycleBrandsDeleteManyArgs>(args?: SelectSubset<T, MotorcycleBrandsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MotorcycleBrands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleBrandsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many MotorcycleBrands
     * const motorcycleBrands = await prisma.motorcycleBrands.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends MotorcycleBrandsUpdateManyArgs>(args: SelectSubset<T, MotorcycleBrandsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MotorcycleBrands and returns the data updated in the database.
     * @param {MotorcycleBrandsUpdateManyAndReturnArgs} args - Arguments to update many MotorcycleBrands.
     * @example
     * // Update many MotorcycleBrands
     * const motorcycleBrands = await prisma.motorcycleBrands.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more MotorcycleBrands and only return the `id`
     * const motorcycleBrandsWithIdOnly = await prisma.motorcycleBrands.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends MotorcycleBrandsUpdateManyAndReturnArgs>(args: SelectSubset<T, MotorcycleBrandsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MotorcycleBrandsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one MotorcycleBrands.
     * @param {MotorcycleBrandsUpsertArgs} args - Arguments to update or create a MotorcycleBrands.
     * @example
     * // Update or create a MotorcycleBrands
     * const motorcycleBrands = await prisma.motorcycleBrands.upsert({
     *   create: {
     *     // ... data to create a MotorcycleBrands
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the MotorcycleBrands we want to update
     *   }
     * })
     */
    upsert<T extends MotorcycleBrandsUpsertArgs>(args: SelectSubset<T, MotorcycleBrandsUpsertArgs<ExtArgs>>): Prisma__MotorcycleBrandsClient<$Result.GetResult<Prisma.$MotorcycleBrandsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of MotorcycleBrands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleBrandsCountArgs} args - Arguments to filter MotorcycleBrands to count.
     * @example
     * // Count the number of MotorcycleBrands
     * const count = await prisma.motorcycleBrands.count({
     *   where: {
     *     // ... the filter for the MotorcycleBrands we want to count
     *   }
     * })
    **/
    count<T extends MotorcycleBrandsCountArgs>(
      args?: Subset<T, MotorcycleBrandsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MotorcycleBrandsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a MotorcycleBrands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleBrandsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MotorcycleBrandsAggregateArgs>(args: Subset<T, MotorcycleBrandsAggregateArgs>): Prisma.PrismaPromise<GetMotorcycleBrandsAggregateType<T>>

    /**
     * Group by MotorcycleBrands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleBrandsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MotorcycleBrandsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MotorcycleBrandsGroupByArgs['orderBy'] }
        : { orderBy?: MotorcycleBrandsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MotorcycleBrandsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMotorcycleBrandsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the MotorcycleBrands model
   */
  readonly fields: MotorcycleBrandsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for MotorcycleBrands.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__MotorcycleBrandsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    MotorcycleModels<T extends MotorcycleBrands$MotorcycleModelsArgs<ExtArgs> = {}>(args?: Subset<T, MotorcycleBrands$MotorcycleModelsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MotorcycleModelsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the MotorcycleBrands model
   */
  interface MotorcycleBrandsFieldRefs {
    readonly id: FieldRef<"MotorcycleBrands", 'Int'>
    readonly name: FieldRef<"MotorcycleBrands", 'String'>
    readonly country: FieldRef<"MotorcycleBrands", 'String'>
    readonly description: FieldRef<"MotorcycleBrands", 'String'>
    readonly createdAt: FieldRef<"MotorcycleBrands", 'DateTime'>
    readonly updatedAt: FieldRef<"MotorcycleBrands", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * MotorcycleBrands findUnique
   */
  export type MotorcycleBrandsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrands
     */
    select?: MotorcycleBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleBrands
     */
    omit?: MotorcycleBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleBrandsInclude<ExtArgs> | null
    /**
     * Filter, which MotorcycleBrands to fetch.
     */
    where: MotorcycleBrandsWhereUniqueInput
  }

  /**
   * MotorcycleBrands findUniqueOrThrow
   */
  export type MotorcycleBrandsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrands
     */
    select?: MotorcycleBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleBrands
     */
    omit?: MotorcycleBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleBrandsInclude<ExtArgs> | null
    /**
     * Filter, which MotorcycleBrands to fetch.
     */
    where: MotorcycleBrandsWhereUniqueInput
  }

  /**
   * MotorcycleBrands findFirst
   */
  export type MotorcycleBrandsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrands
     */
    select?: MotorcycleBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleBrands
     */
    omit?: MotorcycleBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleBrandsInclude<ExtArgs> | null
    /**
     * Filter, which MotorcycleBrands to fetch.
     */
    where?: MotorcycleBrandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MotorcycleBrands to fetch.
     */
    orderBy?: MotorcycleBrandsOrderByWithRelationInput | MotorcycleBrandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MotorcycleBrands.
     */
    cursor?: MotorcycleBrandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MotorcycleBrands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MotorcycleBrands.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MotorcycleBrands.
     */
    distinct?: MotorcycleBrandsScalarFieldEnum | MotorcycleBrandsScalarFieldEnum[]
  }

  /**
   * MotorcycleBrands findFirstOrThrow
   */
  export type MotorcycleBrandsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrands
     */
    select?: MotorcycleBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleBrands
     */
    omit?: MotorcycleBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleBrandsInclude<ExtArgs> | null
    /**
     * Filter, which MotorcycleBrands to fetch.
     */
    where?: MotorcycleBrandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MotorcycleBrands to fetch.
     */
    orderBy?: MotorcycleBrandsOrderByWithRelationInput | MotorcycleBrandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MotorcycleBrands.
     */
    cursor?: MotorcycleBrandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MotorcycleBrands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MotorcycleBrands.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MotorcycleBrands.
     */
    distinct?: MotorcycleBrandsScalarFieldEnum | MotorcycleBrandsScalarFieldEnum[]
  }

  /**
   * MotorcycleBrands findMany
   */
  export type MotorcycleBrandsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrands
     */
    select?: MotorcycleBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleBrands
     */
    omit?: MotorcycleBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleBrandsInclude<ExtArgs> | null
    /**
     * Filter, which MotorcycleBrands to fetch.
     */
    where?: MotorcycleBrandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MotorcycleBrands to fetch.
     */
    orderBy?: MotorcycleBrandsOrderByWithRelationInput | MotorcycleBrandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing MotorcycleBrands.
     */
    cursor?: MotorcycleBrandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MotorcycleBrands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MotorcycleBrands.
     */
    skip?: number
    distinct?: MotorcycleBrandsScalarFieldEnum | MotorcycleBrandsScalarFieldEnum[]
  }

  /**
   * MotorcycleBrands create
   */
  export type MotorcycleBrandsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrands
     */
    select?: MotorcycleBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleBrands
     */
    omit?: MotorcycleBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleBrandsInclude<ExtArgs> | null
    /**
     * The data needed to create a MotorcycleBrands.
     */
    data: XOR<MotorcycleBrandsCreateInput, MotorcycleBrandsUncheckedCreateInput>
  }

  /**
   * MotorcycleBrands createMany
   */
  export type MotorcycleBrandsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many MotorcycleBrands.
     */
    data: MotorcycleBrandsCreateManyInput | MotorcycleBrandsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * MotorcycleBrands createManyAndReturn
   */
  export type MotorcycleBrandsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrands
     */
    select?: MotorcycleBrandsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleBrands
     */
    omit?: MotorcycleBrandsOmit<ExtArgs> | null
    /**
     * The data used to create many MotorcycleBrands.
     */
    data: MotorcycleBrandsCreateManyInput | MotorcycleBrandsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * MotorcycleBrands update
   */
  export type MotorcycleBrandsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrands
     */
    select?: MotorcycleBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleBrands
     */
    omit?: MotorcycleBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleBrandsInclude<ExtArgs> | null
    /**
     * The data needed to update a MotorcycleBrands.
     */
    data: XOR<MotorcycleBrandsUpdateInput, MotorcycleBrandsUncheckedUpdateInput>
    /**
     * Choose, which MotorcycleBrands to update.
     */
    where: MotorcycleBrandsWhereUniqueInput
  }

  /**
   * MotorcycleBrands updateMany
   */
  export type MotorcycleBrandsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update MotorcycleBrands.
     */
    data: XOR<MotorcycleBrandsUpdateManyMutationInput, MotorcycleBrandsUncheckedUpdateManyInput>
    /**
     * Filter which MotorcycleBrands to update
     */
    where?: MotorcycleBrandsWhereInput
    /**
     * Limit how many MotorcycleBrands to update.
     */
    limit?: number
  }

  /**
   * MotorcycleBrands updateManyAndReturn
   */
  export type MotorcycleBrandsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrands
     */
    select?: MotorcycleBrandsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleBrands
     */
    omit?: MotorcycleBrandsOmit<ExtArgs> | null
    /**
     * The data used to update MotorcycleBrands.
     */
    data: XOR<MotorcycleBrandsUpdateManyMutationInput, MotorcycleBrandsUncheckedUpdateManyInput>
    /**
     * Filter which MotorcycleBrands to update
     */
    where?: MotorcycleBrandsWhereInput
    /**
     * Limit how many MotorcycleBrands to update.
     */
    limit?: number
  }

  /**
   * MotorcycleBrands upsert
   */
  export type MotorcycleBrandsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrands
     */
    select?: MotorcycleBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleBrands
     */
    omit?: MotorcycleBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleBrandsInclude<ExtArgs> | null
    /**
     * The filter to search for the MotorcycleBrands to update in case it exists.
     */
    where: MotorcycleBrandsWhereUniqueInput
    /**
     * In case the MotorcycleBrands found by the `where` argument doesn't exist, create a new MotorcycleBrands with this data.
     */
    create: XOR<MotorcycleBrandsCreateInput, MotorcycleBrandsUncheckedCreateInput>
    /**
     * In case the MotorcycleBrands was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MotorcycleBrandsUpdateInput, MotorcycleBrandsUncheckedUpdateInput>
  }

  /**
   * MotorcycleBrands delete
   */
  export type MotorcycleBrandsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrands
     */
    select?: MotorcycleBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleBrands
     */
    omit?: MotorcycleBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleBrandsInclude<ExtArgs> | null
    /**
     * Filter which MotorcycleBrands to delete.
     */
    where: MotorcycleBrandsWhereUniqueInput
  }

  /**
   * MotorcycleBrands deleteMany
   */
  export type MotorcycleBrandsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MotorcycleBrands to delete
     */
    where?: MotorcycleBrandsWhereInput
    /**
     * Limit how many MotorcycleBrands to delete.
     */
    limit?: number
  }

  /**
   * MotorcycleBrands.MotorcycleModels
   */
  export type MotorcycleBrands$MotorcycleModelsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsInclude<ExtArgs> | null
    where?: MotorcycleModelsWhereInput
    orderBy?: MotorcycleModelsOrderByWithRelationInput | MotorcycleModelsOrderByWithRelationInput[]
    cursor?: MotorcycleModelsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MotorcycleModelsScalarFieldEnum | MotorcycleModelsScalarFieldEnum[]
  }

  /**
   * MotorcycleBrands without action
   */
  export type MotorcycleBrandsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleBrands
     */
    select?: MotorcycleBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleBrands
     */
    omit?: MotorcycleBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleBrandsInclude<ExtArgs> | null
  }


  /**
   * Model MotorcycleModels
   */

  export type AggregateMotorcycleModels = {
    _count: MotorcycleModelsCountAggregateOutputType | null
    _avg: MotorcycleModelsAvgAggregateOutputType | null
    _sum: MotorcycleModelsSumAggregateOutputType | null
    _min: MotorcycleModelsMinAggregateOutputType | null
    _max: MotorcycleModelsMaxAggregateOutputType | null
  }

  export type MotorcycleModelsAvgAggregateOutputType = {
    id: number | null
    brandId: number | null
    cubic_centimeter: number | null
    electric_carbon_per_unit: number | null
    oil_carbon_per_unit: number | null
  }

  export type MotorcycleModelsSumAggregateOutputType = {
    id: number | null
    brandId: number | null
    cubic_centimeter: number | null
    electric_carbon_per_unit: number | null
    oil_carbon_per_unit: number | null
  }

  export type MotorcycleModelsMinAggregateOutputType = {
    id: number | null
    brandId: number | null
    name: string | null
    description: string | null
    cubic_centimeter: number | null
    power_type: string | null
    electric_carbon_per_unit: number | null
    oil_carbon_per_unit: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type MotorcycleModelsMaxAggregateOutputType = {
    id: number | null
    brandId: number | null
    name: string | null
    description: string | null
    cubic_centimeter: number | null
    power_type: string | null
    electric_carbon_per_unit: number | null
    oil_carbon_per_unit: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type MotorcycleModelsCountAggregateOutputType = {
    id: number
    brandId: number
    name: number
    description: number
    cubic_centimeter: number
    power_type: number
    electric_carbon_per_unit: number
    oil_carbon_per_unit: number
    oil_type: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type MotorcycleModelsAvgAggregateInputType = {
    id?: true
    brandId?: true
    cubic_centimeter?: true
    electric_carbon_per_unit?: true
    oil_carbon_per_unit?: true
  }

  export type MotorcycleModelsSumAggregateInputType = {
    id?: true
    brandId?: true
    cubic_centimeter?: true
    electric_carbon_per_unit?: true
    oil_carbon_per_unit?: true
  }

  export type MotorcycleModelsMinAggregateInputType = {
    id?: true
    brandId?: true
    name?: true
    description?: true
    cubic_centimeter?: true
    power_type?: true
    electric_carbon_per_unit?: true
    oil_carbon_per_unit?: true
    createdAt?: true
    updatedAt?: true
  }

  export type MotorcycleModelsMaxAggregateInputType = {
    id?: true
    brandId?: true
    name?: true
    description?: true
    cubic_centimeter?: true
    power_type?: true
    electric_carbon_per_unit?: true
    oil_carbon_per_unit?: true
    createdAt?: true
    updatedAt?: true
  }

  export type MotorcycleModelsCountAggregateInputType = {
    id?: true
    brandId?: true
    name?: true
    description?: true
    cubic_centimeter?: true
    power_type?: true
    electric_carbon_per_unit?: true
    oil_carbon_per_unit?: true
    oil_type?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type MotorcycleModelsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MotorcycleModels to aggregate.
     */
    where?: MotorcycleModelsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MotorcycleModels to fetch.
     */
    orderBy?: MotorcycleModelsOrderByWithRelationInput | MotorcycleModelsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MotorcycleModelsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MotorcycleModels from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MotorcycleModels.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned MotorcycleModels
    **/
    _count?: true | MotorcycleModelsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MotorcycleModelsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MotorcycleModelsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MotorcycleModelsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MotorcycleModelsMaxAggregateInputType
  }

  export type GetMotorcycleModelsAggregateType<T extends MotorcycleModelsAggregateArgs> = {
        [P in keyof T & keyof AggregateMotorcycleModels]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMotorcycleModels[P]>
      : GetScalarType<T[P], AggregateMotorcycleModels[P]>
  }




  export type MotorcycleModelsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MotorcycleModelsWhereInput
    orderBy?: MotorcycleModelsOrderByWithAggregationInput | MotorcycleModelsOrderByWithAggregationInput[]
    by: MotorcycleModelsScalarFieldEnum[] | MotorcycleModelsScalarFieldEnum
    having?: MotorcycleModelsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MotorcycleModelsCountAggregateInputType | true
    _avg?: MotorcycleModelsAvgAggregateInputType
    _sum?: MotorcycleModelsSumAggregateInputType
    _min?: MotorcycleModelsMinAggregateInputType
    _max?: MotorcycleModelsMaxAggregateInputType
  }

  export type MotorcycleModelsGroupByOutputType = {
    id: number
    brandId: number
    name: string
    description: string | null
    cubic_centimeter: number | null
    power_type: string | null
    electric_carbon_per_unit: number | null
    oil_carbon_per_unit: number | null
    oil_type: $Enums.MotorBikeOilTypes[]
    createdAt: Date
    updatedAt: Date
    _count: MotorcycleModelsCountAggregateOutputType | null
    _avg: MotorcycleModelsAvgAggregateOutputType | null
    _sum: MotorcycleModelsSumAggregateOutputType | null
    _min: MotorcycleModelsMinAggregateOutputType | null
    _max: MotorcycleModelsMaxAggregateOutputType | null
  }

  type GetMotorcycleModelsGroupByPayload<T extends MotorcycleModelsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MotorcycleModelsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MotorcycleModelsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MotorcycleModelsGroupByOutputType[P]>
            : GetScalarType<T[P], MotorcycleModelsGroupByOutputType[P]>
        }
      >
    >


  export type MotorcycleModelsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    brandId?: boolean
    name?: boolean
    description?: boolean
    cubic_centimeter?: boolean
    power_type?: boolean
    electric_carbon_per_unit?: boolean
    oil_carbon_per_unit?: boolean
    oil_type?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    brand?: boolean | MotorcycleBrandsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["motorcycleModels"]>

  export type MotorcycleModelsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    brandId?: boolean
    name?: boolean
    description?: boolean
    cubic_centimeter?: boolean
    power_type?: boolean
    electric_carbon_per_unit?: boolean
    oil_carbon_per_unit?: boolean
    oil_type?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    brand?: boolean | MotorcycleBrandsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["motorcycleModels"]>

  export type MotorcycleModelsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    brandId?: boolean
    name?: boolean
    description?: boolean
    cubic_centimeter?: boolean
    power_type?: boolean
    electric_carbon_per_unit?: boolean
    oil_carbon_per_unit?: boolean
    oil_type?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    brand?: boolean | MotorcycleBrandsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["motorcycleModels"]>

  export type MotorcycleModelsSelectScalar = {
    id?: boolean
    brandId?: boolean
    name?: boolean
    description?: boolean
    cubic_centimeter?: boolean
    power_type?: boolean
    electric_carbon_per_unit?: boolean
    oil_carbon_per_unit?: boolean
    oil_type?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type MotorcycleModelsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "brandId" | "name" | "description" | "cubic_centimeter" | "power_type" | "electric_carbon_per_unit" | "oil_carbon_per_unit" | "oil_type" | "createdAt" | "updatedAt", ExtArgs["result"]["motorcycleModels"]>
  export type MotorcycleModelsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    brand?: boolean | MotorcycleBrandsDefaultArgs<ExtArgs>
  }
  export type MotorcycleModelsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    brand?: boolean | MotorcycleBrandsDefaultArgs<ExtArgs>
  }
  export type MotorcycleModelsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    brand?: boolean | MotorcycleBrandsDefaultArgs<ExtArgs>
  }

  export type $MotorcycleModelsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "MotorcycleModels"
    objects: {
      brand: Prisma.$MotorcycleBrandsPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      brandId: number
      name: string
      description: string | null
      cubic_centimeter: number | null
      power_type: string | null
      electric_carbon_per_unit: number | null
      oil_carbon_per_unit: number | null
      oil_type: $Enums.MotorBikeOilTypes[]
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["motorcycleModels"]>
    composites: {}
  }

  type MotorcycleModelsGetPayload<S extends boolean | null | undefined | MotorcycleModelsDefaultArgs> = $Result.GetResult<Prisma.$MotorcycleModelsPayload, S>

  type MotorcycleModelsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<MotorcycleModelsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: MotorcycleModelsCountAggregateInputType | true
    }

  export interface MotorcycleModelsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['MotorcycleModels'], meta: { name: 'MotorcycleModels' } }
    /**
     * Find zero or one MotorcycleModels that matches the filter.
     * @param {MotorcycleModelsFindUniqueArgs} args - Arguments to find a MotorcycleModels
     * @example
     * // Get one MotorcycleModels
     * const motorcycleModels = await prisma.motorcycleModels.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends MotorcycleModelsFindUniqueArgs>(args: SelectSubset<T, MotorcycleModelsFindUniqueArgs<ExtArgs>>): Prisma__MotorcycleModelsClient<$Result.GetResult<Prisma.$MotorcycleModelsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one MotorcycleModels that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {MotorcycleModelsFindUniqueOrThrowArgs} args - Arguments to find a MotorcycleModels
     * @example
     * // Get one MotorcycleModels
     * const motorcycleModels = await prisma.motorcycleModels.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends MotorcycleModelsFindUniqueOrThrowArgs>(args: SelectSubset<T, MotorcycleModelsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__MotorcycleModelsClient<$Result.GetResult<Prisma.$MotorcycleModelsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MotorcycleModels that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleModelsFindFirstArgs} args - Arguments to find a MotorcycleModels
     * @example
     * // Get one MotorcycleModels
     * const motorcycleModels = await prisma.motorcycleModels.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends MotorcycleModelsFindFirstArgs>(args?: SelectSubset<T, MotorcycleModelsFindFirstArgs<ExtArgs>>): Prisma__MotorcycleModelsClient<$Result.GetResult<Prisma.$MotorcycleModelsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MotorcycleModels that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleModelsFindFirstOrThrowArgs} args - Arguments to find a MotorcycleModels
     * @example
     * // Get one MotorcycleModels
     * const motorcycleModels = await prisma.motorcycleModels.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends MotorcycleModelsFindFirstOrThrowArgs>(args?: SelectSubset<T, MotorcycleModelsFindFirstOrThrowArgs<ExtArgs>>): Prisma__MotorcycleModelsClient<$Result.GetResult<Prisma.$MotorcycleModelsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more MotorcycleModels that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleModelsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all MotorcycleModels
     * const motorcycleModels = await prisma.motorcycleModels.findMany()
     * 
     * // Get first 10 MotorcycleModels
     * const motorcycleModels = await prisma.motorcycleModels.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const motorcycleModelsWithIdOnly = await prisma.motorcycleModels.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends MotorcycleModelsFindManyArgs>(args?: SelectSubset<T, MotorcycleModelsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MotorcycleModelsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a MotorcycleModels.
     * @param {MotorcycleModelsCreateArgs} args - Arguments to create a MotorcycleModels.
     * @example
     * // Create one MotorcycleModels
     * const MotorcycleModels = await prisma.motorcycleModels.create({
     *   data: {
     *     // ... data to create a MotorcycleModels
     *   }
     * })
     * 
     */
    create<T extends MotorcycleModelsCreateArgs>(args: SelectSubset<T, MotorcycleModelsCreateArgs<ExtArgs>>): Prisma__MotorcycleModelsClient<$Result.GetResult<Prisma.$MotorcycleModelsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many MotorcycleModels.
     * @param {MotorcycleModelsCreateManyArgs} args - Arguments to create many MotorcycleModels.
     * @example
     * // Create many MotorcycleModels
     * const motorcycleModels = await prisma.motorcycleModels.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends MotorcycleModelsCreateManyArgs>(args?: SelectSubset<T, MotorcycleModelsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many MotorcycleModels and returns the data saved in the database.
     * @param {MotorcycleModelsCreateManyAndReturnArgs} args - Arguments to create many MotorcycleModels.
     * @example
     * // Create many MotorcycleModels
     * const motorcycleModels = await prisma.motorcycleModels.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many MotorcycleModels and only return the `id`
     * const motorcycleModelsWithIdOnly = await prisma.motorcycleModels.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends MotorcycleModelsCreateManyAndReturnArgs>(args?: SelectSubset<T, MotorcycleModelsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MotorcycleModelsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a MotorcycleModels.
     * @param {MotorcycleModelsDeleteArgs} args - Arguments to delete one MotorcycleModels.
     * @example
     * // Delete one MotorcycleModels
     * const MotorcycleModels = await prisma.motorcycleModels.delete({
     *   where: {
     *     // ... filter to delete one MotorcycleModels
     *   }
     * })
     * 
     */
    delete<T extends MotorcycleModelsDeleteArgs>(args: SelectSubset<T, MotorcycleModelsDeleteArgs<ExtArgs>>): Prisma__MotorcycleModelsClient<$Result.GetResult<Prisma.$MotorcycleModelsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one MotorcycleModels.
     * @param {MotorcycleModelsUpdateArgs} args - Arguments to update one MotorcycleModels.
     * @example
     * // Update one MotorcycleModels
     * const motorcycleModels = await prisma.motorcycleModels.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends MotorcycleModelsUpdateArgs>(args: SelectSubset<T, MotorcycleModelsUpdateArgs<ExtArgs>>): Prisma__MotorcycleModelsClient<$Result.GetResult<Prisma.$MotorcycleModelsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more MotorcycleModels.
     * @param {MotorcycleModelsDeleteManyArgs} args - Arguments to filter MotorcycleModels to delete.
     * @example
     * // Delete a few MotorcycleModels
     * const { count } = await prisma.motorcycleModels.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends MotorcycleModelsDeleteManyArgs>(args?: SelectSubset<T, MotorcycleModelsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MotorcycleModels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleModelsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many MotorcycleModels
     * const motorcycleModels = await prisma.motorcycleModels.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends MotorcycleModelsUpdateManyArgs>(args: SelectSubset<T, MotorcycleModelsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MotorcycleModels and returns the data updated in the database.
     * @param {MotorcycleModelsUpdateManyAndReturnArgs} args - Arguments to update many MotorcycleModels.
     * @example
     * // Update many MotorcycleModels
     * const motorcycleModels = await prisma.motorcycleModels.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more MotorcycleModels and only return the `id`
     * const motorcycleModelsWithIdOnly = await prisma.motorcycleModels.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends MotorcycleModelsUpdateManyAndReturnArgs>(args: SelectSubset<T, MotorcycleModelsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MotorcycleModelsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one MotorcycleModels.
     * @param {MotorcycleModelsUpsertArgs} args - Arguments to update or create a MotorcycleModels.
     * @example
     * // Update or create a MotorcycleModels
     * const motorcycleModels = await prisma.motorcycleModels.upsert({
     *   create: {
     *     // ... data to create a MotorcycleModels
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the MotorcycleModels we want to update
     *   }
     * })
     */
    upsert<T extends MotorcycleModelsUpsertArgs>(args: SelectSubset<T, MotorcycleModelsUpsertArgs<ExtArgs>>): Prisma__MotorcycleModelsClient<$Result.GetResult<Prisma.$MotorcycleModelsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of MotorcycleModels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleModelsCountArgs} args - Arguments to filter MotorcycleModels to count.
     * @example
     * // Count the number of MotorcycleModels
     * const count = await prisma.motorcycleModels.count({
     *   where: {
     *     // ... the filter for the MotorcycleModels we want to count
     *   }
     * })
    **/
    count<T extends MotorcycleModelsCountArgs>(
      args?: Subset<T, MotorcycleModelsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MotorcycleModelsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a MotorcycleModels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleModelsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MotorcycleModelsAggregateArgs>(args: Subset<T, MotorcycleModelsAggregateArgs>): Prisma.PrismaPromise<GetMotorcycleModelsAggregateType<T>>

    /**
     * Group by MotorcycleModels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MotorcycleModelsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MotorcycleModelsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MotorcycleModelsGroupByArgs['orderBy'] }
        : { orderBy?: MotorcycleModelsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MotorcycleModelsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMotorcycleModelsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the MotorcycleModels model
   */
  readonly fields: MotorcycleModelsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for MotorcycleModels.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__MotorcycleModelsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    brand<T extends MotorcycleBrandsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, MotorcycleBrandsDefaultArgs<ExtArgs>>): Prisma__MotorcycleBrandsClient<$Result.GetResult<Prisma.$MotorcycleBrandsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the MotorcycleModels model
   */
  interface MotorcycleModelsFieldRefs {
    readonly id: FieldRef<"MotorcycleModels", 'Int'>
    readonly brandId: FieldRef<"MotorcycleModels", 'Int'>
    readonly name: FieldRef<"MotorcycleModels", 'String'>
    readonly description: FieldRef<"MotorcycleModels", 'String'>
    readonly cubic_centimeter: FieldRef<"MotorcycleModels", 'Int'>
    readonly power_type: FieldRef<"MotorcycleModels", 'String'>
    readonly electric_carbon_per_unit: FieldRef<"MotorcycleModels", 'Float'>
    readonly oil_carbon_per_unit: FieldRef<"MotorcycleModels", 'Float'>
    readonly oil_type: FieldRef<"MotorcycleModels", 'MotorBikeOilTypes[]'>
    readonly createdAt: FieldRef<"MotorcycleModels", 'DateTime'>
    readonly updatedAt: FieldRef<"MotorcycleModels", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * MotorcycleModels findUnique
   */
  export type MotorcycleModelsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsInclude<ExtArgs> | null
    /**
     * Filter, which MotorcycleModels to fetch.
     */
    where: MotorcycleModelsWhereUniqueInput
  }

  /**
   * MotorcycleModels findUniqueOrThrow
   */
  export type MotorcycleModelsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsInclude<ExtArgs> | null
    /**
     * Filter, which MotorcycleModels to fetch.
     */
    where: MotorcycleModelsWhereUniqueInput
  }

  /**
   * MotorcycleModels findFirst
   */
  export type MotorcycleModelsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsInclude<ExtArgs> | null
    /**
     * Filter, which MotorcycleModels to fetch.
     */
    where?: MotorcycleModelsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MotorcycleModels to fetch.
     */
    orderBy?: MotorcycleModelsOrderByWithRelationInput | MotorcycleModelsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MotorcycleModels.
     */
    cursor?: MotorcycleModelsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MotorcycleModels from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MotorcycleModels.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MotorcycleModels.
     */
    distinct?: MotorcycleModelsScalarFieldEnum | MotorcycleModelsScalarFieldEnum[]
  }

  /**
   * MotorcycleModels findFirstOrThrow
   */
  export type MotorcycleModelsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsInclude<ExtArgs> | null
    /**
     * Filter, which MotorcycleModels to fetch.
     */
    where?: MotorcycleModelsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MotorcycleModels to fetch.
     */
    orderBy?: MotorcycleModelsOrderByWithRelationInput | MotorcycleModelsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MotorcycleModels.
     */
    cursor?: MotorcycleModelsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MotorcycleModels from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MotorcycleModels.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MotorcycleModels.
     */
    distinct?: MotorcycleModelsScalarFieldEnum | MotorcycleModelsScalarFieldEnum[]
  }

  /**
   * MotorcycleModels findMany
   */
  export type MotorcycleModelsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsInclude<ExtArgs> | null
    /**
     * Filter, which MotorcycleModels to fetch.
     */
    where?: MotorcycleModelsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MotorcycleModels to fetch.
     */
    orderBy?: MotorcycleModelsOrderByWithRelationInput | MotorcycleModelsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing MotorcycleModels.
     */
    cursor?: MotorcycleModelsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MotorcycleModels from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MotorcycleModels.
     */
    skip?: number
    distinct?: MotorcycleModelsScalarFieldEnum | MotorcycleModelsScalarFieldEnum[]
  }

  /**
   * MotorcycleModels create
   */
  export type MotorcycleModelsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsInclude<ExtArgs> | null
    /**
     * The data needed to create a MotorcycleModels.
     */
    data: XOR<MotorcycleModelsCreateInput, MotorcycleModelsUncheckedCreateInput>
  }

  /**
   * MotorcycleModels createMany
   */
  export type MotorcycleModelsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many MotorcycleModels.
     */
    data: MotorcycleModelsCreateManyInput | MotorcycleModelsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * MotorcycleModels createManyAndReturn
   */
  export type MotorcycleModelsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * The data used to create many MotorcycleModels.
     */
    data: MotorcycleModelsCreateManyInput | MotorcycleModelsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * MotorcycleModels update
   */
  export type MotorcycleModelsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsInclude<ExtArgs> | null
    /**
     * The data needed to update a MotorcycleModels.
     */
    data: XOR<MotorcycleModelsUpdateInput, MotorcycleModelsUncheckedUpdateInput>
    /**
     * Choose, which MotorcycleModels to update.
     */
    where: MotorcycleModelsWhereUniqueInput
  }

  /**
   * MotorcycleModels updateMany
   */
  export type MotorcycleModelsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update MotorcycleModels.
     */
    data: XOR<MotorcycleModelsUpdateManyMutationInput, MotorcycleModelsUncheckedUpdateManyInput>
    /**
     * Filter which MotorcycleModels to update
     */
    where?: MotorcycleModelsWhereInput
    /**
     * Limit how many MotorcycleModels to update.
     */
    limit?: number
  }

  /**
   * MotorcycleModels updateManyAndReturn
   */
  export type MotorcycleModelsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * The data used to update MotorcycleModels.
     */
    data: XOR<MotorcycleModelsUpdateManyMutationInput, MotorcycleModelsUncheckedUpdateManyInput>
    /**
     * Filter which MotorcycleModels to update
     */
    where?: MotorcycleModelsWhereInput
    /**
     * Limit how many MotorcycleModels to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * MotorcycleModels upsert
   */
  export type MotorcycleModelsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsInclude<ExtArgs> | null
    /**
     * The filter to search for the MotorcycleModels to update in case it exists.
     */
    where: MotorcycleModelsWhereUniqueInput
    /**
     * In case the MotorcycleModels found by the `where` argument doesn't exist, create a new MotorcycleModels with this data.
     */
    create: XOR<MotorcycleModelsCreateInput, MotorcycleModelsUncheckedCreateInput>
    /**
     * In case the MotorcycleModels was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MotorcycleModelsUpdateInput, MotorcycleModelsUncheckedUpdateInput>
  }

  /**
   * MotorcycleModels delete
   */
  export type MotorcycleModelsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsInclude<ExtArgs> | null
    /**
     * Filter which MotorcycleModels to delete.
     */
    where: MotorcycleModelsWhereUniqueInput
  }

  /**
   * MotorcycleModels deleteMany
   */
  export type MotorcycleModelsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MotorcycleModels to delete
     */
    where?: MotorcycleModelsWhereInput
    /**
     * Limit how many MotorcycleModels to delete.
     */
    limit?: number
  }

  /**
   * MotorcycleModels without action
   */
  export type MotorcycleModelsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MotorcycleModels
     */
    select?: MotorcycleModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MotorcycleModels
     */
    omit?: MotorcycleModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MotorcycleModelsInclude<ExtArgs> | null
  }


  /**
   * Model PublicTransportTypes
   */

  export type AggregatePublicTransportTypes = {
    _count: PublicTransportTypesCountAggregateOutputType | null
    _avg: PublicTransportTypesAvgAggregateOutputType | null
    _sum: PublicTransportTypesSumAggregateOutputType | null
    _min: PublicTransportTypesMinAggregateOutputType | null
    _max: PublicTransportTypesMaxAggregateOutputType | null
  }

  export type PublicTransportTypesAvgAggregateOutputType = {
    id: number | null
    carbon_per_km: number | null
  }

  export type PublicTransportTypesSumAggregateOutputType = {
    id: number | null
    carbon_per_km: number | null
  }

  export type PublicTransportTypesMinAggregateOutputType = {
    id: number | null
    name: string | null
    description: string | null
    carbon_per_km: number | null
    power_type: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type PublicTransportTypesMaxAggregateOutputType = {
    id: number | null
    name: string | null
    description: string | null
    carbon_per_km: number | null
    power_type: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type PublicTransportTypesCountAggregateOutputType = {
    id: number
    name: number
    description: number
    carbon_per_km: number
    power_type: number
    oil_type: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type PublicTransportTypesAvgAggregateInputType = {
    id?: true
    carbon_per_km?: true
  }

  export type PublicTransportTypesSumAggregateInputType = {
    id?: true
    carbon_per_km?: true
  }

  export type PublicTransportTypesMinAggregateInputType = {
    id?: true
    name?: true
    description?: true
    carbon_per_km?: true
    power_type?: true
    createdAt?: true
    updatedAt?: true
  }

  export type PublicTransportTypesMaxAggregateInputType = {
    id?: true
    name?: true
    description?: true
    carbon_per_km?: true
    power_type?: true
    createdAt?: true
    updatedAt?: true
  }

  export type PublicTransportTypesCountAggregateInputType = {
    id?: true
    name?: true
    description?: true
    carbon_per_km?: true
    power_type?: true
    oil_type?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type PublicTransportTypesAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PublicTransportTypes to aggregate.
     */
    where?: PublicTransportTypesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PublicTransportTypes to fetch.
     */
    orderBy?: PublicTransportTypesOrderByWithRelationInput | PublicTransportTypesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PublicTransportTypesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PublicTransportTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PublicTransportTypes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PublicTransportTypes
    **/
    _count?: true | PublicTransportTypesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PublicTransportTypesAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PublicTransportTypesSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PublicTransportTypesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PublicTransportTypesMaxAggregateInputType
  }

  export type GetPublicTransportTypesAggregateType<T extends PublicTransportTypesAggregateArgs> = {
        [P in keyof T & keyof AggregatePublicTransportTypes]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePublicTransportTypes[P]>
      : GetScalarType<T[P], AggregatePublicTransportTypes[P]>
  }




  export type PublicTransportTypesGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PublicTransportTypesWhereInput
    orderBy?: PublicTransportTypesOrderByWithAggregationInput | PublicTransportTypesOrderByWithAggregationInput[]
    by: PublicTransportTypesScalarFieldEnum[] | PublicTransportTypesScalarFieldEnum
    having?: PublicTransportTypesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PublicTransportTypesCountAggregateInputType | true
    _avg?: PublicTransportTypesAvgAggregateInputType
    _sum?: PublicTransportTypesSumAggregateInputType
    _min?: PublicTransportTypesMinAggregateInputType
    _max?: PublicTransportTypesMaxAggregateInputType
  }

  export type PublicTransportTypesGroupByOutputType = {
    id: number
    name: string
    description: string | null
    carbon_per_km: number
    power_type: string | null
    oil_type: $Enums.CarOilTypes[]
    createdAt: Date
    updatedAt: Date
    _count: PublicTransportTypesCountAggregateOutputType | null
    _avg: PublicTransportTypesAvgAggregateOutputType | null
    _sum: PublicTransportTypesSumAggregateOutputType | null
    _min: PublicTransportTypesMinAggregateOutputType | null
    _max: PublicTransportTypesMaxAggregateOutputType | null
  }

  type GetPublicTransportTypesGroupByPayload<T extends PublicTransportTypesGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PublicTransportTypesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PublicTransportTypesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PublicTransportTypesGroupByOutputType[P]>
            : GetScalarType<T[P], PublicTransportTypesGroupByOutputType[P]>
        }
      >
    >


  export type PublicTransportTypesSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    carbon_per_km?: boolean
    power_type?: boolean
    oil_type?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["publicTransportTypes"]>

  export type PublicTransportTypesSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    carbon_per_km?: boolean
    power_type?: boolean
    oil_type?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["publicTransportTypes"]>

  export type PublicTransportTypesSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    description?: boolean
    carbon_per_km?: boolean
    power_type?: boolean
    oil_type?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["publicTransportTypes"]>

  export type PublicTransportTypesSelectScalar = {
    id?: boolean
    name?: boolean
    description?: boolean
    carbon_per_km?: boolean
    power_type?: boolean
    oil_type?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type PublicTransportTypesOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "description" | "carbon_per_km" | "power_type" | "oil_type" | "createdAt" | "updatedAt", ExtArgs["result"]["publicTransportTypes"]>

  export type $PublicTransportTypesPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PublicTransportTypes"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      description: string | null
      carbon_per_km: number
      power_type: string | null
      oil_type: $Enums.CarOilTypes[]
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["publicTransportTypes"]>
    composites: {}
  }

  type PublicTransportTypesGetPayload<S extends boolean | null | undefined | PublicTransportTypesDefaultArgs> = $Result.GetResult<Prisma.$PublicTransportTypesPayload, S>

  type PublicTransportTypesCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PublicTransportTypesFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PublicTransportTypesCountAggregateInputType | true
    }

  export interface PublicTransportTypesDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PublicTransportTypes'], meta: { name: 'PublicTransportTypes' } }
    /**
     * Find zero or one PublicTransportTypes that matches the filter.
     * @param {PublicTransportTypesFindUniqueArgs} args - Arguments to find a PublicTransportTypes
     * @example
     * // Get one PublicTransportTypes
     * const publicTransportTypes = await prisma.publicTransportTypes.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PublicTransportTypesFindUniqueArgs>(args: SelectSubset<T, PublicTransportTypesFindUniqueArgs<ExtArgs>>): Prisma__PublicTransportTypesClient<$Result.GetResult<Prisma.$PublicTransportTypesPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PublicTransportTypes that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PublicTransportTypesFindUniqueOrThrowArgs} args - Arguments to find a PublicTransportTypes
     * @example
     * // Get one PublicTransportTypes
     * const publicTransportTypes = await prisma.publicTransportTypes.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PublicTransportTypesFindUniqueOrThrowArgs>(args: SelectSubset<T, PublicTransportTypesFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PublicTransportTypesClient<$Result.GetResult<Prisma.$PublicTransportTypesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PublicTransportTypes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PublicTransportTypesFindFirstArgs} args - Arguments to find a PublicTransportTypes
     * @example
     * // Get one PublicTransportTypes
     * const publicTransportTypes = await prisma.publicTransportTypes.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PublicTransportTypesFindFirstArgs>(args?: SelectSubset<T, PublicTransportTypesFindFirstArgs<ExtArgs>>): Prisma__PublicTransportTypesClient<$Result.GetResult<Prisma.$PublicTransportTypesPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PublicTransportTypes that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PublicTransportTypesFindFirstOrThrowArgs} args - Arguments to find a PublicTransportTypes
     * @example
     * // Get one PublicTransportTypes
     * const publicTransportTypes = await prisma.publicTransportTypes.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PublicTransportTypesFindFirstOrThrowArgs>(args?: SelectSubset<T, PublicTransportTypesFindFirstOrThrowArgs<ExtArgs>>): Prisma__PublicTransportTypesClient<$Result.GetResult<Prisma.$PublicTransportTypesPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PublicTransportTypes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PublicTransportTypesFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PublicTransportTypes
     * const publicTransportTypes = await prisma.publicTransportTypes.findMany()
     * 
     * // Get first 10 PublicTransportTypes
     * const publicTransportTypes = await prisma.publicTransportTypes.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const publicTransportTypesWithIdOnly = await prisma.publicTransportTypes.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PublicTransportTypesFindManyArgs>(args?: SelectSubset<T, PublicTransportTypesFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PublicTransportTypesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PublicTransportTypes.
     * @param {PublicTransportTypesCreateArgs} args - Arguments to create a PublicTransportTypes.
     * @example
     * // Create one PublicTransportTypes
     * const PublicTransportTypes = await prisma.publicTransportTypes.create({
     *   data: {
     *     // ... data to create a PublicTransportTypes
     *   }
     * })
     * 
     */
    create<T extends PublicTransportTypesCreateArgs>(args: SelectSubset<T, PublicTransportTypesCreateArgs<ExtArgs>>): Prisma__PublicTransportTypesClient<$Result.GetResult<Prisma.$PublicTransportTypesPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PublicTransportTypes.
     * @param {PublicTransportTypesCreateManyArgs} args - Arguments to create many PublicTransportTypes.
     * @example
     * // Create many PublicTransportTypes
     * const publicTransportTypes = await prisma.publicTransportTypes.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PublicTransportTypesCreateManyArgs>(args?: SelectSubset<T, PublicTransportTypesCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many PublicTransportTypes and returns the data saved in the database.
     * @param {PublicTransportTypesCreateManyAndReturnArgs} args - Arguments to create many PublicTransportTypes.
     * @example
     * // Create many PublicTransportTypes
     * const publicTransportTypes = await prisma.publicTransportTypes.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many PublicTransportTypes and only return the `id`
     * const publicTransportTypesWithIdOnly = await prisma.publicTransportTypes.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PublicTransportTypesCreateManyAndReturnArgs>(args?: SelectSubset<T, PublicTransportTypesCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PublicTransportTypesPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a PublicTransportTypes.
     * @param {PublicTransportTypesDeleteArgs} args - Arguments to delete one PublicTransportTypes.
     * @example
     * // Delete one PublicTransportTypes
     * const PublicTransportTypes = await prisma.publicTransportTypes.delete({
     *   where: {
     *     // ... filter to delete one PublicTransportTypes
     *   }
     * })
     * 
     */
    delete<T extends PublicTransportTypesDeleteArgs>(args: SelectSubset<T, PublicTransportTypesDeleteArgs<ExtArgs>>): Prisma__PublicTransportTypesClient<$Result.GetResult<Prisma.$PublicTransportTypesPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PublicTransportTypes.
     * @param {PublicTransportTypesUpdateArgs} args - Arguments to update one PublicTransportTypes.
     * @example
     * // Update one PublicTransportTypes
     * const publicTransportTypes = await prisma.publicTransportTypes.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PublicTransportTypesUpdateArgs>(args: SelectSubset<T, PublicTransportTypesUpdateArgs<ExtArgs>>): Prisma__PublicTransportTypesClient<$Result.GetResult<Prisma.$PublicTransportTypesPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PublicTransportTypes.
     * @param {PublicTransportTypesDeleteManyArgs} args - Arguments to filter PublicTransportTypes to delete.
     * @example
     * // Delete a few PublicTransportTypes
     * const { count } = await prisma.publicTransportTypes.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PublicTransportTypesDeleteManyArgs>(args?: SelectSubset<T, PublicTransportTypesDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PublicTransportTypes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PublicTransportTypesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PublicTransportTypes
     * const publicTransportTypes = await prisma.publicTransportTypes.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PublicTransportTypesUpdateManyArgs>(args: SelectSubset<T, PublicTransportTypesUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PublicTransportTypes and returns the data updated in the database.
     * @param {PublicTransportTypesUpdateManyAndReturnArgs} args - Arguments to update many PublicTransportTypes.
     * @example
     * // Update many PublicTransportTypes
     * const publicTransportTypes = await prisma.publicTransportTypes.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more PublicTransportTypes and only return the `id`
     * const publicTransportTypesWithIdOnly = await prisma.publicTransportTypes.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PublicTransportTypesUpdateManyAndReturnArgs>(args: SelectSubset<T, PublicTransportTypesUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PublicTransportTypesPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one PublicTransportTypes.
     * @param {PublicTransportTypesUpsertArgs} args - Arguments to update or create a PublicTransportTypes.
     * @example
     * // Update or create a PublicTransportTypes
     * const publicTransportTypes = await prisma.publicTransportTypes.upsert({
     *   create: {
     *     // ... data to create a PublicTransportTypes
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PublicTransportTypes we want to update
     *   }
     * })
     */
    upsert<T extends PublicTransportTypesUpsertArgs>(args: SelectSubset<T, PublicTransportTypesUpsertArgs<ExtArgs>>): Prisma__PublicTransportTypesClient<$Result.GetResult<Prisma.$PublicTransportTypesPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PublicTransportTypes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PublicTransportTypesCountArgs} args - Arguments to filter PublicTransportTypes to count.
     * @example
     * // Count the number of PublicTransportTypes
     * const count = await prisma.publicTransportTypes.count({
     *   where: {
     *     // ... the filter for the PublicTransportTypes we want to count
     *   }
     * })
    **/
    count<T extends PublicTransportTypesCountArgs>(
      args?: Subset<T, PublicTransportTypesCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PublicTransportTypesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PublicTransportTypes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PublicTransportTypesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PublicTransportTypesAggregateArgs>(args: Subset<T, PublicTransportTypesAggregateArgs>): Prisma.PrismaPromise<GetPublicTransportTypesAggregateType<T>>

    /**
     * Group by PublicTransportTypes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PublicTransportTypesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PublicTransportTypesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PublicTransportTypesGroupByArgs['orderBy'] }
        : { orderBy?: PublicTransportTypesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PublicTransportTypesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPublicTransportTypesGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PublicTransportTypes model
   */
  readonly fields: PublicTransportTypesFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PublicTransportTypes.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PublicTransportTypesClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PublicTransportTypes model
   */
  interface PublicTransportTypesFieldRefs {
    readonly id: FieldRef<"PublicTransportTypes", 'Int'>
    readonly name: FieldRef<"PublicTransportTypes", 'String'>
    readonly description: FieldRef<"PublicTransportTypes", 'String'>
    readonly carbon_per_km: FieldRef<"PublicTransportTypes", 'Float'>
    readonly power_type: FieldRef<"PublicTransportTypes", 'String'>
    readonly oil_type: FieldRef<"PublicTransportTypes", 'CarOilTypes[]'>
    readonly createdAt: FieldRef<"PublicTransportTypes", 'DateTime'>
    readonly updatedAt: FieldRef<"PublicTransportTypes", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * PublicTransportTypes findUnique
   */
  export type PublicTransportTypesFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PublicTransportTypes
     */
    select?: PublicTransportTypesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PublicTransportTypes
     */
    omit?: PublicTransportTypesOmit<ExtArgs> | null
    /**
     * Filter, which PublicTransportTypes to fetch.
     */
    where: PublicTransportTypesWhereUniqueInput
  }

  /**
   * PublicTransportTypes findUniqueOrThrow
   */
  export type PublicTransportTypesFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PublicTransportTypes
     */
    select?: PublicTransportTypesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PublicTransportTypes
     */
    omit?: PublicTransportTypesOmit<ExtArgs> | null
    /**
     * Filter, which PublicTransportTypes to fetch.
     */
    where: PublicTransportTypesWhereUniqueInput
  }

  /**
   * PublicTransportTypes findFirst
   */
  export type PublicTransportTypesFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PublicTransportTypes
     */
    select?: PublicTransportTypesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PublicTransportTypes
     */
    omit?: PublicTransportTypesOmit<ExtArgs> | null
    /**
     * Filter, which PublicTransportTypes to fetch.
     */
    where?: PublicTransportTypesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PublicTransportTypes to fetch.
     */
    orderBy?: PublicTransportTypesOrderByWithRelationInput | PublicTransportTypesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PublicTransportTypes.
     */
    cursor?: PublicTransportTypesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PublicTransportTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PublicTransportTypes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PublicTransportTypes.
     */
    distinct?: PublicTransportTypesScalarFieldEnum | PublicTransportTypesScalarFieldEnum[]
  }

  /**
   * PublicTransportTypes findFirstOrThrow
   */
  export type PublicTransportTypesFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PublicTransportTypes
     */
    select?: PublicTransportTypesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PublicTransportTypes
     */
    omit?: PublicTransportTypesOmit<ExtArgs> | null
    /**
     * Filter, which PublicTransportTypes to fetch.
     */
    where?: PublicTransportTypesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PublicTransportTypes to fetch.
     */
    orderBy?: PublicTransportTypesOrderByWithRelationInput | PublicTransportTypesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PublicTransportTypes.
     */
    cursor?: PublicTransportTypesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PublicTransportTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PublicTransportTypes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PublicTransportTypes.
     */
    distinct?: PublicTransportTypesScalarFieldEnum | PublicTransportTypesScalarFieldEnum[]
  }

  /**
   * PublicTransportTypes findMany
   */
  export type PublicTransportTypesFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PublicTransportTypes
     */
    select?: PublicTransportTypesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PublicTransportTypes
     */
    omit?: PublicTransportTypesOmit<ExtArgs> | null
    /**
     * Filter, which PublicTransportTypes to fetch.
     */
    where?: PublicTransportTypesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PublicTransportTypes to fetch.
     */
    orderBy?: PublicTransportTypesOrderByWithRelationInput | PublicTransportTypesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PublicTransportTypes.
     */
    cursor?: PublicTransportTypesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PublicTransportTypes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PublicTransportTypes.
     */
    skip?: number
    distinct?: PublicTransportTypesScalarFieldEnum | PublicTransportTypesScalarFieldEnum[]
  }

  /**
   * PublicTransportTypes create
   */
  export type PublicTransportTypesCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PublicTransportTypes
     */
    select?: PublicTransportTypesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PublicTransportTypes
     */
    omit?: PublicTransportTypesOmit<ExtArgs> | null
    /**
     * The data needed to create a PublicTransportTypes.
     */
    data: XOR<PublicTransportTypesCreateInput, PublicTransportTypesUncheckedCreateInput>
  }

  /**
   * PublicTransportTypes createMany
   */
  export type PublicTransportTypesCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PublicTransportTypes.
     */
    data: PublicTransportTypesCreateManyInput | PublicTransportTypesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PublicTransportTypes createManyAndReturn
   */
  export type PublicTransportTypesCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PublicTransportTypes
     */
    select?: PublicTransportTypesSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PublicTransportTypes
     */
    omit?: PublicTransportTypesOmit<ExtArgs> | null
    /**
     * The data used to create many PublicTransportTypes.
     */
    data: PublicTransportTypesCreateManyInput | PublicTransportTypesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PublicTransportTypes update
   */
  export type PublicTransportTypesUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PublicTransportTypes
     */
    select?: PublicTransportTypesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PublicTransportTypes
     */
    omit?: PublicTransportTypesOmit<ExtArgs> | null
    /**
     * The data needed to update a PublicTransportTypes.
     */
    data: XOR<PublicTransportTypesUpdateInput, PublicTransportTypesUncheckedUpdateInput>
    /**
     * Choose, which PublicTransportTypes to update.
     */
    where: PublicTransportTypesWhereUniqueInput
  }

  /**
   * PublicTransportTypes updateMany
   */
  export type PublicTransportTypesUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PublicTransportTypes.
     */
    data: XOR<PublicTransportTypesUpdateManyMutationInput, PublicTransportTypesUncheckedUpdateManyInput>
    /**
     * Filter which PublicTransportTypes to update
     */
    where?: PublicTransportTypesWhereInput
    /**
     * Limit how many PublicTransportTypes to update.
     */
    limit?: number
  }

  /**
   * PublicTransportTypes updateManyAndReturn
   */
  export type PublicTransportTypesUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PublicTransportTypes
     */
    select?: PublicTransportTypesSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PublicTransportTypes
     */
    omit?: PublicTransportTypesOmit<ExtArgs> | null
    /**
     * The data used to update PublicTransportTypes.
     */
    data: XOR<PublicTransportTypesUpdateManyMutationInput, PublicTransportTypesUncheckedUpdateManyInput>
    /**
     * Filter which PublicTransportTypes to update
     */
    where?: PublicTransportTypesWhereInput
    /**
     * Limit how many PublicTransportTypes to update.
     */
    limit?: number
  }

  /**
   * PublicTransportTypes upsert
   */
  export type PublicTransportTypesUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PublicTransportTypes
     */
    select?: PublicTransportTypesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PublicTransportTypes
     */
    omit?: PublicTransportTypesOmit<ExtArgs> | null
    /**
     * The filter to search for the PublicTransportTypes to update in case it exists.
     */
    where: PublicTransportTypesWhereUniqueInput
    /**
     * In case the PublicTransportTypes found by the `where` argument doesn't exist, create a new PublicTransportTypes with this data.
     */
    create: XOR<PublicTransportTypesCreateInput, PublicTransportTypesUncheckedCreateInput>
    /**
     * In case the PublicTransportTypes was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PublicTransportTypesUpdateInput, PublicTransportTypesUncheckedUpdateInput>
  }

  /**
   * PublicTransportTypes delete
   */
  export type PublicTransportTypesDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PublicTransportTypes
     */
    select?: PublicTransportTypesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PublicTransportTypes
     */
    omit?: PublicTransportTypesOmit<ExtArgs> | null
    /**
     * Filter which PublicTransportTypes to delete.
     */
    where: PublicTransportTypesWhereUniqueInput
  }

  /**
   * PublicTransportTypes deleteMany
   */
  export type PublicTransportTypesDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PublicTransportTypes to delete
     */
    where?: PublicTransportTypesWhereInput
    /**
     * Limit how many PublicTransportTypes to delete.
     */
    limit?: number
  }

  /**
   * PublicTransportTypes without action
   */
  export type PublicTransportTypesDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PublicTransportTypes
     */
    select?: PublicTransportTypesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PublicTransportTypes
     */
    omit?: PublicTransportTypesOmit<ExtArgs> | null
  }


  /**
   * Model AirBrands
   */

  export type AggregateAirBrands = {
    _count: AirBrandsCountAggregateOutputType | null
    _avg: AirBrandsAvgAggregateOutputType | null
    _sum: AirBrandsSumAggregateOutputType | null
    _min: AirBrandsMinAggregateOutputType | null
    _max: AirBrandsMaxAggregateOutputType | null
  }

  export type AirBrandsAvgAggregateOutputType = {
    id: number | null
  }

  export type AirBrandsSumAggregateOutputType = {
    id: number | null
  }

  export type AirBrandsMinAggregateOutputType = {
    id: number | null
    name: string | null
    country: string | null
    description: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AirBrandsMaxAggregateOutputType = {
    id: number | null
    name: string | null
    country: string | null
    description: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AirBrandsCountAggregateOutputType = {
    id: number
    name: number
    country: number
    description: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type AirBrandsAvgAggregateInputType = {
    id?: true
  }

  export type AirBrandsSumAggregateInputType = {
    id?: true
  }

  export type AirBrandsMinAggregateInputType = {
    id?: true
    name?: true
    country?: true
    description?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AirBrandsMaxAggregateInputType = {
    id?: true
    name?: true
    country?: true
    description?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AirBrandsCountAggregateInputType = {
    id?: true
    name?: true
    country?: true
    description?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type AirBrandsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AirBrands to aggregate.
     */
    where?: AirBrandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AirBrands to fetch.
     */
    orderBy?: AirBrandsOrderByWithRelationInput | AirBrandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AirBrandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AirBrands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AirBrands.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AirBrands
    **/
    _count?: true | AirBrandsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AirBrandsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AirBrandsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AirBrandsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AirBrandsMaxAggregateInputType
  }

  export type GetAirBrandsAggregateType<T extends AirBrandsAggregateArgs> = {
        [P in keyof T & keyof AggregateAirBrands]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAirBrands[P]>
      : GetScalarType<T[P], AggregateAirBrands[P]>
  }




  export type AirBrandsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AirBrandsWhereInput
    orderBy?: AirBrandsOrderByWithAggregationInput | AirBrandsOrderByWithAggregationInput[]
    by: AirBrandsScalarFieldEnum[] | AirBrandsScalarFieldEnum
    having?: AirBrandsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AirBrandsCountAggregateInputType | true
    _avg?: AirBrandsAvgAggregateInputType
    _sum?: AirBrandsSumAggregateInputType
    _min?: AirBrandsMinAggregateInputType
    _max?: AirBrandsMaxAggregateInputType
  }

  export type AirBrandsGroupByOutputType = {
    id: number
    name: string
    country: string | null
    description: string | null
    createdAt: Date
    updatedAt: Date
    _count: AirBrandsCountAggregateOutputType | null
    _avg: AirBrandsAvgAggregateOutputType | null
    _sum: AirBrandsSumAggregateOutputType | null
    _min: AirBrandsMinAggregateOutputType | null
    _max: AirBrandsMaxAggregateOutputType | null
  }

  type GetAirBrandsGroupByPayload<T extends AirBrandsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AirBrandsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AirBrandsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AirBrandsGroupByOutputType[P]>
            : GetScalarType<T[P], AirBrandsGroupByOutputType[P]>
        }
      >
    >


  export type AirBrandsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    country?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    AirModels?: boolean | AirBrands$AirModelsArgs<ExtArgs>
    _count?: boolean | AirBrandsCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["airBrands"]>

  export type AirBrandsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    country?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["airBrands"]>

  export type AirBrandsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    country?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["airBrands"]>

  export type AirBrandsSelectScalar = {
    id?: boolean
    name?: boolean
    country?: boolean
    description?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type AirBrandsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "country" | "description" | "createdAt" | "updatedAt", ExtArgs["result"]["airBrands"]>
  export type AirBrandsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    AirModels?: boolean | AirBrands$AirModelsArgs<ExtArgs>
    _count?: boolean | AirBrandsCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type AirBrandsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type AirBrandsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $AirBrandsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "AirBrands"
    objects: {
      AirModels: Prisma.$AirModelsPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      country: string | null
      description: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["airBrands"]>
    composites: {}
  }

  type AirBrandsGetPayload<S extends boolean | null | undefined | AirBrandsDefaultArgs> = $Result.GetResult<Prisma.$AirBrandsPayload, S>

  type AirBrandsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AirBrandsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AirBrandsCountAggregateInputType | true
    }

  export interface AirBrandsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AirBrands'], meta: { name: 'AirBrands' } }
    /**
     * Find zero or one AirBrands that matches the filter.
     * @param {AirBrandsFindUniqueArgs} args - Arguments to find a AirBrands
     * @example
     * // Get one AirBrands
     * const airBrands = await prisma.airBrands.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AirBrandsFindUniqueArgs>(args: SelectSubset<T, AirBrandsFindUniqueArgs<ExtArgs>>): Prisma__AirBrandsClient<$Result.GetResult<Prisma.$AirBrandsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one AirBrands that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AirBrandsFindUniqueOrThrowArgs} args - Arguments to find a AirBrands
     * @example
     * // Get one AirBrands
     * const airBrands = await prisma.airBrands.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AirBrandsFindUniqueOrThrowArgs>(args: SelectSubset<T, AirBrandsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AirBrandsClient<$Result.GetResult<Prisma.$AirBrandsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AirBrands that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirBrandsFindFirstArgs} args - Arguments to find a AirBrands
     * @example
     * // Get one AirBrands
     * const airBrands = await prisma.airBrands.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AirBrandsFindFirstArgs>(args?: SelectSubset<T, AirBrandsFindFirstArgs<ExtArgs>>): Prisma__AirBrandsClient<$Result.GetResult<Prisma.$AirBrandsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AirBrands that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirBrandsFindFirstOrThrowArgs} args - Arguments to find a AirBrands
     * @example
     * // Get one AirBrands
     * const airBrands = await prisma.airBrands.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AirBrandsFindFirstOrThrowArgs>(args?: SelectSubset<T, AirBrandsFindFirstOrThrowArgs<ExtArgs>>): Prisma__AirBrandsClient<$Result.GetResult<Prisma.$AirBrandsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more AirBrands that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirBrandsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AirBrands
     * const airBrands = await prisma.airBrands.findMany()
     * 
     * // Get first 10 AirBrands
     * const airBrands = await prisma.airBrands.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const airBrandsWithIdOnly = await prisma.airBrands.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends AirBrandsFindManyArgs>(args?: SelectSubset<T, AirBrandsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AirBrandsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a AirBrands.
     * @param {AirBrandsCreateArgs} args - Arguments to create a AirBrands.
     * @example
     * // Create one AirBrands
     * const AirBrands = await prisma.airBrands.create({
     *   data: {
     *     // ... data to create a AirBrands
     *   }
     * })
     * 
     */
    create<T extends AirBrandsCreateArgs>(args: SelectSubset<T, AirBrandsCreateArgs<ExtArgs>>): Prisma__AirBrandsClient<$Result.GetResult<Prisma.$AirBrandsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many AirBrands.
     * @param {AirBrandsCreateManyArgs} args - Arguments to create many AirBrands.
     * @example
     * // Create many AirBrands
     * const airBrands = await prisma.airBrands.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AirBrandsCreateManyArgs>(args?: SelectSubset<T, AirBrandsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many AirBrands and returns the data saved in the database.
     * @param {AirBrandsCreateManyAndReturnArgs} args - Arguments to create many AirBrands.
     * @example
     * // Create many AirBrands
     * const airBrands = await prisma.airBrands.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many AirBrands and only return the `id`
     * const airBrandsWithIdOnly = await prisma.airBrands.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends AirBrandsCreateManyAndReturnArgs>(args?: SelectSubset<T, AirBrandsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AirBrandsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a AirBrands.
     * @param {AirBrandsDeleteArgs} args - Arguments to delete one AirBrands.
     * @example
     * // Delete one AirBrands
     * const AirBrands = await prisma.airBrands.delete({
     *   where: {
     *     // ... filter to delete one AirBrands
     *   }
     * })
     * 
     */
    delete<T extends AirBrandsDeleteArgs>(args: SelectSubset<T, AirBrandsDeleteArgs<ExtArgs>>): Prisma__AirBrandsClient<$Result.GetResult<Prisma.$AirBrandsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one AirBrands.
     * @param {AirBrandsUpdateArgs} args - Arguments to update one AirBrands.
     * @example
     * // Update one AirBrands
     * const airBrands = await prisma.airBrands.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AirBrandsUpdateArgs>(args: SelectSubset<T, AirBrandsUpdateArgs<ExtArgs>>): Prisma__AirBrandsClient<$Result.GetResult<Prisma.$AirBrandsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more AirBrands.
     * @param {AirBrandsDeleteManyArgs} args - Arguments to filter AirBrands to delete.
     * @example
     * // Delete a few AirBrands
     * const { count } = await prisma.airBrands.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AirBrandsDeleteManyArgs>(args?: SelectSubset<T, AirBrandsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AirBrands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirBrandsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AirBrands
     * const airBrands = await prisma.airBrands.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AirBrandsUpdateManyArgs>(args: SelectSubset<T, AirBrandsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AirBrands and returns the data updated in the database.
     * @param {AirBrandsUpdateManyAndReturnArgs} args - Arguments to update many AirBrands.
     * @example
     * // Update many AirBrands
     * const airBrands = await prisma.airBrands.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more AirBrands and only return the `id`
     * const airBrandsWithIdOnly = await prisma.airBrands.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends AirBrandsUpdateManyAndReturnArgs>(args: SelectSubset<T, AirBrandsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AirBrandsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one AirBrands.
     * @param {AirBrandsUpsertArgs} args - Arguments to update or create a AirBrands.
     * @example
     * // Update or create a AirBrands
     * const airBrands = await prisma.airBrands.upsert({
     *   create: {
     *     // ... data to create a AirBrands
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AirBrands we want to update
     *   }
     * })
     */
    upsert<T extends AirBrandsUpsertArgs>(args: SelectSubset<T, AirBrandsUpsertArgs<ExtArgs>>): Prisma__AirBrandsClient<$Result.GetResult<Prisma.$AirBrandsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of AirBrands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirBrandsCountArgs} args - Arguments to filter AirBrands to count.
     * @example
     * // Count the number of AirBrands
     * const count = await prisma.airBrands.count({
     *   where: {
     *     // ... the filter for the AirBrands we want to count
     *   }
     * })
    **/
    count<T extends AirBrandsCountArgs>(
      args?: Subset<T, AirBrandsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AirBrandsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AirBrands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirBrandsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AirBrandsAggregateArgs>(args: Subset<T, AirBrandsAggregateArgs>): Prisma.PrismaPromise<GetAirBrandsAggregateType<T>>

    /**
     * Group by AirBrands.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirBrandsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AirBrandsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AirBrandsGroupByArgs['orderBy'] }
        : { orderBy?: AirBrandsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AirBrandsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAirBrandsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the AirBrands model
   */
  readonly fields: AirBrandsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for AirBrands.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AirBrandsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    AirModels<T extends AirBrands$AirModelsArgs<ExtArgs> = {}>(args?: Subset<T, AirBrands$AirModelsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AirModelsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the AirBrands model
   */
  interface AirBrandsFieldRefs {
    readonly id: FieldRef<"AirBrands", 'Int'>
    readonly name: FieldRef<"AirBrands", 'String'>
    readonly country: FieldRef<"AirBrands", 'String'>
    readonly description: FieldRef<"AirBrands", 'String'>
    readonly createdAt: FieldRef<"AirBrands", 'DateTime'>
    readonly updatedAt: FieldRef<"AirBrands", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * AirBrands findUnique
   */
  export type AirBrandsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrands
     */
    select?: AirBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirBrands
     */
    omit?: AirBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirBrandsInclude<ExtArgs> | null
    /**
     * Filter, which AirBrands to fetch.
     */
    where: AirBrandsWhereUniqueInput
  }

  /**
   * AirBrands findUniqueOrThrow
   */
  export type AirBrandsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrands
     */
    select?: AirBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirBrands
     */
    omit?: AirBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirBrandsInclude<ExtArgs> | null
    /**
     * Filter, which AirBrands to fetch.
     */
    where: AirBrandsWhereUniqueInput
  }

  /**
   * AirBrands findFirst
   */
  export type AirBrandsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrands
     */
    select?: AirBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirBrands
     */
    omit?: AirBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirBrandsInclude<ExtArgs> | null
    /**
     * Filter, which AirBrands to fetch.
     */
    where?: AirBrandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AirBrands to fetch.
     */
    orderBy?: AirBrandsOrderByWithRelationInput | AirBrandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AirBrands.
     */
    cursor?: AirBrandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AirBrands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AirBrands.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AirBrands.
     */
    distinct?: AirBrandsScalarFieldEnum | AirBrandsScalarFieldEnum[]
  }

  /**
   * AirBrands findFirstOrThrow
   */
  export type AirBrandsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrands
     */
    select?: AirBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirBrands
     */
    omit?: AirBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirBrandsInclude<ExtArgs> | null
    /**
     * Filter, which AirBrands to fetch.
     */
    where?: AirBrandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AirBrands to fetch.
     */
    orderBy?: AirBrandsOrderByWithRelationInput | AirBrandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AirBrands.
     */
    cursor?: AirBrandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AirBrands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AirBrands.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AirBrands.
     */
    distinct?: AirBrandsScalarFieldEnum | AirBrandsScalarFieldEnum[]
  }

  /**
   * AirBrands findMany
   */
  export type AirBrandsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrands
     */
    select?: AirBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirBrands
     */
    omit?: AirBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirBrandsInclude<ExtArgs> | null
    /**
     * Filter, which AirBrands to fetch.
     */
    where?: AirBrandsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AirBrands to fetch.
     */
    orderBy?: AirBrandsOrderByWithRelationInput | AirBrandsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AirBrands.
     */
    cursor?: AirBrandsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AirBrands from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AirBrands.
     */
    skip?: number
    distinct?: AirBrandsScalarFieldEnum | AirBrandsScalarFieldEnum[]
  }

  /**
   * AirBrands create
   */
  export type AirBrandsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrands
     */
    select?: AirBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirBrands
     */
    omit?: AirBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirBrandsInclude<ExtArgs> | null
    /**
     * The data needed to create a AirBrands.
     */
    data: XOR<AirBrandsCreateInput, AirBrandsUncheckedCreateInput>
  }

  /**
   * AirBrands createMany
   */
  export type AirBrandsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AirBrands.
     */
    data: AirBrandsCreateManyInput | AirBrandsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AirBrands createManyAndReturn
   */
  export type AirBrandsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrands
     */
    select?: AirBrandsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AirBrands
     */
    omit?: AirBrandsOmit<ExtArgs> | null
    /**
     * The data used to create many AirBrands.
     */
    data: AirBrandsCreateManyInput | AirBrandsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AirBrands update
   */
  export type AirBrandsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrands
     */
    select?: AirBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirBrands
     */
    omit?: AirBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirBrandsInclude<ExtArgs> | null
    /**
     * The data needed to update a AirBrands.
     */
    data: XOR<AirBrandsUpdateInput, AirBrandsUncheckedUpdateInput>
    /**
     * Choose, which AirBrands to update.
     */
    where: AirBrandsWhereUniqueInput
  }

  /**
   * AirBrands updateMany
   */
  export type AirBrandsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AirBrands.
     */
    data: XOR<AirBrandsUpdateManyMutationInput, AirBrandsUncheckedUpdateManyInput>
    /**
     * Filter which AirBrands to update
     */
    where?: AirBrandsWhereInput
    /**
     * Limit how many AirBrands to update.
     */
    limit?: number
  }

  /**
   * AirBrands updateManyAndReturn
   */
  export type AirBrandsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrands
     */
    select?: AirBrandsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AirBrands
     */
    omit?: AirBrandsOmit<ExtArgs> | null
    /**
     * The data used to update AirBrands.
     */
    data: XOR<AirBrandsUpdateManyMutationInput, AirBrandsUncheckedUpdateManyInput>
    /**
     * Filter which AirBrands to update
     */
    where?: AirBrandsWhereInput
    /**
     * Limit how many AirBrands to update.
     */
    limit?: number
  }

  /**
   * AirBrands upsert
   */
  export type AirBrandsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrands
     */
    select?: AirBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirBrands
     */
    omit?: AirBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirBrandsInclude<ExtArgs> | null
    /**
     * The filter to search for the AirBrands to update in case it exists.
     */
    where: AirBrandsWhereUniqueInput
    /**
     * In case the AirBrands found by the `where` argument doesn't exist, create a new AirBrands with this data.
     */
    create: XOR<AirBrandsCreateInput, AirBrandsUncheckedCreateInput>
    /**
     * In case the AirBrands was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AirBrandsUpdateInput, AirBrandsUncheckedUpdateInput>
  }

  /**
   * AirBrands delete
   */
  export type AirBrandsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrands
     */
    select?: AirBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirBrands
     */
    omit?: AirBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirBrandsInclude<ExtArgs> | null
    /**
     * Filter which AirBrands to delete.
     */
    where: AirBrandsWhereUniqueInput
  }

  /**
   * AirBrands deleteMany
   */
  export type AirBrandsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AirBrands to delete
     */
    where?: AirBrandsWhereInput
    /**
     * Limit how many AirBrands to delete.
     */
    limit?: number
  }

  /**
   * AirBrands.AirModels
   */
  export type AirBrands$AirModelsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsInclude<ExtArgs> | null
    where?: AirModelsWhereInput
    orderBy?: AirModelsOrderByWithRelationInput | AirModelsOrderByWithRelationInput[]
    cursor?: AirModelsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: AirModelsScalarFieldEnum | AirModelsScalarFieldEnum[]
  }

  /**
   * AirBrands without action
   */
  export type AirBrandsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirBrands
     */
    select?: AirBrandsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirBrands
     */
    omit?: AirBrandsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirBrandsInclude<ExtArgs> | null
  }


  /**
   * Model AirModels
   */

  export type AggregateAirModels = {
    _count: AirModelsCountAggregateOutputType | null
    _avg: AirModelsAvgAggregateOutputType | null
    _sum: AirModelsSumAggregateOutputType | null
    _min: AirModelsMinAggregateOutputType | null
    _max: AirModelsMaxAggregateOutputType | null
  }

  export type AirModelsAvgAggregateOutputType = {
    id: number | null
    brandId: number | null
    oil_carbon_per_unit: number | null
  }

  export type AirModelsSumAggregateOutputType = {
    id: number | null
    brandId: number | null
    oil_carbon_per_unit: number | null
  }

  export type AirModelsMinAggregateOutputType = {
    id: number | null
    brandId: number | null
    name: string | null
    description: string | null
    oil_type: $Enums.AirOilTypes | null
    oil_carbon_per_unit: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AirModelsMaxAggregateOutputType = {
    id: number | null
    brandId: number | null
    name: string | null
    description: string | null
    oil_type: $Enums.AirOilTypes | null
    oil_carbon_per_unit: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AirModelsCountAggregateOutputType = {
    id: number
    brandId: number
    name: number
    description: number
    oil_type: number
    oil_carbon_per_unit: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type AirModelsAvgAggregateInputType = {
    id?: true
    brandId?: true
    oil_carbon_per_unit?: true
  }

  export type AirModelsSumAggregateInputType = {
    id?: true
    brandId?: true
    oil_carbon_per_unit?: true
  }

  export type AirModelsMinAggregateInputType = {
    id?: true
    brandId?: true
    name?: true
    description?: true
    oil_type?: true
    oil_carbon_per_unit?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AirModelsMaxAggregateInputType = {
    id?: true
    brandId?: true
    name?: true
    description?: true
    oil_type?: true
    oil_carbon_per_unit?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AirModelsCountAggregateInputType = {
    id?: true
    brandId?: true
    name?: true
    description?: true
    oil_type?: true
    oil_carbon_per_unit?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type AirModelsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AirModels to aggregate.
     */
    where?: AirModelsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AirModels to fetch.
     */
    orderBy?: AirModelsOrderByWithRelationInput | AirModelsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AirModelsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AirModels from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AirModels.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AirModels
    **/
    _count?: true | AirModelsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AirModelsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AirModelsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AirModelsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AirModelsMaxAggregateInputType
  }

  export type GetAirModelsAggregateType<T extends AirModelsAggregateArgs> = {
        [P in keyof T & keyof AggregateAirModels]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAirModels[P]>
      : GetScalarType<T[P], AggregateAirModels[P]>
  }




  export type AirModelsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AirModelsWhereInput
    orderBy?: AirModelsOrderByWithAggregationInput | AirModelsOrderByWithAggregationInput[]
    by: AirModelsScalarFieldEnum[] | AirModelsScalarFieldEnum
    having?: AirModelsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AirModelsCountAggregateInputType | true
    _avg?: AirModelsAvgAggregateInputType
    _sum?: AirModelsSumAggregateInputType
    _min?: AirModelsMinAggregateInputType
    _max?: AirModelsMaxAggregateInputType
  }

  export type AirModelsGroupByOutputType = {
    id: number
    brandId: number
    name: string
    description: string | null
    oil_type: $Enums.AirOilTypes | null
    oil_carbon_per_unit: number | null
    createdAt: Date
    updatedAt: Date
    _count: AirModelsCountAggregateOutputType | null
    _avg: AirModelsAvgAggregateOutputType | null
    _sum: AirModelsSumAggregateOutputType | null
    _min: AirModelsMinAggregateOutputType | null
    _max: AirModelsMaxAggregateOutputType | null
  }

  type GetAirModelsGroupByPayload<T extends AirModelsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AirModelsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AirModelsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AirModelsGroupByOutputType[P]>
            : GetScalarType<T[P], AirModelsGroupByOutputType[P]>
        }
      >
    >


  export type AirModelsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    brandId?: boolean
    name?: boolean
    description?: boolean
    oil_type?: boolean
    oil_carbon_per_unit?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    brand?: boolean | AirBrandsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["airModels"]>

  export type AirModelsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    brandId?: boolean
    name?: boolean
    description?: boolean
    oil_type?: boolean
    oil_carbon_per_unit?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    brand?: boolean | AirBrandsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["airModels"]>

  export type AirModelsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    brandId?: boolean
    name?: boolean
    description?: boolean
    oil_type?: boolean
    oil_carbon_per_unit?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    brand?: boolean | AirBrandsDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["airModels"]>

  export type AirModelsSelectScalar = {
    id?: boolean
    brandId?: boolean
    name?: boolean
    description?: boolean
    oil_type?: boolean
    oil_carbon_per_unit?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type AirModelsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "brandId" | "name" | "description" | "oil_type" | "oil_carbon_per_unit" | "createdAt" | "updatedAt", ExtArgs["result"]["airModels"]>
  export type AirModelsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    brand?: boolean | AirBrandsDefaultArgs<ExtArgs>
  }
  export type AirModelsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    brand?: boolean | AirBrandsDefaultArgs<ExtArgs>
  }
  export type AirModelsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    brand?: boolean | AirBrandsDefaultArgs<ExtArgs>
  }

  export type $AirModelsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "AirModels"
    objects: {
      brand: Prisma.$AirBrandsPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      brandId: number
      name: string
      description: string | null
      oil_type: $Enums.AirOilTypes | null
      oil_carbon_per_unit: number | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["airModels"]>
    composites: {}
  }

  type AirModelsGetPayload<S extends boolean | null | undefined | AirModelsDefaultArgs> = $Result.GetResult<Prisma.$AirModelsPayload, S>

  type AirModelsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AirModelsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AirModelsCountAggregateInputType | true
    }

  export interface AirModelsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AirModels'], meta: { name: 'AirModels' } }
    /**
     * Find zero or one AirModels that matches the filter.
     * @param {AirModelsFindUniqueArgs} args - Arguments to find a AirModels
     * @example
     * // Get one AirModels
     * const airModels = await prisma.airModels.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AirModelsFindUniqueArgs>(args: SelectSubset<T, AirModelsFindUniqueArgs<ExtArgs>>): Prisma__AirModelsClient<$Result.GetResult<Prisma.$AirModelsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one AirModels that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AirModelsFindUniqueOrThrowArgs} args - Arguments to find a AirModels
     * @example
     * // Get one AirModels
     * const airModels = await prisma.airModels.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AirModelsFindUniqueOrThrowArgs>(args: SelectSubset<T, AirModelsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AirModelsClient<$Result.GetResult<Prisma.$AirModelsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AirModels that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirModelsFindFirstArgs} args - Arguments to find a AirModels
     * @example
     * // Get one AirModels
     * const airModels = await prisma.airModels.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AirModelsFindFirstArgs>(args?: SelectSubset<T, AirModelsFindFirstArgs<ExtArgs>>): Prisma__AirModelsClient<$Result.GetResult<Prisma.$AirModelsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AirModels that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirModelsFindFirstOrThrowArgs} args - Arguments to find a AirModels
     * @example
     * // Get one AirModels
     * const airModels = await prisma.airModels.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AirModelsFindFirstOrThrowArgs>(args?: SelectSubset<T, AirModelsFindFirstOrThrowArgs<ExtArgs>>): Prisma__AirModelsClient<$Result.GetResult<Prisma.$AirModelsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more AirModels that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirModelsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AirModels
     * const airModels = await prisma.airModels.findMany()
     * 
     * // Get first 10 AirModels
     * const airModels = await prisma.airModels.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const airModelsWithIdOnly = await prisma.airModels.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends AirModelsFindManyArgs>(args?: SelectSubset<T, AirModelsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AirModelsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a AirModels.
     * @param {AirModelsCreateArgs} args - Arguments to create a AirModels.
     * @example
     * // Create one AirModels
     * const AirModels = await prisma.airModels.create({
     *   data: {
     *     // ... data to create a AirModels
     *   }
     * })
     * 
     */
    create<T extends AirModelsCreateArgs>(args: SelectSubset<T, AirModelsCreateArgs<ExtArgs>>): Prisma__AirModelsClient<$Result.GetResult<Prisma.$AirModelsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many AirModels.
     * @param {AirModelsCreateManyArgs} args - Arguments to create many AirModels.
     * @example
     * // Create many AirModels
     * const airModels = await prisma.airModels.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AirModelsCreateManyArgs>(args?: SelectSubset<T, AirModelsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many AirModels and returns the data saved in the database.
     * @param {AirModelsCreateManyAndReturnArgs} args - Arguments to create many AirModels.
     * @example
     * // Create many AirModels
     * const airModels = await prisma.airModels.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many AirModels and only return the `id`
     * const airModelsWithIdOnly = await prisma.airModels.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends AirModelsCreateManyAndReturnArgs>(args?: SelectSubset<T, AirModelsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AirModelsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a AirModels.
     * @param {AirModelsDeleteArgs} args - Arguments to delete one AirModels.
     * @example
     * // Delete one AirModels
     * const AirModels = await prisma.airModels.delete({
     *   where: {
     *     // ... filter to delete one AirModels
     *   }
     * })
     * 
     */
    delete<T extends AirModelsDeleteArgs>(args: SelectSubset<T, AirModelsDeleteArgs<ExtArgs>>): Prisma__AirModelsClient<$Result.GetResult<Prisma.$AirModelsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one AirModels.
     * @param {AirModelsUpdateArgs} args - Arguments to update one AirModels.
     * @example
     * // Update one AirModels
     * const airModels = await prisma.airModels.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AirModelsUpdateArgs>(args: SelectSubset<T, AirModelsUpdateArgs<ExtArgs>>): Prisma__AirModelsClient<$Result.GetResult<Prisma.$AirModelsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more AirModels.
     * @param {AirModelsDeleteManyArgs} args - Arguments to filter AirModels to delete.
     * @example
     * // Delete a few AirModels
     * const { count } = await prisma.airModels.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AirModelsDeleteManyArgs>(args?: SelectSubset<T, AirModelsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AirModels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirModelsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AirModels
     * const airModels = await prisma.airModels.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AirModelsUpdateManyArgs>(args: SelectSubset<T, AirModelsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AirModels and returns the data updated in the database.
     * @param {AirModelsUpdateManyAndReturnArgs} args - Arguments to update many AirModels.
     * @example
     * // Update many AirModels
     * const airModels = await prisma.airModels.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more AirModels and only return the `id`
     * const airModelsWithIdOnly = await prisma.airModels.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends AirModelsUpdateManyAndReturnArgs>(args: SelectSubset<T, AirModelsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AirModelsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one AirModels.
     * @param {AirModelsUpsertArgs} args - Arguments to update or create a AirModels.
     * @example
     * // Update or create a AirModels
     * const airModels = await prisma.airModels.upsert({
     *   create: {
     *     // ... data to create a AirModels
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AirModels we want to update
     *   }
     * })
     */
    upsert<T extends AirModelsUpsertArgs>(args: SelectSubset<T, AirModelsUpsertArgs<ExtArgs>>): Prisma__AirModelsClient<$Result.GetResult<Prisma.$AirModelsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of AirModels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirModelsCountArgs} args - Arguments to filter AirModels to count.
     * @example
     * // Count the number of AirModels
     * const count = await prisma.airModels.count({
     *   where: {
     *     // ... the filter for the AirModels we want to count
     *   }
     * })
    **/
    count<T extends AirModelsCountArgs>(
      args?: Subset<T, AirModelsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AirModelsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AirModels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirModelsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AirModelsAggregateArgs>(args: Subset<T, AirModelsAggregateArgs>): Prisma.PrismaPromise<GetAirModelsAggregateType<T>>

    /**
     * Group by AirModels.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AirModelsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AirModelsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AirModelsGroupByArgs['orderBy'] }
        : { orderBy?: AirModelsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AirModelsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAirModelsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the AirModels model
   */
  readonly fields: AirModelsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for AirModels.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AirModelsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    brand<T extends AirBrandsDefaultArgs<ExtArgs> = {}>(args?: Subset<T, AirBrandsDefaultArgs<ExtArgs>>): Prisma__AirBrandsClient<$Result.GetResult<Prisma.$AirBrandsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the AirModels model
   */
  interface AirModelsFieldRefs {
    readonly id: FieldRef<"AirModels", 'Int'>
    readonly brandId: FieldRef<"AirModels", 'Int'>
    readonly name: FieldRef<"AirModels", 'String'>
    readonly description: FieldRef<"AirModels", 'String'>
    readonly oil_type: FieldRef<"AirModels", 'AirOilTypes'>
    readonly oil_carbon_per_unit: FieldRef<"AirModels", 'Float'>
    readonly createdAt: FieldRef<"AirModels", 'DateTime'>
    readonly updatedAt: FieldRef<"AirModels", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * AirModels findUnique
   */
  export type AirModelsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsInclude<ExtArgs> | null
    /**
     * Filter, which AirModels to fetch.
     */
    where: AirModelsWhereUniqueInput
  }

  /**
   * AirModels findUniqueOrThrow
   */
  export type AirModelsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsInclude<ExtArgs> | null
    /**
     * Filter, which AirModels to fetch.
     */
    where: AirModelsWhereUniqueInput
  }

  /**
   * AirModels findFirst
   */
  export type AirModelsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsInclude<ExtArgs> | null
    /**
     * Filter, which AirModels to fetch.
     */
    where?: AirModelsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AirModels to fetch.
     */
    orderBy?: AirModelsOrderByWithRelationInput | AirModelsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AirModels.
     */
    cursor?: AirModelsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AirModels from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AirModels.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AirModels.
     */
    distinct?: AirModelsScalarFieldEnum | AirModelsScalarFieldEnum[]
  }

  /**
   * AirModels findFirstOrThrow
   */
  export type AirModelsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsInclude<ExtArgs> | null
    /**
     * Filter, which AirModels to fetch.
     */
    where?: AirModelsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AirModels to fetch.
     */
    orderBy?: AirModelsOrderByWithRelationInput | AirModelsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AirModels.
     */
    cursor?: AirModelsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AirModels from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AirModels.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AirModels.
     */
    distinct?: AirModelsScalarFieldEnum | AirModelsScalarFieldEnum[]
  }

  /**
   * AirModels findMany
   */
  export type AirModelsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsInclude<ExtArgs> | null
    /**
     * Filter, which AirModels to fetch.
     */
    where?: AirModelsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AirModels to fetch.
     */
    orderBy?: AirModelsOrderByWithRelationInput | AirModelsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AirModels.
     */
    cursor?: AirModelsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AirModels from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AirModels.
     */
    skip?: number
    distinct?: AirModelsScalarFieldEnum | AirModelsScalarFieldEnum[]
  }

  /**
   * AirModels create
   */
  export type AirModelsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsInclude<ExtArgs> | null
    /**
     * The data needed to create a AirModels.
     */
    data: XOR<AirModelsCreateInput, AirModelsUncheckedCreateInput>
  }

  /**
   * AirModels createMany
   */
  export type AirModelsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AirModels.
     */
    data: AirModelsCreateManyInput | AirModelsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * AirModels createManyAndReturn
   */
  export type AirModelsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * The data used to create many AirModels.
     */
    data: AirModelsCreateManyInput | AirModelsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * AirModels update
   */
  export type AirModelsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsInclude<ExtArgs> | null
    /**
     * The data needed to update a AirModels.
     */
    data: XOR<AirModelsUpdateInput, AirModelsUncheckedUpdateInput>
    /**
     * Choose, which AirModels to update.
     */
    where: AirModelsWhereUniqueInput
  }

  /**
   * AirModels updateMany
   */
  export type AirModelsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AirModels.
     */
    data: XOR<AirModelsUpdateManyMutationInput, AirModelsUncheckedUpdateManyInput>
    /**
     * Filter which AirModels to update
     */
    where?: AirModelsWhereInput
    /**
     * Limit how many AirModels to update.
     */
    limit?: number
  }

  /**
   * AirModels updateManyAndReturn
   */
  export type AirModelsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * The data used to update AirModels.
     */
    data: XOR<AirModelsUpdateManyMutationInput, AirModelsUncheckedUpdateManyInput>
    /**
     * Filter which AirModels to update
     */
    where?: AirModelsWhereInput
    /**
     * Limit how many AirModels to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * AirModels upsert
   */
  export type AirModelsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsInclude<ExtArgs> | null
    /**
     * The filter to search for the AirModels to update in case it exists.
     */
    where: AirModelsWhereUniqueInput
    /**
     * In case the AirModels found by the `where` argument doesn't exist, create a new AirModels with this data.
     */
    create: XOR<AirModelsCreateInput, AirModelsUncheckedCreateInput>
    /**
     * In case the AirModels was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AirModelsUpdateInput, AirModelsUncheckedUpdateInput>
  }

  /**
   * AirModels delete
   */
  export type AirModelsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsInclude<ExtArgs> | null
    /**
     * Filter which AirModels to delete.
     */
    where: AirModelsWhereUniqueInput
  }

  /**
   * AirModels deleteMany
   */
  export type AirModelsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AirModels to delete
     */
    where?: AirModelsWhereInput
    /**
     * Limit how many AirModels to delete.
     */
    limit?: number
  }

  /**
   * AirModels without action
   */
  export type AirModelsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AirModels
     */
    select?: AirModelsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AirModels
     */
    omit?: AirModelsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: AirModelsInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const CustomersScalarFieldEnum: {
    id: 'id',
    username: 'username',
    email: 'email',
    password: 'password',
    phone: 'phone',
    address: 'address',
    city: 'city',
    state: 'state',
    zipCode: 'zipCode',
    province: 'province',
    isActive: 'isActive',
    isVerified: 'isVerified',
    lastLogin: 'lastLogin',
    profilePicture: 'profilePicture',
    organizationId: 'organizationId',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type CustomersScalarFieldEnum = (typeof CustomersScalarFieldEnum)[keyof typeof CustomersScalarFieldEnum]


  export const HistoryCalculatorScalarFieldEnum: {
    id: 'id',
    customerId: 'customerId',
    calculation: 'calculation',
    result: 'result',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type HistoryCalculatorScalarFieldEnum = (typeof HistoryCalculatorScalarFieldEnum)[keyof typeof HistoryCalculatorScalarFieldEnum]


  export const OrganizationScalarFieldEnum: {
    id: 'id',
    org_name: 'org_name',
    org_email: 'org_email',
    org_phone: 'org_phone',
    org_address: 'org_address',
    org_city: 'org_city',
    org_state: 'org_state',
    org_zipCode: 'org_zipCode',
    org_province: 'org_province',
    org_logo: 'org_logo',
    org_password: 'org_password',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type OrganizationScalarFieldEnum = (typeof OrganizationScalarFieldEnum)[keyof typeof OrganizationScalarFieldEnum]


  export const CarBrandsScalarFieldEnum: {
    id: 'id',
    name: 'name',
    country: 'country',
    description: 'description',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type CarBrandsScalarFieldEnum = (typeof CarBrandsScalarFieldEnum)[keyof typeof CarBrandsScalarFieldEnum]


  export const CarModelsScalarFieldEnum: {
    id: 'id',
    brandId: 'brandId',
    name: 'name',
    description: 'description',
    power_type: 'power_type',
    oil_type: 'oil_type',
    oil_carbon_per_unit: 'oil_carbon_per_unit',
    electric_carbon_per_unit: 'electric_carbon_per_unit',
    cubic_centimeter: 'cubic_centimeter',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type CarModelsScalarFieldEnum = (typeof CarModelsScalarFieldEnum)[keyof typeof CarModelsScalarFieldEnum]


  export const MotorcycleBrandsScalarFieldEnum: {
    id: 'id',
    name: 'name',
    country: 'country',
    description: 'description',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type MotorcycleBrandsScalarFieldEnum = (typeof MotorcycleBrandsScalarFieldEnum)[keyof typeof MotorcycleBrandsScalarFieldEnum]


  export const MotorcycleModelsScalarFieldEnum: {
    id: 'id',
    brandId: 'brandId',
    name: 'name',
    description: 'description',
    cubic_centimeter: 'cubic_centimeter',
    power_type: 'power_type',
    electric_carbon_per_unit: 'electric_carbon_per_unit',
    oil_carbon_per_unit: 'oil_carbon_per_unit',
    oil_type: 'oil_type',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type MotorcycleModelsScalarFieldEnum = (typeof MotorcycleModelsScalarFieldEnum)[keyof typeof MotorcycleModelsScalarFieldEnum]


  export const PublicTransportTypesScalarFieldEnum: {
    id: 'id',
    name: 'name',
    description: 'description',
    carbon_per_km: 'carbon_per_km',
    power_type: 'power_type',
    oil_type: 'oil_type',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type PublicTransportTypesScalarFieldEnum = (typeof PublicTransportTypesScalarFieldEnum)[keyof typeof PublicTransportTypesScalarFieldEnum]


  export const AirBrandsScalarFieldEnum: {
    id: 'id',
    name: 'name',
    country: 'country',
    description: 'description',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type AirBrandsScalarFieldEnum = (typeof AirBrandsScalarFieldEnum)[keyof typeof AirBrandsScalarFieldEnum]


  export const AirModelsScalarFieldEnum: {
    id: 'id',
    brandId: 'brandId',
    name: 'name',
    description: 'description',
    oil_type: 'oil_type',
    oil_carbon_per_unit: 'oil_carbon_per_unit',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type AirModelsScalarFieldEnum = (typeof AirModelsScalarFieldEnum)[keyof typeof AirModelsScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    


  /**
   * Reference to a field of type 'CarOilTypes[]'
   */
  export type ListEnumCarOilTypesFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'CarOilTypes[]'>
    


  /**
   * Reference to a field of type 'CarOilTypes'
   */
  export type EnumCarOilTypesFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'CarOilTypes'>
    


  /**
   * Reference to a field of type 'MotorBikeOilTypes[]'
   */
  export type ListEnumMotorBikeOilTypesFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'MotorBikeOilTypes[]'>
    


  /**
   * Reference to a field of type 'MotorBikeOilTypes'
   */
  export type EnumMotorBikeOilTypesFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'MotorBikeOilTypes'>
    


  /**
   * Reference to a field of type 'AirOilTypes'
   */
  export type EnumAirOilTypesFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'AirOilTypes'>
    


  /**
   * Reference to a field of type 'AirOilTypes[]'
   */
  export type ListEnumAirOilTypesFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'AirOilTypes[]'>
    
  /**
   * Deep Input Types
   */


  export type CustomersWhereInput = {
    AND?: CustomersWhereInput | CustomersWhereInput[]
    OR?: CustomersWhereInput[]
    NOT?: CustomersWhereInput | CustomersWhereInput[]
    id?: IntFilter<"Customers"> | number
    username?: StringFilter<"Customers"> | string
    email?: StringFilter<"Customers"> | string
    password?: StringNullableFilter<"Customers"> | string | null
    phone?: StringNullableFilter<"Customers"> | string | null
    address?: StringNullableFilter<"Customers"> | string | null
    city?: StringNullableFilter<"Customers"> | string | null
    state?: StringNullableFilter<"Customers"> | string | null
    zipCode?: StringNullableFilter<"Customers"> | string | null
    province?: StringNullableFilter<"Customers"> | string | null
    isActive?: BoolFilter<"Customers"> | boolean
    isVerified?: BoolFilter<"Customers"> | boolean
    lastLogin?: DateTimeNullableFilter<"Customers"> | Date | string | null
    profilePicture?: StringNullableFilter<"Customers"> | string | null
    organizationId?: IntNullableFilter<"Customers"> | number | null
    createdAt?: DateTimeFilter<"Customers"> | Date | string
    updatedAt?: DateTimeFilter<"Customers"> | Date | string
    HistoryCalculator?: HistoryCalculatorListRelationFilter
    org_adminOf?: OrganizationListRelationFilter
    org_memberOf?: OrganizationListRelationFilter
  }

  export type CustomersOrderByWithRelationInput = {
    id?: SortOrder
    username?: SortOrder
    email?: SortOrder
    password?: SortOrderInput | SortOrder
    phone?: SortOrderInput | SortOrder
    address?: SortOrderInput | SortOrder
    city?: SortOrderInput | SortOrder
    state?: SortOrderInput | SortOrder
    zipCode?: SortOrderInput | SortOrder
    province?: SortOrderInput | SortOrder
    isActive?: SortOrder
    isVerified?: SortOrder
    lastLogin?: SortOrderInput | SortOrder
    profilePicture?: SortOrderInput | SortOrder
    organizationId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    HistoryCalculator?: HistoryCalculatorOrderByRelationAggregateInput
    org_adminOf?: OrganizationOrderByRelationAggregateInput
    org_memberOf?: OrganizationOrderByRelationAggregateInput
  }

  export type CustomersWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    email?: string
    AND?: CustomersWhereInput | CustomersWhereInput[]
    OR?: CustomersWhereInput[]
    NOT?: CustomersWhereInput | CustomersWhereInput[]
    username?: StringFilter<"Customers"> | string
    password?: StringNullableFilter<"Customers"> | string | null
    phone?: StringNullableFilter<"Customers"> | string | null
    address?: StringNullableFilter<"Customers"> | string | null
    city?: StringNullableFilter<"Customers"> | string | null
    state?: StringNullableFilter<"Customers"> | string | null
    zipCode?: StringNullableFilter<"Customers"> | string | null
    province?: StringNullableFilter<"Customers"> | string | null
    isActive?: BoolFilter<"Customers"> | boolean
    isVerified?: BoolFilter<"Customers"> | boolean
    lastLogin?: DateTimeNullableFilter<"Customers"> | Date | string | null
    profilePicture?: StringNullableFilter<"Customers"> | string | null
    organizationId?: IntNullableFilter<"Customers"> | number | null
    createdAt?: DateTimeFilter<"Customers"> | Date | string
    updatedAt?: DateTimeFilter<"Customers"> | Date | string
    HistoryCalculator?: HistoryCalculatorListRelationFilter
    org_adminOf?: OrganizationListRelationFilter
    org_memberOf?: OrganizationListRelationFilter
  }, "id" | "email">

  export type CustomersOrderByWithAggregationInput = {
    id?: SortOrder
    username?: SortOrder
    email?: SortOrder
    password?: SortOrderInput | SortOrder
    phone?: SortOrderInput | SortOrder
    address?: SortOrderInput | SortOrder
    city?: SortOrderInput | SortOrder
    state?: SortOrderInput | SortOrder
    zipCode?: SortOrderInput | SortOrder
    province?: SortOrderInput | SortOrder
    isActive?: SortOrder
    isVerified?: SortOrder
    lastLogin?: SortOrderInput | SortOrder
    profilePicture?: SortOrderInput | SortOrder
    organizationId?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: CustomersCountOrderByAggregateInput
    _avg?: CustomersAvgOrderByAggregateInput
    _max?: CustomersMaxOrderByAggregateInput
    _min?: CustomersMinOrderByAggregateInput
    _sum?: CustomersSumOrderByAggregateInput
  }

  export type CustomersScalarWhereWithAggregatesInput = {
    AND?: CustomersScalarWhereWithAggregatesInput | CustomersScalarWhereWithAggregatesInput[]
    OR?: CustomersScalarWhereWithAggregatesInput[]
    NOT?: CustomersScalarWhereWithAggregatesInput | CustomersScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Customers"> | number
    username?: StringWithAggregatesFilter<"Customers"> | string
    email?: StringWithAggregatesFilter<"Customers"> | string
    password?: StringNullableWithAggregatesFilter<"Customers"> | string | null
    phone?: StringNullableWithAggregatesFilter<"Customers"> | string | null
    address?: StringNullableWithAggregatesFilter<"Customers"> | string | null
    city?: StringNullableWithAggregatesFilter<"Customers"> | string | null
    state?: StringNullableWithAggregatesFilter<"Customers"> | string | null
    zipCode?: StringNullableWithAggregatesFilter<"Customers"> | string | null
    province?: StringNullableWithAggregatesFilter<"Customers"> | string | null
    isActive?: BoolWithAggregatesFilter<"Customers"> | boolean
    isVerified?: BoolWithAggregatesFilter<"Customers"> | boolean
    lastLogin?: DateTimeNullableWithAggregatesFilter<"Customers"> | Date | string | null
    profilePicture?: StringNullableWithAggregatesFilter<"Customers"> | string | null
    organizationId?: IntNullableWithAggregatesFilter<"Customers"> | number | null
    createdAt?: DateTimeWithAggregatesFilter<"Customers"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Customers"> | Date | string
  }

  export type HistoryCalculatorWhereInput = {
    AND?: HistoryCalculatorWhereInput | HistoryCalculatorWhereInput[]
    OR?: HistoryCalculatorWhereInput[]
    NOT?: HistoryCalculatorWhereInput | HistoryCalculatorWhereInput[]
    id?: IntFilter<"HistoryCalculator"> | number
    customerId?: IntFilter<"HistoryCalculator"> | number
    calculation?: StringFilter<"HistoryCalculator"> | string
    result?: FloatFilter<"HistoryCalculator"> | number
    createdAt?: DateTimeFilter<"HistoryCalculator"> | Date | string
    updatedAt?: DateTimeFilter<"HistoryCalculator"> | Date | string
    customer?: XOR<CustomersScalarRelationFilter, CustomersWhereInput>
  }

  export type HistoryCalculatorOrderByWithRelationInput = {
    id?: SortOrder
    customerId?: SortOrder
    calculation?: SortOrder
    result?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    customer?: CustomersOrderByWithRelationInput
  }

  export type HistoryCalculatorWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: HistoryCalculatorWhereInput | HistoryCalculatorWhereInput[]
    OR?: HistoryCalculatorWhereInput[]
    NOT?: HistoryCalculatorWhereInput | HistoryCalculatorWhereInput[]
    customerId?: IntFilter<"HistoryCalculator"> | number
    calculation?: StringFilter<"HistoryCalculator"> | string
    result?: FloatFilter<"HistoryCalculator"> | number
    createdAt?: DateTimeFilter<"HistoryCalculator"> | Date | string
    updatedAt?: DateTimeFilter<"HistoryCalculator"> | Date | string
    customer?: XOR<CustomersScalarRelationFilter, CustomersWhereInput>
  }, "id">

  export type HistoryCalculatorOrderByWithAggregationInput = {
    id?: SortOrder
    customerId?: SortOrder
    calculation?: SortOrder
    result?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: HistoryCalculatorCountOrderByAggregateInput
    _avg?: HistoryCalculatorAvgOrderByAggregateInput
    _max?: HistoryCalculatorMaxOrderByAggregateInput
    _min?: HistoryCalculatorMinOrderByAggregateInput
    _sum?: HistoryCalculatorSumOrderByAggregateInput
  }

  export type HistoryCalculatorScalarWhereWithAggregatesInput = {
    AND?: HistoryCalculatorScalarWhereWithAggregatesInput | HistoryCalculatorScalarWhereWithAggregatesInput[]
    OR?: HistoryCalculatorScalarWhereWithAggregatesInput[]
    NOT?: HistoryCalculatorScalarWhereWithAggregatesInput | HistoryCalculatorScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"HistoryCalculator"> | number
    customerId?: IntWithAggregatesFilter<"HistoryCalculator"> | number
    calculation?: StringWithAggregatesFilter<"HistoryCalculator"> | string
    result?: FloatWithAggregatesFilter<"HistoryCalculator"> | number
    createdAt?: DateTimeWithAggregatesFilter<"HistoryCalculator"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"HistoryCalculator"> | Date | string
  }

  export type OrganizationWhereInput = {
    AND?: OrganizationWhereInput | OrganizationWhereInput[]
    OR?: OrganizationWhereInput[]
    NOT?: OrganizationWhereInput | OrganizationWhereInput[]
    id?: IntFilter<"Organization"> | number
    org_name?: StringFilter<"Organization"> | string
    org_email?: StringFilter<"Organization"> | string
    org_phone?: StringNullableFilter<"Organization"> | string | null
    org_address?: StringNullableFilter<"Organization"> | string | null
    org_city?: StringNullableFilter<"Organization"> | string | null
    org_state?: StringNullableFilter<"Organization"> | string | null
    org_zipCode?: StringNullableFilter<"Organization"> | string | null
    org_province?: StringNullableFilter<"Organization"> | string | null
    org_logo?: StringNullableFilter<"Organization"> | string | null
    org_password?: StringNullableFilter<"Organization"> | string | null
    createdAt?: DateTimeFilter<"Organization"> | Date | string
    updatedAt?: DateTimeFilter<"Organization"> | Date | string
    org_admins?: CustomersListRelationFilter
    org_members?: CustomersListRelationFilter
  }

  export type OrganizationOrderByWithRelationInput = {
    id?: SortOrder
    org_name?: SortOrder
    org_email?: SortOrder
    org_phone?: SortOrderInput | SortOrder
    org_address?: SortOrderInput | SortOrder
    org_city?: SortOrderInput | SortOrder
    org_state?: SortOrderInput | SortOrder
    org_zipCode?: SortOrderInput | SortOrder
    org_province?: SortOrderInput | SortOrder
    org_logo?: SortOrderInput | SortOrder
    org_password?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    org_admins?: CustomersOrderByRelationAggregateInput
    org_members?: CustomersOrderByRelationAggregateInput
  }

  export type OrganizationWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    org_email?: string
    AND?: OrganizationWhereInput | OrganizationWhereInput[]
    OR?: OrganizationWhereInput[]
    NOT?: OrganizationWhereInput | OrganizationWhereInput[]
    org_name?: StringFilter<"Organization"> | string
    org_phone?: StringNullableFilter<"Organization"> | string | null
    org_address?: StringNullableFilter<"Organization"> | string | null
    org_city?: StringNullableFilter<"Organization"> | string | null
    org_state?: StringNullableFilter<"Organization"> | string | null
    org_zipCode?: StringNullableFilter<"Organization"> | string | null
    org_province?: StringNullableFilter<"Organization"> | string | null
    org_logo?: StringNullableFilter<"Organization"> | string | null
    org_password?: StringNullableFilter<"Organization"> | string | null
    createdAt?: DateTimeFilter<"Organization"> | Date | string
    updatedAt?: DateTimeFilter<"Organization"> | Date | string
    org_admins?: CustomersListRelationFilter
    org_members?: CustomersListRelationFilter
  }, "id" | "org_email">

  export type OrganizationOrderByWithAggregationInput = {
    id?: SortOrder
    org_name?: SortOrder
    org_email?: SortOrder
    org_phone?: SortOrderInput | SortOrder
    org_address?: SortOrderInput | SortOrder
    org_city?: SortOrderInput | SortOrder
    org_state?: SortOrderInput | SortOrder
    org_zipCode?: SortOrderInput | SortOrder
    org_province?: SortOrderInput | SortOrder
    org_logo?: SortOrderInput | SortOrder
    org_password?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: OrganizationCountOrderByAggregateInput
    _avg?: OrganizationAvgOrderByAggregateInput
    _max?: OrganizationMaxOrderByAggregateInput
    _min?: OrganizationMinOrderByAggregateInput
    _sum?: OrganizationSumOrderByAggregateInput
  }

  export type OrganizationScalarWhereWithAggregatesInput = {
    AND?: OrganizationScalarWhereWithAggregatesInput | OrganizationScalarWhereWithAggregatesInput[]
    OR?: OrganizationScalarWhereWithAggregatesInput[]
    NOT?: OrganizationScalarWhereWithAggregatesInput | OrganizationScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"Organization"> | number
    org_name?: StringWithAggregatesFilter<"Organization"> | string
    org_email?: StringWithAggregatesFilter<"Organization"> | string
    org_phone?: StringNullableWithAggregatesFilter<"Organization"> | string | null
    org_address?: StringNullableWithAggregatesFilter<"Organization"> | string | null
    org_city?: StringNullableWithAggregatesFilter<"Organization"> | string | null
    org_state?: StringNullableWithAggregatesFilter<"Organization"> | string | null
    org_zipCode?: StringNullableWithAggregatesFilter<"Organization"> | string | null
    org_province?: StringNullableWithAggregatesFilter<"Organization"> | string | null
    org_logo?: StringNullableWithAggregatesFilter<"Organization"> | string | null
    org_password?: StringNullableWithAggregatesFilter<"Organization"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Organization"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Organization"> | Date | string
  }

  export type CarBrandsWhereInput = {
    AND?: CarBrandsWhereInput | CarBrandsWhereInput[]
    OR?: CarBrandsWhereInput[]
    NOT?: CarBrandsWhereInput | CarBrandsWhereInput[]
    id?: IntFilter<"CarBrands"> | number
    name?: StringFilter<"CarBrands"> | string
    country?: StringNullableFilter<"CarBrands"> | string | null
    description?: StringNullableFilter<"CarBrands"> | string | null
    createdAt?: DateTimeFilter<"CarBrands"> | Date | string
    updatedAt?: DateTimeFilter<"CarBrands"> | Date | string
    CarModels?: CarModelsListRelationFilter
  }

  export type CarBrandsOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrderInput | SortOrder
    description?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    CarModels?: CarModelsOrderByRelationAggregateInput
  }

  export type CarBrandsWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    name?: string
    AND?: CarBrandsWhereInput | CarBrandsWhereInput[]
    OR?: CarBrandsWhereInput[]
    NOT?: CarBrandsWhereInput | CarBrandsWhereInput[]
    country?: StringNullableFilter<"CarBrands"> | string | null
    description?: StringNullableFilter<"CarBrands"> | string | null
    createdAt?: DateTimeFilter<"CarBrands"> | Date | string
    updatedAt?: DateTimeFilter<"CarBrands"> | Date | string
    CarModels?: CarModelsListRelationFilter
  }, "id" | "name">

  export type CarBrandsOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrderInput | SortOrder
    description?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: CarBrandsCountOrderByAggregateInput
    _avg?: CarBrandsAvgOrderByAggregateInput
    _max?: CarBrandsMaxOrderByAggregateInput
    _min?: CarBrandsMinOrderByAggregateInput
    _sum?: CarBrandsSumOrderByAggregateInput
  }

  export type CarBrandsScalarWhereWithAggregatesInput = {
    AND?: CarBrandsScalarWhereWithAggregatesInput | CarBrandsScalarWhereWithAggregatesInput[]
    OR?: CarBrandsScalarWhereWithAggregatesInput[]
    NOT?: CarBrandsScalarWhereWithAggregatesInput | CarBrandsScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"CarBrands"> | number
    name?: StringWithAggregatesFilter<"CarBrands"> | string
    country?: StringNullableWithAggregatesFilter<"CarBrands"> | string | null
    description?: StringNullableWithAggregatesFilter<"CarBrands"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"CarBrands"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"CarBrands"> | Date | string
  }

  export type CarModelsWhereInput = {
    AND?: CarModelsWhereInput | CarModelsWhereInput[]
    OR?: CarModelsWhereInput[]
    NOT?: CarModelsWhereInput | CarModelsWhereInput[]
    id?: IntFilter<"CarModels"> | number
    brandId?: IntFilter<"CarModels"> | number
    name?: StringFilter<"CarModels"> | string
    description?: StringNullableFilter<"CarModels"> | string | null
    power_type?: StringNullableFilter<"CarModels"> | string | null
    oil_type?: EnumCarOilTypesNullableListFilter<"CarModels">
    oil_carbon_per_unit?: FloatNullableFilter<"CarModels"> | number | null
    electric_carbon_per_unit?: FloatNullableFilter<"CarModels"> | number | null
    cubic_centimeter?: IntNullableFilter<"CarModels"> | number | null
    createdAt?: DateTimeFilter<"CarModels"> | Date | string
    updatedAt?: DateTimeFilter<"CarModels"> | Date | string
    brand?: XOR<CarBrandsScalarRelationFilter, CarBrandsWhereInput>
  }

  export type CarModelsOrderByWithRelationInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    power_type?: SortOrderInput | SortOrder
    oil_type?: SortOrder
    oil_carbon_per_unit?: SortOrderInput | SortOrder
    electric_carbon_per_unit?: SortOrderInput | SortOrder
    cubic_centimeter?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    brand?: CarBrandsOrderByWithRelationInput
  }

  export type CarModelsWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: CarModelsWhereInput | CarModelsWhereInput[]
    OR?: CarModelsWhereInput[]
    NOT?: CarModelsWhereInput | CarModelsWhereInput[]
    brandId?: IntFilter<"CarModels"> | number
    name?: StringFilter<"CarModels"> | string
    description?: StringNullableFilter<"CarModels"> | string | null
    power_type?: StringNullableFilter<"CarModels"> | string | null
    oil_type?: EnumCarOilTypesNullableListFilter<"CarModels">
    oil_carbon_per_unit?: FloatNullableFilter<"CarModels"> | number | null
    electric_carbon_per_unit?: FloatNullableFilter<"CarModels"> | number | null
    cubic_centimeter?: IntNullableFilter<"CarModels"> | number | null
    createdAt?: DateTimeFilter<"CarModels"> | Date | string
    updatedAt?: DateTimeFilter<"CarModels"> | Date | string
    brand?: XOR<CarBrandsScalarRelationFilter, CarBrandsWhereInput>
  }, "id">

  export type CarModelsOrderByWithAggregationInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    power_type?: SortOrderInput | SortOrder
    oil_type?: SortOrder
    oil_carbon_per_unit?: SortOrderInput | SortOrder
    electric_carbon_per_unit?: SortOrderInput | SortOrder
    cubic_centimeter?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: CarModelsCountOrderByAggregateInput
    _avg?: CarModelsAvgOrderByAggregateInput
    _max?: CarModelsMaxOrderByAggregateInput
    _min?: CarModelsMinOrderByAggregateInput
    _sum?: CarModelsSumOrderByAggregateInput
  }

  export type CarModelsScalarWhereWithAggregatesInput = {
    AND?: CarModelsScalarWhereWithAggregatesInput | CarModelsScalarWhereWithAggregatesInput[]
    OR?: CarModelsScalarWhereWithAggregatesInput[]
    NOT?: CarModelsScalarWhereWithAggregatesInput | CarModelsScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"CarModels"> | number
    brandId?: IntWithAggregatesFilter<"CarModels"> | number
    name?: StringWithAggregatesFilter<"CarModels"> | string
    description?: StringNullableWithAggregatesFilter<"CarModels"> | string | null
    power_type?: StringNullableWithAggregatesFilter<"CarModels"> | string | null
    oil_type?: EnumCarOilTypesNullableListFilter<"CarModels">
    oil_carbon_per_unit?: FloatNullableWithAggregatesFilter<"CarModels"> | number | null
    electric_carbon_per_unit?: FloatNullableWithAggregatesFilter<"CarModels"> | number | null
    cubic_centimeter?: IntNullableWithAggregatesFilter<"CarModels"> | number | null
    createdAt?: DateTimeWithAggregatesFilter<"CarModels"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"CarModels"> | Date | string
  }

  export type MotorcycleBrandsWhereInput = {
    AND?: MotorcycleBrandsWhereInput | MotorcycleBrandsWhereInput[]
    OR?: MotorcycleBrandsWhereInput[]
    NOT?: MotorcycleBrandsWhereInput | MotorcycleBrandsWhereInput[]
    id?: IntFilter<"MotorcycleBrands"> | number
    name?: StringFilter<"MotorcycleBrands"> | string
    country?: StringNullableFilter<"MotorcycleBrands"> | string | null
    description?: StringNullableFilter<"MotorcycleBrands"> | string | null
    createdAt?: DateTimeFilter<"MotorcycleBrands"> | Date | string
    updatedAt?: DateTimeFilter<"MotorcycleBrands"> | Date | string
    MotorcycleModels?: MotorcycleModelsListRelationFilter
  }

  export type MotorcycleBrandsOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrderInput | SortOrder
    description?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    MotorcycleModels?: MotorcycleModelsOrderByRelationAggregateInput
  }

  export type MotorcycleBrandsWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    name?: string
    AND?: MotorcycleBrandsWhereInput | MotorcycleBrandsWhereInput[]
    OR?: MotorcycleBrandsWhereInput[]
    NOT?: MotorcycleBrandsWhereInput | MotorcycleBrandsWhereInput[]
    country?: StringNullableFilter<"MotorcycleBrands"> | string | null
    description?: StringNullableFilter<"MotorcycleBrands"> | string | null
    createdAt?: DateTimeFilter<"MotorcycleBrands"> | Date | string
    updatedAt?: DateTimeFilter<"MotorcycleBrands"> | Date | string
    MotorcycleModels?: MotorcycleModelsListRelationFilter
  }, "id" | "name">

  export type MotorcycleBrandsOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrderInput | SortOrder
    description?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: MotorcycleBrandsCountOrderByAggregateInput
    _avg?: MotorcycleBrandsAvgOrderByAggregateInput
    _max?: MotorcycleBrandsMaxOrderByAggregateInput
    _min?: MotorcycleBrandsMinOrderByAggregateInput
    _sum?: MotorcycleBrandsSumOrderByAggregateInput
  }

  export type MotorcycleBrandsScalarWhereWithAggregatesInput = {
    AND?: MotorcycleBrandsScalarWhereWithAggregatesInput | MotorcycleBrandsScalarWhereWithAggregatesInput[]
    OR?: MotorcycleBrandsScalarWhereWithAggregatesInput[]
    NOT?: MotorcycleBrandsScalarWhereWithAggregatesInput | MotorcycleBrandsScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"MotorcycleBrands"> | number
    name?: StringWithAggregatesFilter<"MotorcycleBrands"> | string
    country?: StringNullableWithAggregatesFilter<"MotorcycleBrands"> | string | null
    description?: StringNullableWithAggregatesFilter<"MotorcycleBrands"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"MotorcycleBrands"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"MotorcycleBrands"> | Date | string
  }

  export type MotorcycleModelsWhereInput = {
    AND?: MotorcycleModelsWhereInput | MotorcycleModelsWhereInput[]
    OR?: MotorcycleModelsWhereInput[]
    NOT?: MotorcycleModelsWhereInput | MotorcycleModelsWhereInput[]
    id?: IntFilter<"MotorcycleModels"> | number
    brandId?: IntFilter<"MotorcycleModels"> | number
    name?: StringFilter<"MotorcycleModels"> | string
    description?: StringNullableFilter<"MotorcycleModels"> | string | null
    cubic_centimeter?: IntNullableFilter<"MotorcycleModels"> | number | null
    power_type?: StringNullableFilter<"MotorcycleModels"> | string | null
    electric_carbon_per_unit?: FloatNullableFilter<"MotorcycleModels"> | number | null
    oil_carbon_per_unit?: FloatNullableFilter<"MotorcycleModels"> | number | null
    oil_type?: EnumMotorBikeOilTypesNullableListFilter<"MotorcycleModels">
    createdAt?: DateTimeFilter<"MotorcycleModels"> | Date | string
    updatedAt?: DateTimeFilter<"MotorcycleModels"> | Date | string
    brand?: XOR<MotorcycleBrandsScalarRelationFilter, MotorcycleBrandsWhereInput>
  }

  export type MotorcycleModelsOrderByWithRelationInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    cubic_centimeter?: SortOrderInput | SortOrder
    power_type?: SortOrderInput | SortOrder
    electric_carbon_per_unit?: SortOrderInput | SortOrder
    oil_carbon_per_unit?: SortOrderInput | SortOrder
    oil_type?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    brand?: MotorcycleBrandsOrderByWithRelationInput
  }

  export type MotorcycleModelsWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: MotorcycleModelsWhereInput | MotorcycleModelsWhereInput[]
    OR?: MotorcycleModelsWhereInput[]
    NOT?: MotorcycleModelsWhereInput | MotorcycleModelsWhereInput[]
    brandId?: IntFilter<"MotorcycleModels"> | number
    name?: StringFilter<"MotorcycleModels"> | string
    description?: StringNullableFilter<"MotorcycleModels"> | string | null
    cubic_centimeter?: IntNullableFilter<"MotorcycleModels"> | number | null
    power_type?: StringNullableFilter<"MotorcycleModels"> | string | null
    electric_carbon_per_unit?: FloatNullableFilter<"MotorcycleModels"> | number | null
    oil_carbon_per_unit?: FloatNullableFilter<"MotorcycleModels"> | number | null
    oil_type?: EnumMotorBikeOilTypesNullableListFilter<"MotorcycleModels">
    createdAt?: DateTimeFilter<"MotorcycleModels"> | Date | string
    updatedAt?: DateTimeFilter<"MotorcycleModels"> | Date | string
    brand?: XOR<MotorcycleBrandsScalarRelationFilter, MotorcycleBrandsWhereInput>
  }, "id">

  export type MotorcycleModelsOrderByWithAggregationInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    cubic_centimeter?: SortOrderInput | SortOrder
    power_type?: SortOrderInput | SortOrder
    electric_carbon_per_unit?: SortOrderInput | SortOrder
    oil_carbon_per_unit?: SortOrderInput | SortOrder
    oil_type?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: MotorcycleModelsCountOrderByAggregateInput
    _avg?: MotorcycleModelsAvgOrderByAggregateInput
    _max?: MotorcycleModelsMaxOrderByAggregateInput
    _min?: MotorcycleModelsMinOrderByAggregateInput
    _sum?: MotorcycleModelsSumOrderByAggregateInput
  }

  export type MotorcycleModelsScalarWhereWithAggregatesInput = {
    AND?: MotorcycleModelsScalarWhereWithAggregatesInput | MotorcycleModelsScalarWhereWithAggregatesInput[]
    OR?: MotorcycleModelsScalarWhereWithAggregatesInput[]
    NOT?: MotorcycleModelsScalarWhereWithAggregatesInput | MotorcycleModelsScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"MotorcycleModels"> | number
    brandId?: IntWithAggregatesFilter<"MotorcycleModels"> | number
    name?: StringWithAggregatesFilter<"MotorcycleModels"> | string
    description?: StringNullableWithAggregatesFilter<"MotorcycleModels"> | string | null
    cubic_centimeter?: IntNullableWithAggregatesFilter<"MotorcycleModels"> | number | null
    power_type?: StringNullableWithAggregatesFilter<"MotorcycleModels"> | string | null
    electric_carbon_per_unit?: FloatNullableWithAggregatesFilter<"MotorcycleModels"> | number | null
    oil_carbon_per_unit?: FloatNullableWithAggregatesFilter<"MotorcycleModels"> | number | null
    oil_type?: EnumMotorBikeOilTypesNullableListFilter<"MotorcycleModels">
    createdAt?: DateTimeWithAggregatesFilter<"MotorcycleModels"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"MotorcycleModels"> | Date | string
  }

  export type PublicTransportTypesWhereInput = {
    AND?: PublicTransportTypesWhereInput | PublicTransportTypesWhereInput[]
    OR?: PublicTransportTypesWhereInput[]
    NOT?: PublicTransportTypesWhereInput | PublicTransportTypesWhereInput[]
    id?: IntFilter<"PublicTransportTypes"> | number
    name?: StringFilter<"PublicTransportTypes"> | string
    description?: StringNullableFilter<"PublicTransportTypes"> | string | null
    carbon_per_km?: FloatFilter<"PublicTransportTypes"> | number
    power_type?: StringNullableFilter<"PublicTransportTypes"> | string | null
    oil_type?: EnumCarOilTypesNullableListFilter<"PublicTransportTypes">
    createdAt?: DateTimeFilter<"PublicTransportTypes"> | Date | string
    updatedAt?: DateTimeFilter<"PublicTransportTypes"> | Date | string
  }

  export type PublicTransportTypesOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    carbon_per_km?: SortOrder
    power_type?: SortOrderInput | SortOrder
    oil_type?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PublicTransportTypesWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    name?: string
    AND?: PublicTransportTypesWhereInput | PublicTransportTypesWhereInput[]
    OR?: PublicTransportTypesWhereInput[]
    NOT?: PublicTransportTypesWhereInput | PublicTransportTypesWhereInput[]
    description?: StringNullableFilter<"PublicTransportTypes"> | string | null
    carbon_per_km?: FloatFilter<"PublicTransportTypes"> | number
    power_type?: StringNullableFilter<"PublicTransportTypes"> | string | null
    oil_type?: EnumCarOilTypesNullableListFilter<"PublicTransportTypes">
    createdAt?: DateTimeFilter<"PublicTransportTypes"> | Date | string
    updatedAt?: DateTimeFilter<"PublicTransportTypes"> | Date | string
  }, "id" | "name">

  export type PublicTransportTypesOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    carbon_per_km?: SortOrder
    power_type?: SortOrderInput | SortOrder
    oil_type?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: PublicTransportTypesCountOrderByAggregateInput
    _avg?: PublicTransportTypesAvgOrderByAggregateInput
    _max?: PublicTransportTypesMaxOrderByAggregateInput
    _min?: PublicTransportTypesMinOrderByAggregateInput
    _sum?: PublicTransportTypesSumOrderByAggregateInput
  }

  export type PublicTransportTypesScalarWhereWithAggregatesInput = {
    AND?: PublicTransportTypesScalarWhereWithAggregatesInput | PublicTransportTypesScalarWhereWithAggregatesInput[]
    OR?: PublicTransportTypesScalarWhereWithAggregatesInput[]
    NOT?: PublicTransportTypesScalarWhereWithAggregatesInput | PublicTransportTypesScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"PublicTransportTypes"> | number
    name?: StringWithAggregatesFilter<"PublicTransportTypes"> | string
    description?: StringNullableWithAggregatesFilter<"PublicTransportTypes"> | string | null
    carbon_per_km?: FloatWithAggregatesFilter<"PublicTransportTypes"> | number
    power_type?: StringNullableWithAggregatesFilter<"PublicTransportTypes"> | string | null
    oil_type?: EnumCarOilTypesNullableListFilter<"PublicTransportTypes">
    createdAt?: DateTimeWithAggregatesFilter<"PublicTransportTypes"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"PublicTransportTypes"> | Date | string
  }

  export type AirBrandsWhereInput = {
    AND?: AirBrandsWhereInput | AirBrandsWhereInput[]
    OR?: AirBrandsWhereInput[]
    NOT?: AirBrandsWhereInput | AirBrandsWhereInput[]
    id?: IntFilter<"AirBrands"> | number
    name?: StringFilter<"AirBrands"> | string
    country?: StringNullableFilter<"AirBrands"> | string | null
    description?: StringNullableFilter<"AirBrands"> | string | null
    createdAt?: DateTimeFilter<"AirBrands"> | Date | string
    updatedAt?: DateTimeFilter<"AirBrands"> | Date | string
    AirModels?: AirModelsListRelationFilter
  }

  export type AirBrandsOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrderInput | SortOrder
    description?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    AirModels?: AirModelsOrderByRelationAggregateInput
  }

  export type AirBrandsWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    name?: string
    AND?: AirBrandsWhereInput | AirBrandsWhereInput[]
    OR?: AirBrandsWhereInput[]
    NOT?: AirBrandsWhereInput | AirBrandsWhereInput[]
    country?: StringNullableFilter<"AirBrands"> | string | null
    description?: StringNullableFilter<"AirBrands"> | string | null
    createdAt?: DateTimeFilter<"AirBrands"> | Date | string
    updatedAt?: DateTimeFilter<"AirBrands"> | Date | string
    AirModels?: AirModelsListRelationFilter
  }, "id" | "name">

  export type AirBrandsOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrderInput | SortOrder
    description?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: AirBrandsCountOrderByAggregateInput
    _avg?: AirBrandsAvgOrderByAggregateInput
    _max?: AirBrandsMaxOrderByAggregateInput
    _min?: AirBrandsMinOrderByAggregateInput
    _sum?: AirBrandsSumOrderByAggregateInput
  }

  export type AirBrandsScalarWhereWithAggregatesInput = {
    AND?: AirBrandsScalarWhereWithAggregatesInput | AirBrandsScalarWhereWithAggregatesInput[]
    OR?: AirBrandsScalarWhereWithAggregatesInput[]
    NOT?: AirBrandsScalarWhereWithAggregatesInput | AirBrandsScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"AirBrands"> | number
    name?: StringWithAggregatesFilter<"AirBrands"> | string
    country?: StringNullableWithAggregatesFilter<"AirBrands"> | string | null
    description?: StringNullableWithAggregatesFilter<"AirBrands"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"AirBrands"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"AirBrands"> | Date | string
  }

  export type AirModelsWhereInput = {
    AND?: AirModelsWhereInput | AirModelsWhereInput[]
    OR?: AirModelsWhereInput[]
    NOT?: AirModelsWhereInput | AirModelsWhereInput[]
    id?: IntFilter<"AirModels"> | number
    brandId?: IntFilter<"AirModels"> | number
    name?: StringFilter<"AirModels"> | string
    description?: StringNullableFilter<"AirModels"> | string | null
    oil_type?: EnumAirOilTypesNullableFilter<"AirModels"> | $Enums.AirOilTypes | null
    oil_carbon_per_unit?: FloatNullableFilter<"AirModels"> | number | null
    createdAt?: DateTimeFilter<"AirModels"> | Date | string
    updatedAt?: DateTimeFilter<"AirModels"> | Date | string
    brand?: XOR<AirBrandsScalarRelationFilter, AirBrandsWhereInput>
  }

  export type AirModelsOrderByWithRelationInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    oil_type?: SortOrderInput | SortOrder
    oil_carbon_per_unit?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    brand?: AirBrandsOrderByWithRelationInput
  }

  export type AirModelsWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: AirModelsWhereInput | AirModelsWhereInput[]
    OR?: AirModelsWhereInput[]
    NOT?: AirModelsWhereInput | AirModelsWhereInput[]
    brandId?: IntFilter<"AirModels"> | number
    name?: StringFilter<"AirModels"> | string
    description?: StringNullableFilter<"AirModels"> | string | null
    oil_type?: EnumAirOilTypesNullableFilter<"AirModels"> | $Enums.AirOilTypes | null
    oil_carbon_per_unit?: FloatNullableFilter<"AirModels"> | number | null
    createdAt?: DateTimeFilter<"AirModels"> | Date | string
    updatedAt?: DateTimeFilter<"AirModels"> | Date | string
    brand?: XOR<AirBrandsScalarRelationFilter, AirBrandsWhereInput>
  }, "id">

  export type AirModelsOrderByWithAggregationInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrderInput | SortOrder
    oil_type?: SortOrderInput | SortOrder
    oil_carbon_per_unit?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: AirModelsCountOrderByAggregateInput
    _avg?: AirModelsAvgOrderByAggregateInput
    _max?: AirModelsMaxOrderByAggregateInput
    _min?: AirModelsMinOrderByAggregateInput
    _sum?: AirModelsSumOrderByAggregateInput
  }

  export type AirModelsScalarWhereWithAggregatesInput = {
    AND?: AirModelsScalarWhereWithAggregatesInput | AirModelsScalarWhereWithAggregatesInput[]
    OR?: AirModelsScalarWhereWithAggregatesInput[]
    NOT?: AirModelsScalarWhereWithAggregatesInput | AirModelsScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"AirModels"> | number
    brandId?: IntWithAggregatesFilter<"AirModels"> | number
    name?: StringWithAggregatesFilter<"AirModels"> | string
    description?: StringNullableWithAggregatesFilter<"AirModels"> | string | null
    oil_type?: EnumAirOilTypesNullableWithAggregatesFilter<"AirModels"> | $Enums.AirOilTypes | null
    oil_carbon_per_unit?: FloatNullableWithAggregatesFilter<"AirModels"> | number | null
    createdAt?: DateTimeWithAggregatesFilter<"AirModels"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"AirModels"> | Date | string
  }

  export type CustomersCreateInput = {
    username: string
    email: string
    password?: string | null
    phone?: string | null
    address?: string | null
    city?: string | null
    state?: string | null
    zipCode?: string | null
    province?: string | null
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: Date | string | null
    profilePicture?: string | null
    organizationId?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
    HistoryCalculator?: HistoryCalculatorCreateNestedManyWithoutCustomerInput
    org_adminOf?: OrganizationCreateNestedManyWithoutOrg_adminsInput
    org_memberOf?: OrganizationCreateNestedManyWithoutOrg_membersInput
  }

  export type CustomersUncheckedCreateInput = {
    id?: number
    username: string
    email: string
    password?: string | null
    phone?: string | null
    address?: string | null
    city?: string | null
    state?: string | null
    zipCode?: string | null
    province?: string | null
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: Date | string | null
    profilePicture?: string | null
    organizationId?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
    HistoryCalculator?: HistoryCalculatorUncheckedCreateNestedManyWithoutCustomerInput
    org_adminOf?: OrganizationUncheckedCreateNestedManyWithoutOrg_adminsInput
    org_memberOf?: OrganizationUncheckedCreateNestedManyWithoutOrg_membersInput
  }

  export type CustomersUpdateInput = {
    username?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    province?: NullableStringFieldUpdateOperationsInput | string | null
    isActive?: BoolFieldUpdateOperationsInput | boolean
    isVerified?: BoolFieldUpdateOperationsInput | boolean
    lastLogin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    profilePicture?: NullableStringFieldUpdateOperationsInput | string | null
    organizationId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    HistoryCalculator?: HistoryCalculatorUpdateManyWithoutCustomerNestedInput
    org_adminOf?: OrganizationUpdateManyWithoutOrg_adminsNestedInput
    org_memberOf?: OrganizationUpdateManyWithoutOrg_membersNestedInput
  }

  export type CustomersUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    province?: NullableStringFieldUpdateOperationsInput | string | null
    isActive?: BoolFieldUpdateOperationsInput | boolean
    isVerified?: BoolFieldUpdateOperationsInput | boolean
    lastLogin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    profilePicture?: NullableStringFieldUpdateOperationsInput | string | null
    organizationId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    HistoryCalculator?: HistoryCalculatorUncheckedUpdateManyWithoutCustomerNestedInput
    org_adminOf?: OrganizationUncheckedUpdateManyWithoutOrg_adminsNestedInput
    org_memberOf?: OrganizationUncheckedUpdateManyWithoutOrg_membersNestedInput
  }

  export type CustomersCreateManyInput = {
    id?: number
    username: string
    email: string
    password?: string | null
    phone?: string | null
    address?: string | null
    city?: string | null
    state?: string | null
    zipCode?: string | null
    province?: string | null
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: Date | string | null
    profilePicture?: string | null
    organizationId?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CustomersUpdateManyMutationInput = {
    username?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    province?: NullableStringFieldUpdateOperationsInput | string | null
    isActive?: BoolFieldUpdateOperationsInput | boolean
    isVerified?: BoolFieldUpdateOperationsInput | boolean
    lastLogin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    profilePicture?: NullableStringFieldUpdateOperationsInput | string | null
    organizationId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CustomersUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    province?: NullableStringFieldUpdateOperationsInput | string | null
    isActive?: BoolFieldUpdateOperationsInput | boolean
    isVerified?: BoolFieldUpdateOperationsInput | boolean
    lastLogin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    profilePicture?: NullableStringFieldUpdateOperationsInput | string | null
    organizationId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HistoryCalculatorCreateInput = {
    calculation: string
    result: number
    createdAt?: Date | string
    updatedAt?: Date | string
    customer: CustomersCreateNestedOneWithoutHistoryCalculatorInput
  }

  export type HistoryCalculatorUncheckedCreateInput = {
    id?: number
    customerId: number
    calculation: string
    result: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type HistoryCalculatorUpdateInput = {
    calculation?: StringFieldUpdateOperationsInput | string
    result?: FloatFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    customer?: CustomersUpdateOneRequiredWithoutHistoryCalculatorNestedInput
  }

  export type HistoryCalculatorUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    customerId?: IntFieldUpdateOperationsInput | number
    calculation?: StringFieldUpdateOperationsInput | string
    result?: FloatFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HistoryCalculatorCreateManyInput = {
    id?: number
    customerId: number
    calculation: string
    result: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type HistoryCalculatorUpdateManyMutationInput = {
    calculation?: StringFieldUpdateOperationsInput | string
    result?: FloatFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HistoryCalculatorUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    customerId?: IntFieldUpdateOperationsInput | number
    calculation?: StringFieldUpdateOperationsInput | string
    result?: FloatFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type OrganizationCreateInput = {
    org_name: string
    org_email: string
    org_phone?: string | null
    org_address?: string | null
    org_city?: string | null
    org_state?: string | null
    org_zipCode?: string | null
    org_province?: string | null
    org_logo?: string | null
    org_password?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    org_admins?: CustomersCreateNestedManyWithoutOrg_adminOfInput
    org_members?: CustomersCreateNestedManyWithoutOrg_memberOfInput
  }

  export type OrganizationUncheckedCreateInput = {
    id?: number
    org_name: string
    org_email: string
    org_phone?: string | null
    org_address?: string | null
    org_city?: string | null
    org_state?: string | null
    org_zipCode?: string | null
    org_province?: string | null
    org_logo?: string | null
    org_password?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    org_admins?: CustomersUncheckedCreateNestedManyWithoutOrg_adminOfInput
    org_members?: CustomersUncheckedCreateNestedManyWithoutOrg_memberOfInput
  }

  export type OrganizationUpdateInput = {
    org_name?: StringFieldUpdateOperationsInput | string
    org_email?: StringFieldUpdateOperationsInput | string
    org_phone?: NullableStringFieldUpdateOperationsInput | string | null
    org_address?: NullableStringFieldUpdateOperationsInput | string | null
    org_city?: NullableStringFieldUpdateOperationsInput | string | null
    org_state?: NullableStringFieldUpdateOperationsInput | string | null
    org_zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    org_province?: NullableStringFieldUpdateOperationsInput | string | null
    org_logo?: NullableStringFieldUpdateOperationsInput | string | null
    org_password?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    org_admins?: CustomersUpdateManyWithoutOrg_adminOfNestedInput
    org_members?: CustomersUpdateManyWithoutOrg_memberOfNestedInput
  }

  export type OrganizationUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    org_name?: StringFieldUpdateOperationsInput | string
    org_email?: StringFieldUpdateOperationsInput | string
    org_phone?: NullableStringFieldUpdateOperationsInput | string | null
    org_address?: NullableStringFieldUpdateOperationsInput | string | null
    org_city?: NullableStringFieldUpdateOperationsInput | string | null
    org_state?: NullableStringFieldUpdateOperationsInput | string | null
    org_zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    org_province?: NullableStringFieldUpdateOperationsInput | string | null
    org_logo?: NullableStringFieldUpdateOperationsInput | string | null
    org_password?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    org_admins?: CustomersUncheckedUpdateManyWithoutOrg_adminOfNestedInput
    org_members?: CustomersUncheckedUpdateManyWithoutOrg_memberOfNestedInput
  }

  export type OrganizationCreateManyInput = {
    id?: number
    org_name: string
    org_email: string
    org_phone?: string | null
    org_address?: string | null
    org_city?: string | null
    org_state?: string | null
    org_zipCode?: string | null
    org_province?: string | null
    org_logo?: string | null
    org_password?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type OrganizationUpdateManyMutationInput = {
    org_name?: StringFieldUpdateOperationsInput | string
    org_email?: StringFieldUpdateOperationsInput | string
    org_phone?: NullableStringFieldUpdateOperationsInput | string | null
    org_address?: NullableStringFieldUpdateOperationsInput | string | null
    org_city?: NullableStringFieldUpdateOperationsInput | string | null
    org_state?: NullableStringFieldUpdateOperationsInput | string | null
    org_zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    org_province?: NullableStringFieldUpdateOperationsInput | string | null
    org_logo?: NullableStringFieldUpdateOperationsInput | string | null
    org_password?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type OrganizationUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    org_name?: StringFieldUpdateOperationsInput | string
    org_email?: StringFieldUpdateOperationsInput | string
    org_phone?: NullableStringFieldUpdateOperationsInput | string | null
    org_address?: NullableStringFieldUpdateOperationsInput | string | null
    org_city?: NullableStringFieldUpdateOperationsInput | string | null
    org_state?: NullableStringFieldUpdateOperationsInput | string | null
    org_zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    org_province?: NullableStringFieldUpdateOperationsInput | string | null
    org_logo?: NullableStringFieldUpdateOperationsInput | string | null
    org_password?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CarBrandsCreateInput = {
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    CarModels?: CarModelsCreateNestedManyWithoutBrandInput
  }

  export type CarBrandsUncheckedCreateInput = {
    id?: number
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    CarModels?: CarModelsUncheckedCreateNestedManyWithoutBrandInput
  }

  export type CarBrandsUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    CarModels?: CarModelsUpdateManyWithoutBrandNestedInput
  }

  export type CarBrandsUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    CarModels?: CarModelsUncheckedUpdateManyWithoutBrandNestedInput
  }

  export type CarBrandsCreateManyInput = {
    id?: number
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CarBrandsUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CarBrandsUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CarModelsCreateInput = {
    name: string
    description?: string | null
    power_type?: string | null
    oil_type?: CarModelsCreateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: number | null
    electric_carbon_per_unit?: number | null
    cubic_centimeter?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
    brand: CarBrandsCreateNestedOneWithoutCarModelsInput
  }

  export type CarModelsUncheckedCreateInput = {
    id?: number
    brandId: number
    name: string
    description?: string | null
    power_type?: string | null
    oil_type?: CarModelsCreateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: number | null
    electric_carbon_per_unit?: number | null
    cubic_centimeter?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CarModelsUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: CarModelsUpdateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    brand?: CarBrandsUpdateOneRequiredWithoutCarModelsNestedInput
  }

  export type CarModelsUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    brandId?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: CarModelsUpdateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CarModelsCreateManyInput = {
    id?: number
    brandId: number
    name: string
    description?: string | null
    power_type?: string | null
    oil_type?: CarModelsCreateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: number | null
    electric_carbon_per_unit?: number | null
    cubic_centimeter?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CarModelsUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: CarModelsUpdateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CarModelsUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    brandId?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: CarModelsUpdateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MotorcycleBrandsCreateInput = {
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    MotorcycleModels?: MotorcycleModelsCreateNestedManyWithoutBrandInput
  }

  export type MotorcycleBrandsUncheckedCreateInput = {
    id?: number
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    MotorcycleModels?: MotorcycleModelsUncheckedCreateNestedManyWithoutBrandInput
  }

  export type MotorcycleBrandsUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    MotorcycleModels?: MotorcycleModelsUpdateManyWithoutBrandNestedInput
  }

  export type MotorcycleBrandsUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    MotorcycleModels?: MotorcycleModelsUncheckedUpdateManyWithoutBrandNestedInput
  }

  export type MotorcycleBrandsCreateManyInput = {
    id?: number
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MotorcycleBrandsUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MotorcycleBrandsUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MotorcycleModelsCreateInput = {
    name: string
    description?: string | null
    cubic_centimeter?: number | null
    power_type?: string | null
    electric_carbon_per_unit?: number | null
    oil_carbon_per_unit?: number | null
    oil_type?: MotorcycleModelsCreateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: Date | string
    updatedAt?: Date | string
    brand: MotorcycleBrandsCreateNestedOneWithoutMotorcycleModelsInput
  }

  export type MotorcycleModelsUncheckedCreateInput = {
    id?: number
    brandId: number
    name: string
    description?: string | null
    cubic_centimeter?: number | null
    power_type?: string | null
    electric_carbon_per_unit?: number | null
    oil_carbon_per_unit?: number | null
    oil_type?: MotorcycleModelsCreateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MotorcycleModelsUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_type?: MotorcycleModelsUpdateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    brand?: MotorcycleBrandsUpdateOneRequiredWithoutMotorcycleModelsNestedInput
  }

  export type MotorcycleModelsUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    brandId?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_type?: MotorcycleModelsUpdateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MotorcycleModelsCreateManyInput = {
    id?: number
    brandId: number
    name: string
    description?: string | null
    cubic_centimeter?: number | null
    power_type?: string | null
    electric_carbon_per_unit?: number | null
    oil_carbon_per_unit?: number | null
    oil_type?: MotorcycleModelsCreateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MotorcycleModelsUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_type?: MotorcycleModelsUpdateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MotorcycleModelsUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    brandId?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_type?: MotorcycleModelsUpdateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PublicTransportTypesCreateInput = {
    name: string
    description?: string | null
    carbon_per_km?: number
    power_type?: string | null
    oil_type?: PublicTransportTypesCreateoil_typeInput | $Enums.CarOilTypes[]
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PublicTransportTypesUncheckedCreateInput = {
    id?: number
    name: string
    description?: string | null
    carbon_per_km?: number
    power_type?: string | null
    oil_type?: PublicTransportTypesCreateoil_typeInput | $Enums.CarOilTypes[]
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PublicTransportTypesUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    carbon_per_km?: FloatFieldUpdateOperationsInput | number
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: PublicTransportTypesUpdateoil_typeInput | $Enums.CarOilTypes[]
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PublicTransportTypesUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    carbon_per_km?: FloatFieldUpdateOperationsInput | number
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: PublicTransportTypesUpdateoil_typeInput | $Enums.CarOilTypes[]
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PublicTransportTypesCreateManyInput = {
    id?: number
    name: string
    description?: string | null
    carbon_per_km?: number
    power_type?: string | null
    oil_type?: PublicTransportTypesCreateoil_typeInput | $Enums.CarOilTypes[]
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PublicTransportTypesUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    carbon_per_km?: FloatFieldUpdateOperationsInput | number
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: PublicTransportTypesUpdateoil_typeInput | $Enums.CarOilTypes[]
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PublicTransportTypesUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    carbon_per_km?: FloatFieldUpdateOperationsInput | number
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: PublicTransportTypesUpdateoil_typeInput | $Enums.CarOilTypes[]
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AirBrandsCreateInput = {
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    AirModels?: AirModelsCreateNestedManyWithoutBrandInput
  }

  export type AirBrandsUncheckedCreateInput = {
    id?: number
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    AirModels?: AirModelsUncheckedCreateNestedManyWithoutBrandInput
  }

  export type AirBrandsUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    AirModels?: AirModelsUpdateManyWithoutBrandNestedInput
  }

  export type AirBrandsUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    AirModels?: AirModelsUncheckedUpdateManyWithoutBrandNestedInput
  }

  export type AirBrandsCreateManyInput = {
    id?: number
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AirBrandsUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AirBrandsUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AirModelsCreateInput = {
    name: string
    description?: string | null
    oil_type?: $Enums.AirOilTypes | null
    oil_carbon_per_unit?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
    brand: AirBrandsCreateNestedOneWithoutAirModelsInput
  }

  export type AirModelsUncheckedCreateInput = {
    id?: number
    brandId: number
    name: string
    description?: string | null
    oil_type?: $Enums.AirOilTypes | null
    oil_carbon_per_unit?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AirModelsUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: NullableEnumAirOilTypesFieldUpdateOperationsInput | $Enums.AirOilTypes | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    brand?: AirBrandsUpdateOneRequiredWithoutAirModelsNestedInput
  }

  export type AirModelsUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    brandId?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: NullableEnumAirOilTypesFieldUpdateOperationsInput | $Enums.AirOilTypes | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AirModelsCreateManyInput = {
    id?: number
    brandId: number
    name: string
    description?: string | null
    oil_type?: $Enums.AirOilTypes | null
    oil_carbon_per_unit?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AirModelsUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: NullableEnumAirOilTypesFieldUpdateOperationsInput | $Enums.AirOilTypes | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AirModelsUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    brandId?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: NullableEnumAirOilTypesFieldUpdateOperationsInput | $Enums.AirOilTypes | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type HistoryCalculatorListRelationFilter = {
    every?: HistoryCalculatorWhereInput
    some?: HistoryCalculatorWhereInput
    none?: HistoryCalculatorWhereInput
  }

  export type OrganizationListRelationFilter = {
    every?: OrganizationWhereInput
    some?: OrganizationWhereInput
    none?: OrganizationWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type HistoryCalculatorOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type OrganizationOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type CustomersCountOrderByAggregateInput = {
    id?: SortOrder
    username?: SortOrder
    email?: SortOrder
    password?: SortOrder
    phone?: SortOrder
    address?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zipCode?: SortOrder
    province?: SortOrder
    isActive?: SortOrder
    isVerified?: SortOrder
    lastLogin?: SortOrder
    profilePicture?: SortOrder
    organizationId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CustomersAvgOrderByAggregateInput = {
    id?: SortOrder
    organizationId?: SortOrder
  }

  export type CustomersMaxOrderByAggregateInput = {
    id?: SortOrder
    username?: SortOrder
    email?: SortOrder
    password?: SortOrder
    phone?: SortOrder
    address?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zipCode?: SortOrder
    province?: SortOrder
    isActive?: SortOrder
    isVerified?: SortOrder
    lastLogin?: SortOrder
    profilePicture?: SortOrder
    organizationId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CustomersMinOrderByAggregateInput = {
    id?: SortOrder
    username?: SortOrder
    email?: SortOrder
    password?: SortOrder
    phone?: SortOrder
    address?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zipCode?: SortOrder
    province?: SortOrder
    isActive?: SortOrder
    isVerified?: SortOrder
    lastLogin?: SortOrder
    profilePicture?: SortOrder
    organizationId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CustomersSumOrderByAggregateInput = {
    id?: SortOrder
    organizationId?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type FloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type CustomersScalarRelationFilter = {
    is?: CustomersWhereInput
    isNot?: CustomersWhereInput
  }

  export type HistoryCalculatorCountOrderByAggregateInput = {
    id?: SortOrder
    customerId?: SortOrder
    calculation?: SortOrder
    result?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type HistoryCalculatorAvgOrderByAggregateInput = {
    id?: SortOrder
    customerId?: SortOrder
    result?: SortOrder
  }

  export type HistoryCalculatorMaxOrderByAggregateInput = {
    id?: SortOrder
    customerId?: SortOrder
    calculation?: SortOrder
    result?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type HistoryCalculatorMinOrderByAggregateInput = {
    id?: SortOrder
    customerId?: SortOrder
    calculation?: SortOrder
    result?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type HistoryCalculatorSumOrderByAggregateInput = {
    id?: SortOrder
    customerId?: SortOrder
    result?: SortOrder
  }

  export type FloatWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedFloatFilter<$PrismaModel>
    _min?: NestedFloatFilter<$PrismaModel>
    _max?: NestedFloatFilter<$PrismaModel>
  }

  export type CustomersListRelationFilter = {
    every?: CustomersWhereInput
    some?: CustomersWhereInput
    none?: CustomersWhereInput
  }

  export type CustomersOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type OrganizationCountOrderByAggregateInput = {
    id?: SortOrder
    org_name?: SortOrder
    org_email?: SortOrder
    org_phone?: SortOrder
    org_address?: SortOrder
    org_city?: SortOrder
    org_state?: SortOrder
    org_zipCode?: SortOrder
    org_province?: SortOrder
    org_logo?: SortOrder
    org_password?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type OrganizationAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type OrganizationMaxOrderByAggregateInput = {
    id?: SortOrder
    org_name?: SortOrder
    org_email?: SortOrder
    org_phone?: SortOrder
    org_address?: SortOrder
    org_city?: SortOrder
    org_state?: SortOrder
    org_zipCode?: SortOrder
    org_province?: SortOrder
    org_logo?: SortOrder
    org_password?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type OrganizationMinOrderByAggregateInput = {
    id?: SortOrder
    org_name?: SortOrder
    org_email?: SortOrder
    org_phone?: SortOrder
    org_address?: SortOrder
    org_city?: SortOrder
    org_state?: SortOrder
    org_zipCode?: SortOrder
    org_province?: SortOrder
    org_logo?: SortOrder
    org_password?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type OrganizationSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type CarModelsListRelationFilter = {
    every?: CarModelsWhereInput
    some?: CarModelsWhereInput
    none?: CarModelsWhereInput
  }

  export type CarModelsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type CarBrandsCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CarBrandsAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type CarBrandsMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CarBrandsMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CarBrandsSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type EnumCarOilTypesNullableListFilter<$PrismaModel = never> = {
    equals?: $Enums.CarOilTypes[] | ListEnumCarOilTypesFieldRefInput<$PrismaModel> | null
    has?: $Enums.CarOilTypes | EnumCarOilTypesFieldRefInput<$PrismaModel> | null
    hasEvery?: $Enums.CarOilTypes[] | ListEnumCarOilTypesFieldRefInput<$PrismaModel>
    hasSome?: $Enums.CarOilTypes[] | ListEnumCarOilTypesFieldRefInput<$PrismaModel>
    isEmpty?: boolean
  }

  export type FloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type CarBrandsScalarRelationFilter = {
    is?: CarBrandsWhereInput
    isNot?: CarBrandsWhereInput
  }

  export type CarModelsCountOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrder
    power_type?: SortOrder
    oil_type?: SortOrder
    oil_carbon_per_unit?: SortOrder
    electric_carbon_per_unit?: SortOrder
    cubic_centimeter?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CarModelsAvgOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    oil_carbon_per_unit?: SortOrder
    electric_carbon_per_unit?: SortOrder
    cubic_centimeter?: SortOrder
  }

  export type CarModelsMaxOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrder
    power_type?: SortOrder
    oil_carbon_per_unit?: SortOrder
    electric_carbon_per_unit?: SortOrder
    cubic_centimeter?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CarModelsMinOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrder
    power_type?: SortOrder
    oil_carbon_per_unit?: SortOrder
    electric_carbon_per_unit?: SortOrder
    cubic_centimeter?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CarModelsSumOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    oil_carbon_per_unit?: SortOrder
    electric_carbon_per_unit?: SortOrder
    cubic_centimeter?: SortOrder
  }

  export type FloatNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedFloatNullableFilter<$PrismaModel>
    _min?: NestedFloatNullableFilter<$PrismaModel>
    _max?: NestedFloatNullableFilter<$PrismaModel>
  }

  export type MotorcycleModelsListRelationFilter = {
    every?: MotorcycleModelsWhereInput
    some?: MotorcycleModelsWhereInput
    none?: MotorcycleModelsWhereInput
  }

  export type MotorcycleModelsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type MotorcycleBrandsCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type MotorcycleBrandsAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type MotorcycleBrandsMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type MotorcycleBrandsMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type MotorcycleBrandsSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type EnumMotorBikeOilTypesNullableListFilter<$PrismaModel = never> = {
    equals?: $Enums.MotorBikeOilTypes[] | ListEnumMotorBikeOilTypesFieldRefInput<$PrismaModel> | null
    has?: $Enums.MotorBikeOilTypes | EnumMotorBikeOilTypesFieldRefInput<$PrismaModel> | null
    hasEvery?: $Enums.MotorBikeOilTypes[] | ListEnumMotorBikeOilTypesFieldRefInput<$PrismaModel>
    hasSome?: $Enums.MotorBikeOilTypes[] | ListEnumMotorBikeOilTypesFieldRefInput<$PrismaModel>
    isEmpty?: boolean
  }

  export type MotorcycleBrandsScalarRelationFilter = {
    is?: MotorcycleBrandsWhereInput
    isNot?: MotorcycleBrandsWhereInput
  }

  export type MotorcycleModelsCountOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrder
    cubic_centimeter?: SortOrder
    power_type?: SortOrder
    electric_carbon_per_unit?: SortOrder
    oil_carbon_per_unit?: SortOrder
    oil_type?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type MotorcycleModelsAvgOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    cubic_centimeter?: SortOrder
    electric_carbon_per_unit?: SortOrder
    oil_carbon_per_unit?: SortOrder
  }

  export type MotorcycleModelsMaxOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrder
    cubic_centimeter?: SortOrder
    power_type?: SortOrder
    electric_carbon_per_unit?: SortOrder
    oil_carbon_per_unit?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type MotorcycleModelsMinOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrder
    cubic_centimeter?: SortOrder
    power_type?: SortOrder
    electric_carbon_per_unit?: SortOrder
    oil_carbon_per_unit?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type MotorcycleModelsSumOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    cubic_centimeter?: SortOrder
    electric_carbon_per_unit?: SortOrder
    oil_carbon_per_unit?: SortOrder
  }

  export type PublicTransportTypesCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    carbon_per_km?: SortOrder
    power_type?: SortOrder
    oil_type?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PublicTransportTypesAvgOrderByAggregateInput = {
    id?: SortOrder
    carbon_per_km?: SortOrder
  }

  export type PublicTransportTypesMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    carbon_per_km?: SortOrder
    power_type?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PublicTransportTypesMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    description?: SortOrder
    carbon_per_km?: SortOrder
    power_type?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PublicTransportTypesSumOrderByAggregateInput = {
    id?: SortOrder
    carbon_per_km?: SortOrder
  }

  export type AirModelsListRelationFilter = {
    every?: AirModelsWhereInput
    some?: AirModelsWhereInput
    none?: AirModelsWhereInput
  }

  export type AirModelsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type AirBrandsCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AirBrandsAvgOrderByAggregateInput = {
    id?: SortOrder
  }

  export type AirBrandsMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AirBrandsMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    country?: SortOrder
    description?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AirBrandsSumOrderByAggregateInput = {
    id?: SortOrder
  }

  export type EnumAirOilTypesNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.AirOilTypes | EnumAirOilTypesFieldRefInput<$PrismaModel> | null
    in?: $Enums.AirOilTypes[] | ListEnumAirOilTypesFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.AirOilTypes[] | ListEnumAirOilTypesFieldRefInput<$PrismaModel> | null
    not?: NestedEnumAirOilTypesNullableFilter<$PrismaModel> | $Enums.AirOilTypes | null
  }

  export type AirBrandsScalarRelationFilter = {
    is?: AirBrandsWhereInput
    isNot?: AirBrandsWhereInput
  }

  export type AirModelsCountOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrder
    oil_type?: SortOrder
    oil_carbon_per_unit?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AirModelsAvgOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    oil_carbon_per_unit?: SortOrder
  }

  export type AirModelsMaxOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrder
    oil_type?: SortOrder
    oil_carbon_per_unit?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AirModelsMinOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    name?: SortOrder
    description?: SortOrder
    oil_type?: SortOrder
    oil_carbon_per_unit?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AirModelsSumOrderByAggregateInput = {
    id?: SortOrder
    brandId?: SortOrder
    oil_carbon_per_unit?: SortOrder
  }

  export type EnumAirOilTypesNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.AirOilTypes | EnumAirOilTypesFieldRefInput<$PrismaModel> | null
    in?: $Enums.AirOilTypes[] | ListEnumAirOilTypesFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.AirOilTypes[] | ListEnumAirOilTypesFieldRefInput<$PrismaModel> | null
    not?: NestedEnumAirOilTypesNullableWithAggregatesFilter<$PrismaModel> | $Enums.AirOilTypes | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumAirOilTypesNullableFilter<$PrismaModel>
    _max?: NestedEnumAirOilTypesNullableFilter<$PrismaModel>
  }

  export type HistoryCalculatorCreateNestedManyWithoutCustomerInput = {
    create?: XOR<HistoryCalculatorCreateWithoutCustomerInput, HistoryCalculatorUncheckedCreateWithoutCustomerInput> | HistoryCalculatorCreateWithoutCustomerInput[] | HistoryCalculatorUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: HistoryCalculatorCreateOrConnectWithoutCustomerInput | HistoryCalculatorCreateOrConnectWithoutCustomerInput[]
    createMany?: HistoryCalculatorCreateManyCustomerInputEnvelope
    connect?: HistoryCalculatorWhereUniqueInput | HistoryCalculatorWhereUniqueInput[]
  }

  export type OrganizationCreateNestedManyWithoutOrg_adminsInput = {
    create?: XOR<OrganizationCreateWithoutOrg_adminsInput, OrganizationUncheckedCreateWithoutOrg_adminsInput> | OrganizationCreateWithoutOrg_adminsInput[] | OrganizationUncheckedCreateWithoutOrg_adminsInput[]
    connectOrCreate?: OrganizationCreateOrConnectWithoutOrg_adminsInput | OrganizationCreateOrConnectWithoutOrg_adminsInput[]
    connect?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
  }

  export type OrganizationCreateNestedManyWithoutOrg_membersInput = {
    create?: XOR<OrganizationCreateWithoutOrg_membersInput, OrganizationUncheckedCreateWithoutOrg_membersInput> | OrganizationCreateWithoutOrg_membersInput[] | OrganizationUncheckedCreateWithoutOrg_membersInput[]
    connectOrCreate?: OrganizationCreateOrConnectWithoutOrg_membersInput | OrganizationCreateOrConnectWithoutOrg_membersInput[]
    connect?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
  }

  export type HistoryCalculatorUncheckedCreateNestedManyWithoutCustomerInput = {
    create?: XOR<HistoryCalculatorCreateWithoutCustomerInput, HistoryCalculatorUncheckedCreateWithoutCustomerInput> | HistoryCalculatorCreateWithoutCustomerInput[] | HistoryCalculatorUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: HistoryCalculatorCreateOrConnectWithoutCustomerInput | HistoryCalculatorCreateOrConnectWithoutCustomerInput[]
    createMany?: HistoryCalculatorCreateManyCustomerInputEnvelope
    connect?: HistoryCalculatorWhereUniqueInput | HistoryCalculatorWhereUniqueInput[]
  }

  export type OrganizationUncheckedCreateNestedManyWithoutOrg_adminsInput = {
    create?: XOR<OrganizationCreateWithoutOrg_adminsInput, OrganizationUncheckedCreateWithoutOrg_adminsInput> | OrganizationCreateWithoutOrg_adminsInput[] | OrganizationUncheckedCreateWithoutOrg_adminsInput[]
    connectOrCreate?: OrganizationCreateOrConnectWithoutOrg_adminsInput | OrganizationCreateOrConnectWithoutOrg_adminsInput[]
    connect?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
  }

  export type OrganizationUncheckedCreateNestedManyWithoutOrg_membersInput = {
    create?: XOR<OrganizationCreateWithoutOrg_membersInput, OrganizationUncheckedCreateWithoutOrg_membersInput> | OrganizationCreateWithoutOrg_membersInput[] | OrganizationUncheckedCreateWithoutOrg_membersInput[]
    connectOrCreate?: OrganizationCreateOrConnectWithoutOrg_membersInput | OrganizationCreateOrConnectWithoutOrg_membersInput[]
    connect?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type HistoryCalculatorUpdateManyWithoutCustomerNestedInput = {
    create?: XOR<HistoryCalculatorCreateWithoutCustomerInput, HistoryCalculatorUncheckedCreateWithoutCustomerInput> | HistoryCalculatorCreateWithoutCustomerInput[] | HistoryCalculatorUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: HistoryCalculatorCreateOrConnectWithoutCustomerInput | HistoryCalculatorCreateOrConnectWithoutCustomerInput[]
    upsert?: HistoryCalculatorUpsertWithWhereUniqueWithoutCustomerInput | HistoryCalculatorUpsertWithWhereUniqueWithoutCustomerInput[]
    createMany?: HistoryCalculatorCreateManyCustomerInputEnvelope
    set?: HistoryCalculatorWhereUniqueInput | HistoryCalculatorWhereUniqueInput[]
    disconnect?: HistoryCalculatorWhereUniqueInput | HistoryCalculatorWhereUniqueInput[]
    delete?: HistoryCalculatorWhereUniqueInput | HistoryCalculatorWhereUniqueInput[]
    connect?: HistoryCalculatorWhereUniqueInput | HistoryCalculatorWhereUniqueInput[]
    update?: HistoryCalculatorUpdateWithWhereUniqueWithoutCustomerInput | HistoryCalculatorUpdateWithWhereUniqueWithoutCustomerInput[]
    updateMany?: HistoryCalculatorUpdateManyWithWhereWithoutCustomerInput | HistoryCalculatorUpdateManyWithWhereWithoutCustomerInput[]
    deleteMany?: HistoryCalculatorScalarWhereInput | HistoryCalculatorScalarWhereInput[]
  }

  export type OrganizationUpdateManyWithoutOrg_adminsNestedInput = {
    create?: XOR<OrganizationCreateWithoutOrg_adminsInput, OrganizationUncheckedCreateWithoutOrg_adminsInput> | OrganizationCreateWithoutOrg_adminsInput[] | OrganizationUncheckedCreateWithoutOrg_adminsInput[]
    connectOrCreate?: OrganizationCreateOrConnectWithoutOrg_adminsInput | OrganizationCreateOrConnectWithoutOrg_adminsInput[]
    upsert?: OrganizationUpsertWithWhereUniqueWithoutOrg_adminsInput | OrganizationUpsertWithWhereUniqueWithoutOrg_adminsInput[]
    set?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    disconnect?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    delete?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    connect?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    update?: OrganizationUpdateWithWhereUniqueWithoutOrg_adminsInput | OrganizationUpdateWithWhereUniqueWithoutOrg_adminsInput[]
    updateMany?: OrganizationUpdateManyWithWhereWithoutOrg_adminsInput | OrganizationUpdateManyWithWhereWithoutOrg_adminsInput[]
    deleteMany?: OrganizationScalarWhereInput | OrganizationScalarWhereInput[]
  }

  export type OrganizationUpdateManyWithoutOrg_membersNestedInput = {
    create?: XOR<OrganizationCreateWithoutOrg_membersInput, OrganizationUncheckedCreateWithoutOrg_membersInput> | OrganizationCreateWithoutOrg_membersInput[] | OrganizationUncheckedCreateWithoutOrg_membersInput[]
    connectOrCreate?: OrganizationCreateOrConnectWithoutOrg_membersInput | OrganizationCreateOrConnectWithoutOrg_membersInput[]
    upsert?: OrganizationUpsertWithWhereUniqueWithoutOrg_membersInput | OrganizationUpsertWithWhereUniqueWithoutOrg_membersInput[]
    set?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    disconnect?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    delete?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    connect?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    update?: OrganizationUpdateWithWhereUniqueWithoutOrg_membersInput | OrganizationUpdateWithWhereUniqueWithoutOrg_membersInput[]
    updateMany?: OrganizationUpdateManyWithWhereWithoutOrg_membersInput | OrganizationUpdateManyWithWhereWithoutOrg_membersInput[]
    deleteMany?: OrganizationScalarWhereInput | OrganizationScalarWhereInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type HistoryCalculatorUncheckedUpdateManyWithoutCustomerNestedInput = {
    create?: XOR<HistoryCalculatorCreateWithoutCustomerInput, HistoryCalculatorUncheckedCreateWithoutCustomerInput> | HistoryCalculatorCreateWithoutCustomerInput[] | HistoryCalculatorUncheckedCreateWithoutCustomerInput[]
    connectOrCreate?: HistoryCalculatorCreateOrConnectWithoutCustomerInput | HistoryCalculatorCreateOrConnectWithoutCustomerInput[]
    upsert?: HistoryCalculatorUpsertWithWhereUniqueWithoutCustomerInput | HistoryCalculatorUpsertWithWhereUniqueWithoutCustomerInput[]
    createMany?: HistoryCalculatorCreateManyCustomerInputEnvelope
    set?: HistoryCalculatorWhereUniqueInput | HistoryCalculatorWhereUniqueInput[]
    disconnect?: HistoryCalculatorWhereUniqueInput | HistoryCalculatorWhereUniqueInput[]
    delete?: HistoryCalculatorWhereUniqueInput | HistoryCalculatorWhereUniqueInput[]
    connect?: HistoryCalculatorWhereUniqueInput | HistoryCalculatorWhereUniqueInput[]
    update?: HistoryCalculatorUpdateWithWhereUniqueWithoutCustomerInput | HistoryCalculatorUpdateWithWhereUniqueWithoutCustomerInput[]
    updateMany?: HistoryCalculatorUpdateManyWithWhereWithoutCustomerInput | HistoryCalculatorUpdateManyWithWhereWithoutCustomerInput[]
    deleteMany?: HistoryCalculatorScalarWhereInput | HistoryCalculatorScalarWhereInput[]
  }

  export type OrganizationUncheckedUpdateManyWithoutOrg_adminsNestedInput = {
    create?: XOR<OrganizationCreateWithoutOrg_adminsInput, OrganizationUncheckedCreateWithoutOrg_adminsInput> | OrganizationCreateWithoutOrg_adminsInput[] | OrganizationUncheckedCreateWithoutOrg_adminsInput[]
    connectOrCreate?: OrganizationCreateOrConnectWithoutOrg_adminsInput | OrganizationCreateOrConnectWithoutOrg_adminsInput[]
    upsert?: OrganizationUpsertWithWhereUniqueWithoutOrg_adminsInput | OrganizationUpsertWithWhereUniqueWithoutOrg_adminsInput[]
    set?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    disconnect?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    delete?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    connect?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    update?: OrganizationUpdateWithWhereUniqueWithoutOrg_adminsInput | OrganizationUpdateWithWhereUniqueWithoutOrg_adminsInput[]
    updateMany?: OrganizationUpdateManyWithWhereWithoutOrg_adminsInput | OrganizationUpdateManyWithWhereWithoutOrg_adminsInput[]
    deleteMany?: OrganizationScalarWhereInput | OrganizationScalarWhereInput[]
  }

  export type OrganizationUncheckedUpdateManyWithoutOrg_membersNestedInput = {
    create?: XOR<OrganizationCreateWithoutOrg_membersInput, OrganizationUncheckedCreateWithoutOrg_membersInput> | OrganizationCreateWithoutOrg_membersInput[] | OrganizationUncheckedCreateWithoutOrg_membersInput[]
    connectOrCreate?: OrganizationCreateOrConnectWithoutOrg_membersInput | OrganizationCreateOrConnectWithoutOrg_membersInput[]
    upsert?: OrganizationUpsertWithWhereUniqueWithoutOrg_membersInput | OrganizationUpsertWithWhereUniqueWithoutOrg_membersInput[]
    set?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    disconnect?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    delete?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    connect?: OrganizationWhereUniqueInput | OrganizationWhereUniqueInput[]
    update?: OrganizationUpdateWithWhereUniqueWithoutOrg_membersInput | OrganizationUpdateWithWhereUniqueWithoutOrg_membersInput[]
    updateMany?: OrganizationUpdateManyWithWhereWithoutOrg_membersInput | OrganizationUpdateManyWithWhereWithoutOrg_membersInput[]
    deleteMany?: OrganizationScalarWhereInput | OrganizationScalarWhereInput[]
  }

  export type CustomersCreateNestedOneWithoutHistoryCalculatorInput = {
    create?: XOR<CustomersCreateWithoutHistoryCalculatorInput, CustomersUncheckedCreateWithoutHistoryCalculatorInput>
    connectOrCreate?: CustomersCreateOrConnectWithoutHistoryCalculatorInput
    connect?: CustomersWhereUniqueInput
  }

  export type FloatFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type CustomersUpdateOneRequiredWithoutHistoryCalculatorNestedInput = {
    create?: XOR<CustomersCreateWithoutHistoryCalculatorInput, CustomersUncheckedCreateWithoutHistoryCalculatorInput>
    connectOrCreate?: CustomersCreateOrConnectWithoutHistoryCalculatorInput
    upsert?: CustomersUpsertWithoutHistoryCalculatorInput
    connect?: CustomersWhereUniqueInput
    update?: XOR<XOR<CustomersUpdateToOneWithWhereWithoutHistoryCalculatorInput, CustomersUpdateWithoutHistoryCalculatorInput>, CustomersUncheckedUpdateWithoutHistoryCalculatorInput>
  }

  export type CustomersCreateNestedManyWithoutOrg_adminOfInput = {
    create?: XOR<CustomersCreateWithoutOrg_adminOfInput, CustomersUncheckedCreateWithoutOrg_adminOfInput> | CustomersCreateWithoutOrg_adminOfInput[] | CustomersUncheckedCreateWithoutOrg_adminOfInput[]
    connectOrCreate?: CustomersCreateOrConnectWithoutOrg_adminOfInput | CustomersCreateOrConnectWithoutOrg_adminOfInput[]
    connect?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
  }

  export type CustomersCreateNestedManyWithoutOrg_memberOfInput = {
    create?: XOR<CustomersCreateWithoutOrg_memberOfInput, CustomersUncheckedCreateWithoutOrg_memberOfInput> | CustomersCreateWithoutOrg_memberOfInput[] | CustomersUncheckedCreateWithoutOrg_memberOfInput[]
    connectOrCreate?: CustomersCreateOrConnectWithoutOrg_memberOfInput | CustomersCreateOrConnectWithoutOrg_memberOfInput[]
    connect?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
  }

  export type CustomersUncheckedCreateNestedManyWithoutOrg_adminOfInput = {
    create?: XOR<CustomersCreateWithoutOrg_adminOfInput, CustomersUncheckedCreateWithoutOrg_adminOfInput> | CustomersCreateWithoutOrg_adminOfInput[] | CustomersUncheckedCreateWithoutOrg_adminOfInput[]
    connectOrCreate?: CustomersCreateOrConnectWithoutOrg_adminOfInput | CustomersCreateOrConnectWithoutOrg_adminOfInput[]
    connect?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
  }

  export type CustomersUncheckedCreateNestedManyWithoutOrg_memberOfInput = {
    create?: XOR<CustomersCreateWithoutOrg_memberOfInput, CustomersUncheckedCreateWithoutOrg_memberOfInput> | CustomersCreateWithoutOrg_memberOfInput[] | CustomersUncheckedCreateWithoutOrg_memberOfInput[]
    connectOrCreate?: CustomersCreateOrConnectWithoutOrg_memberOfInput | CustomersCreateOrConnectWithoutOrg_memberOfInput[]
    connect?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
  }

  export type CustomersUpdateManyWithoutOrg_adminOfNestedInput = {
    create?: XOR<CustomersCreateWithoutOrg_adminOfInput, CustomersUncheckedCreateWithoutOrg_adminOfInput> | CustomersCreateWithoutOrg_adminOfInput[] | CustomersUncheckedCreateWithoutOrg_adminOfInput[]
    connectOrCreate?: CustomersCreateOrConnectWithoutOrg_adminOfInput | CustomersCreateOrConnectWithoutOrg_adminOfInput[]
    upsert?: CustomersUpsertWithWhereUniqueWithoutOrg_adminOfInput | CustomersUpsertWithWhereUniqueWithoutOrg_adminOfInput[]
    set?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    disconnect?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    delete?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    connect?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    update?: CustomersUpdateWithWhereUniqueWithoutOrg_adminOfInput | CustomersUpdateWithWhereUniqueWithoutOrg_adminOfInput[]
    updateMany?: CustomersUpdateManyWithWhereWithoutOrg_adminOfInput | CustomersUpdateManyWithWhereWithoutOrg_adminOfInput[]
    deleteMany?: CustomersScalarWhereInput | CustomersScalarWhereInput[]
  }

  export type CustomersUpdateManyWithoutOrg_memberOfNestedInput = {
    create?: XOR<CustomersCreateWithoutOrg_memberOfInput, CustomersUncheckedCreateWithoutOrg_memberOfInput> | CustomersCreateWithoutOrg_memberOfInput[] | CustomersUncheckedCreateWithoutOrg_memberOfInput[]
    connectOrCreate?: CustomersCreateOrConnectWithoutOrg_memberOfInput | CustomersCreateOrConnectWithoutOrg_memberOfInput[]
    upsert?: CustomersUpsertWithWhereUniqueWithoutOrg_memberOfInput | CustomersUpsertWithWhereUniqueWithoutOrg_memberOfInput[]
    set?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    disconnect?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    delete?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    connect?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    update?: CustomersUpdateWithWhereUniqueWithoutOrg_memberOfInput | CustomersUpdateWithWhereUniqueWithoutOrg_memberOfInput[]
    updateMany?: CustomersUpdateManyWithWhereWithoutOrg_memberOfInput | CustomersUpdateManyWithWhereWithoutOrg_memberOfInput[]
    deleteMany?: CustomersScalarWhereInput | CustomersScalarWhereInput[]
  }

  export type CustomersUncheckedUpdateManyWithoutOrg_adminOfNestedInput = {
    create?: XOR<CustomersCreateWithoutOrg_adminOfInput, CustomersUncheckedCreateWithoutOrg_adminOfInput> | CustomersCreateWithoutOrg_adminOfInput[] | CustomersUncheckedCreateWithoutOrg_adminOfInput[]
    connectOrCreate?: CustomersCreateOrConnectWithoutOrg_adminOfInput | CustomersCreateOrConnectWithoutOrg_adminOfInput[]
    upsert?: CustomersUpsertWithWhereUniqueWithoutOrg_adminOfInput | CustomersUpsertWithWhereUniqueWithoutOrg_adminOfInput[]
    set?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    disconnect?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    delete?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    connect?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    update?: CustomersUpdateWithWhereUniqueWithoutOrg_adminOfInput | CustomersUpdateWithWhereUniqueWithoutOrg_adminOfInput[]
    updateMany?: CustomersUpdateManyWithWhereWithoutOrg_adminOfInput | CustomersUpdateManyWithWhereWithoutOrg_adminOfInput[]
    deleteMany?: CustomersScalarWhereInput | CustomersScalarWhereInput[]
  }

  export type CustomersUncheckedUpdateManyWithoutOrg_memberOfNestedInput = {
    create?: XOR<CustomersCreateWithoutOrg_memberOfInput, CustomersUncheckedCreateWithoutOrg_memberOfInput> | CustomersCreateWithoutOrg_memberOfInput[] | CustomersUncheckedCreateWithoutOrg_memberOfInput[]
    connectOrCreate?: CustomersCreateOrConnectWithoutOrg_memberOfInput | CustomersCreateOrConnectWithoutOrg_memberOfInput[]
    upsert?: CustomersUpsertWithWhereUniqueWithoutOrg_memberOfInput | CustomersUpsertWithWhereUniqueWithoutOrg_memberOfInput[]
    set?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    disconnect?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    delete?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    connect?: CustomersWhereUniqueInput | CustomersWhereUniqueInput[]
    update?: CustomersUpdateWithWhereUniqueWithoutOrg_memberOfInput | CustomersUpdateWithWhereUniqueWithoutOrg_memberOfInput[]
    updateMany?: CustomersUpdateManyWithWhereWithoutOrg_memberOfInput | CustomersUpdateManyWithWhereWithoutOrg_memberOfInput[]
    deleteMany?: CustomersScalarWhereInput | CustomersScalarWhereInput[]
  }

  export type CarModelsCreateNestedManyWithoutBrandInput = {
    create?: XOR<CarModelsCreateWithoutBrandInput, CarModelsUncheckedCreateWithoutBrandInput> | CarModelsCreateWithoutBrandInput[] | CarModelsUncheckedCreateWithoutBrandInput[]
    connectOrCreate?: CarModelsCreateOrConnectWithoutBrandInput | CarModelsCreateOrConnectWithoutBrandInput[]
    createMany?: CarModelsCreateManyBrandInputEnvelope
    connect?: CarModelsWhereUniqueInput | CarModelsWhereUniqueInput[]
  }

  export type CarModelsUncheckedCreateNestedManyWithoutBrandInput = {
    create?: XOR<CarModelsCreateWithoutBrandInput, CarModelsUncheckedCreateWithoutBrandInput> | CarModelsCreateWithoutBrandInput[] | CarModelsUncheckedCreateWithoutBrandInput[]
    connectOrCreate?: CarModelsCreateOrConnectWithoutBrandInput | CarModelsCreateOrConnectWithoutBrandInput[]
    createMany?: CarModelsCreateManyBrandInputEnvelope
    connect?: CarModelsWhereUniqueInput | CarModelsWhereUniqueInput[]
  }

  export type CarModelsUpdateManyWithoutBrandNestedInput = {
    create?: XOR<CarModelsCreateWithoutBrandInput, CarModelsUncheckedCreateWithoutBrandInput> | CarModelsCreateWithoutBrandInput[] | CarModelsUncheckedCreateWithoutBrandInput[]
    connectOrCreate?: CarModelsCreateOrConnectWithoutBrandInput | CarModelsCreateOrConnectWithoutBrandInput[]
    upsert?: CarModelsUpsertWithWhereUniqueWithoutBrandInput | CarModelsUpsertWithWhereUniqueWithoutBrandInput[]
    createMany?: CarModelsCreateManyBrandInputEnvelope
    set?: CarModelsWhereUniqueInput | CarModelsWhereUniqueInput[]
    disconnect?: CarModelsWhereUniqueInput | CarModelsWhereUniqueInput[]
    delete?: CarModelsWhereUniqueInput | CarModelsWhereUniqueInput[]
    connect?: CarModelsWhereUniqueInput | CarModelsWhereUniqueInput[]
    update?: CarModelsUpdateWithWhereUniqueWithoutBrandInput | CarModelsUpdateWithWhereUniqueWithoutBrandInput[]
    updateMany?: CarModelsUpdateManyWithWhereWithoutBrandInput | CarModelsUpdateManyWithWhereWithoutBrandInput[]
    deleteMany?: CarModelsScalarWhereInput | CarModelsScalarWhereInput[]
  }

  export type CarModelsUncheckedUpdateManyWithoutBrandNestedInput = {
    create?: XOR<CarModelsCreateWithoutBrandInput, CarModelsUncheckedCreateWithoutBrandInput> | CarModelsCreateWithoutBrandInput[] | CarModelsUncheckedCreateWithoutBrandInput[]
    connectOrCreate?: CarModelsCreateOrConnectWithoutBrandInput | CarModelsCreateOrConnectWithoutBrandInput[]
    upsert?: CarModelsUpsertWithWhereUniqueWithoutBrandInput | CarModelsUpsertWithWhereUniqueWithoutBrandInput[]
    createMany?: CarModelsCreateManyBrandInputEnvelope
    set?: CarModelsWhereUniqueInput | CarModelsWhereUniqueInput[]
    disconnect?: CarModelsWhereUniqueInput | CarModelsWhereUniqueInput[]
    delete?: CarModelsWhereUniqueInput | CarModelsWhereUniqueInput[]
    connect?: CarModelsWhereUniqueInput | CarModelsWhereUniqueInput[]
    update?: CarModelsUpdateWithWhereUniqueWithoutBrandInput | CarModelsUpdateWithWhereUniqueWithoutBrandInput[]
    updateMany?: CarModelsUpdateManyWithWhereWithoutBrandInput | CarModelsUpdateManyWithWhereWithoutBrandInput[]
    deleteMany?: CarModelsScalarWhereInput | CarModelsScalarWhereInput[]
  }

  export type CarModelsCreateoil_typeInput = {
    set: $Enums.CarOilTypes[]
  }

  export type CarBrandsCreateNestedOneWithoutCarModelsInput = {
    create?: XOR<CarBrandsCreateWithoutCarModelsInput, CarBrandsUncheckedCreateWithoutCarModelsInput>
    connectOrCreate?: CarBrandsCreateOrConnectWithoutCarModelsInput
    connect?: CarBrandsWhereUniqueInput
  }

  export type CarModelsUpdateoil_typeInput = {
    set?: $Enums.CarOilTypes[]
    push?: $Enums.CarOilTypes | $Enums.CarOilTypes[]
  }

  export type NullableFloatFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type CarBrandsUpdateOneRequiredWithoutCarModelsNestedInput = {
    create?: XOR<CarBrandsCreateWithoutCarModelsInput, CarBrandsUncheckedCreateWithoutCarModelsInput>
    connectOrCreate?: CarBrandsCreateOrConnectWithoutCarModelsInput
    upsert?: CarBrandsUpsertWithoutCarModelsInput
    connect?: CarBrandsWhereUniqueInput
    update?: XOR<XOR<CarBrandsUpdateToOneWithWhereWithoutCarModelsInput, CarBrandsUpdateWithoutCarModelsInput>, CarBrandsUncheckedUpdateWithoutCarModelsInput>
  }

  export type MotorcycleModelsCreateNestedManyWithoutBrandInput = {
    create?: XOR<MotorcycleModelsCreateWithoutBrandInput, MotorcycleModelsUncheckedCreateWithoutBrandInput> | MotorcycleModelsCreateWithoutBrandInput[] | MotorcycleModelsUncheckedCreateWithoutBrandInput[]
    connectOrCreate?: MotorcycleModelsCreateOrConnectWithoutBrandInput | MotorcycleModelsCreateOrConnectWithoutBrandInput[]
    createMany?: MotorcycleModelsCreateManyBrandInputEnvelope
    connect?: MotorcycleModelsWhereUniqueInput | MotorcycleModelsWhereUniqueInput[]
  }

  export type MotorcycleModelsUncheckedCreateNestedManyWithoutBrandInput = {
    create?: XOR<MotorcycleModelsCreateWithoutBrandInput, MotorcycleModelsUncheckedCreateWithoutBrandInput> | MotorcycleModelsCreateWithoutBrandInput[] | MotorcycleModelsUncheckedCreateWithoutBrandInput[]
    connectOrCreate?: MotorcycleModelsCreateOrConnectWithoutBrandInput | MotorcycleModelsCreateOrConnectWithoutBrandInput[]
    createMany?: MotorcycleModelsCreateManyBrandInputEnvelope
    connect?: MotorcycleModelsWhereUniqueInput | MotorcycleModelsWhereUniqueInput[]
  }

  export type MotorcycleModelsUpdateManyWithoutBrandNestedInput = {
    create?: XOR<MotorcycleModelsCreateWithoutBrandInput, MotorcycleModelsUncheckedCreateWithoutBrandInput> | MotorcycleModelsCreateWithoutBrandInput[] | MotorcycleModelsUncheckedCreateWithoutBrandInput[]
    connectOrCreate?: MotorcycleModelsCreateOrConnectWithoutBrandInput | MotorcycleModelsCreateOrConnectWithoutBrandInput[]
    upsert?: MotorcycleModelsUpsertWithWhereUniqueWithoutBrandInput | MotorcycleModelsUpsertWithWhereUniqueWithoutBrandInput[]
    createMany?: MotorcycleModelsCreateManyBrandInputEnvelope
    set?: MotorcycleModelsWhereUniqueInput | MotorcycleModelsWhereUniqueInput[]
    disconnect?: MotorcycleModelsWhereUniqueInput | MotorcycleModelsWhereUniqueInput[]
    delete?: MotorcycleModelsWhereUniqueInput | MotorcycleModelsWhereUniqueInput[]
    connect?: MotorcycleModelsWhereUniqueInput | MotorcycleModelsWhereUniqueInput[]
    update?: MotorcycleModelsUpdateWithWhereUniqueWithoutBrandInput | MotorcycleModelsUpdateWithWhereUniqueWithoutBrandInput[]
    updateMany?: MotorcycleModelsUpdateManyWithWhereWithoutBrandInput | MotorcycleModelsUpdateManyWithWhereWithoutBrandInput[]
    deleteMany?: MotorcycleModelsScalarWhereInput | MotorcycleModelsScalarWhereInput[]
  }

  export type MotorcycleModelsUncheckedUpdateManyWithoutBrandNestedInput = {
    create?: XOR<MotorcycleModelsCreateWithoutBrandInput, MotorcycleModelsUncheckedCreateWithoutBrandInput> | MotorcycleModelsCreateWithoutBrandInput[] | MotorcycleModelsUncheckedCreateWithoutBrandInput[]
    connectOrCreate?: MotorcycleModelsCreateOrConnectWithoutBrandInput | MotorcycleModelsCreateOrConnectWithoutBrandInput[]
    upsert?: MotorcycleModelsUpsertWithWhereUniqueWithoutBrandInput | MotorcycleModelsUpsertWithWhereUniqueWithoutBrandInput[]
    createMany?: MotorcycleModelsCreateManyBrandInputEnvelope
    set?: MotorcycleModelsWhereUniqueInput | MotorcycleModelsWhereUniqueInput[]
    disconnect?: MotorcycleModelsWhereUniqueInput | MotorcycleModelsWhereUniqueInput[]
    delete?: MotorcycleModelsWhereUniqueInput | MotorcycleModelsWhereUniqueInput[]
    connect?: MotorcycleModelsWhereUniqueInput | MotorcycleModelsWhereUniqueInput[]
    update?: MotorcycleModelsUpdateWithWhereUniqueWithoutBrandInput | MotorcycleModelsUpdateWithWhereUniqueWithoutBrandInput[]
    updateMany?: MotorcycleModelsUpdateManyWithWhereWithoutBrandInput | MotorcycleModelsUpdateManyWithWhereWithoutBrandInput[]
    deleteMany?: MotorcycleModelsScalarWhereInput | MotorcycleModelsScalarWhereInput[]
  }

  export type MotorcycleModelsCreateoil_typeInput = {
    set: $Enums.MotorBikeOilTypes[]
  }

  export type MotorcycleBrandsCreateNestedOneWithoutMotorcycleModelsInput = {
    create?: XOR<MotorcycleBrandsCreateWithoutMotorcycleModelsInput, MotorcycleBrandsUncheckedCreateWithoutMotorcycleModelsInput>
    connectOrCreate?: MotorcycleBrandsCreateOrConnectWithoutMotorcycleModelsInput
    connect?: MotorcycleBrandsWhereUniqueInput
  }

  export type MotorcycleModelsUpdateoil_typeInput = {
    set?: $Enums.MotorBikeOilTypes[]
    push?: $Enums.MotorBikeOilTypes | $Enums.MotorBikeOilTypes[]
  }

  export type MotorcycleBrandsUpdateOneRequiredWithoutMotorcycleModelsNestedInput = {
    create?: XOR<MotorcycleBrandsCreateWithoutMotorcycleModelsInput, MotorcycleBrandsUncheckedCreateWithoutMotorcycleModelsInput>
    connectOrCreate?: MotorcycleBrandsCreateOrConnectWithoutMotorcycleModelsInput
    upsert?: MotorcycleBrandsUpsertWithoutMotorcycleModelsInput
    connect?: MotorcycleBrandsWhereUniqueInput
    update?: XOR<XOR<MotorcycleBrandsUpdateToOneWithWhereWithoutMotorcycleModelsInput, MotorcycleBrandsUpdateWithoutMotorcycleModelsInput>, MotorcycleBrandsUncheckedUpdateWithoutMotorcycleModelsInput>
  }

  export type PublicTransportTypesCreateoil_typeInput = {
    set: $Enums.CarOilTypes[]
  }

  export type PublicTransportTypesUpdateoil_typeInput = {
    set?: $Enums.CarOilTypes[]
    push?: $Enums.CarOilTypes | $Enums.CarOilTypes[]
  }

  export type AirModelsCreateNestedManyWithoutBrandInput = {
    create?: XOR<AirModelsCreateWithoutBrandInput, AirModelsUncheckedCreateWithoutBrandInput> | AirModelsCreateWithoutBrandInput[] | AirModelsUncheckedCreateWithoutBrandInput[]
    connectOrCreate?: AirModelsCreateOrConnectWithoutBrandInput | AirModelsCreateOrConnectWithoutBrandInput[]
    createMany?: AirModelsCreateManyBrandInputEnvelope
    connect?: AirModelsWhereUniqueInput | AirModelsWhereUniqueInput[]
  }

  export type AirModelsUncheckedCreateNestedManyWithoutBrandInput = {
    create?: XOR<AirModelsCreateWithoutBrandInput, AirModelsUncheckedCreateWithoutBrandInput> | AirModelsCreateWithoutBrandInput[] | AirModelsUncheckedCreateWithoutBrandInput[]
    connectOrCreate?: AirModelsCreateOrConnectWithoutBrandInput | AirModelsCreateOrConnectWithoutBrandInput[]
    createMany?: AirModelsCreateManyBrandInputEnvelope
    connect?: AirModelsWhereUniqueInput | AirModelsWhereUniqueInput[]
  }

  export type AirModelsUpdateManyWithoutBrandNestedInput = {
    create?: XOR<AirModelsCreateWithoutBrandInput, AirModelsUncheckedCreateWithoutBrandInput> | AirModelsCreateWithoutBrandInput[] | AirModelsUncheckedCreateWithoutBrandInput[]
    connectOrCreate?: AirModelsCreateOrConnectWithoutBrandInput | AirModelsCreateOrConnectWithoutBrandInput[]
    upsert?: AirModelsUpsertWithWhereUniqueWithoutBrandInput | AirModelsUpsertWithWhereUniqueWithoutBrandInput[]
    createMany?: AirModelsCreateManyBrandInputEnvelope
    set?: AirModelsWhereUniqueInput | AirModelsWhereUniqueInput[]
    disconnect?: AirModelsWhereUniqueInput | AirModelsWhereUniqueInput[]
    delete?: AirModelsWhereUniqueInput | AirModelsWhereUniqueInput[]
    connect?: AirModelsWhereUniqueInput | AirModelsWhereUniqueInput[]
    update?: AirModelsUpdateWithWhereUniqueWithoutBrandInput | AirModelsUpdateWithWhereUniqueWithoutBrandInput[]
    updateMany?: AirModelsUpdateManyWithWhereWithoutBrandInput | AirModelsUpdateManyWithWhereWithoutBrandInput[]
    deleteMany?: AirModelsScalarWhereInput | AirModelsScalarWhereInput[]
  }

  export type AirModelsUncheckedUpdateManyWithoutBrandNestedInput = {
    create?: XOR<AirModelsCreateWithoutBrandInput, AirModelsUncheckedCreateWithoutBrandInput> | AirModelsCreateWithoutBrandInput[] | AirModelsUncheckedCreateWithoutBrandInput[]
    connectOrCreate?: AirModelsCreateOrConnectWithoutBrandInput | AirModelsCreateOrConnectWithoutBrandInput[]
    upsert?: AirModelsUpsertWithWhereUniqueWithoutBrandInput | AirModelsUpsertWithWhereUniqueWithoutBrandInput[]
    createMany?: AirModelsCreateManyBrandInputEnvelope
    set?: AirModelsWhereUniqueInput | AirModelsWhereUniqueInput[]
    disconnect?: AirModelsWhereUniqueInput | AirModelsWhereUniqueInput[]
    delete?: AirModelsWhereUniqueInput | AirModelsWhereUniqueInput[]
    connect?: AirModelsWhereUniqueInput | AirModelsWhereUniqueInput[]
    update?: AirModelsUpdateWithWhereUniqueWithoutBrandInput | AirModelsUpdateWithWhereUniqueWithoutBrandInput[]
    updateMany?: AirModelsUpdateManyWithWhereWithoutBrandInput | AirModelsUpdateManyWithWhereWithoutBrandInput[]
    deleteMany?: AirModelsScalarWhereInput | AirModelsScalarWhereInput[]
  }

  export type AirBrandsCreateNestedOneWithoutAirModelsInput = {
    create?: XOR<AirBrandsCreateWithoutAirModelsInput, AirBrandsUncheckedCreateWithoutAirModelsInput>
    connectOrCreate?: AirBrandsCreateOrConnectWithoutAirModelsInput
    connect?: AirBrandsWhereUniqueInput
  }

  export type NullableEnumAirOilTypesFieldUpdateOperationsInput = {
    set?: $Enums.AirOilTypes | null
  }

  export type AirBrandsUpdateOneRequiredWithoutAirModelsNestedInput = {
    create?: XOR<AirBrandsCreateWithoutAirModelsInput, AirBrandsUncheckedCreateWithoutAirModelsInput>
    connectOrCreate?: AirBrandsCreateOrConnectWithoutAirModelsInput
    upsert?: AirBrandsUpsertWithoutAirModelsInput
    connect?: AirBrandsWhereUniqueInput
    update?: XOR<XOR<AirBrandsUpdateToOneWithWhereWithoutAirModelsInput, AirBrandsUpdateWithoutAirModelsInput>, AirBrandsUncheckedUpdateWithoutAirModelsInput>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedFloatWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedFloatFilter<$PrismaModel>
    _min?: NestedFloatFilter<$PrismaModel>
    _max?: NestedFloatFilter<$PrismaModel>
  }

  export type NestedFloatNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedFloatNullableFilter<$PrismaModel>
    _min?: NestedFloatNullableFilter<$PrismaModel>
    _max?: NestedFloatNullableFilter<$PrismaModel>
  }

  export type NestedEnumAirOilTypesNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.AirOilTypes | EnumAirOilTypesFieldRefInput<$PrismaModel> | null
    in?: $Enums.AirOilTypes[] | ListEnumAirOilTypesFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.AirOilTypes[] | ListEnumAirOilTypesFieldRefInput<$PrismaModel> | null
    not?: NestedEnumAirOilTypesNullableFilter<$PrismaModel> | $Enums.AirOilTypes | null
  }

  export type NestedEnumAirOilTypesNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.AirOilTypes | EnumAirOilTypesFieldRefInput<$PrismaModel> | null
    in?: $Enums.AirOilTypes[] | ListEnumAirOilTypesFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.AirOilTypes[] | ListEnumAirOilTypesFieldRefInput<$PrismaModel> | null
    not?: NestedEnumAirOilTypesNullableWithAggregatesFilter<$PrismaModel> | $Enums.AirOilTypes | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumAirOilTypesNullableFilter<$PrismaModel>
    _max?: NestedEnumAirOilTypesNullableFilter<$PrismaModel>
  }

  export type HistoryCalculatorCreateWithoutCustomerInput = {
    calculation: string
    result: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type HistoryCalculatorUncheckedCreateWithoutCustomerInput = {
    id?: number
    calculation: string
    result: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type HistoryCalculatorCreateOrConnectWithoutCustomerInput = {
    where: HistoryCalculatorWhereUniqueInput
    create: XOR<HistoryCalculatorCreateWithoutCustomerInput, HistoryCalculatorUncheckedCreateWithoutCustomerInput>
  }

  export type HistoryCalculatorCreateManyCustomerInputEnvelope = {
    data: HistoryCalculatorCreateManyCustomerInput | HistoryCalculatorCreateManyCustomerInput[]
    skipDuplicates?: boolean
  }

  export type OrganizationCreateWithoutOrg_adminsInput = {
    org_name: string
    org_email: string
    org_phone?: string | null
    org_address?: string | null
    org_city?: string | null
    org_state?: string | null
    org_zipCode?: string | null
    org_province?: string | null
    org_logo?: string | null
    org_password?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    org_members?: CustomersCreateNestedManyWithoutOrg_memberOfInput
  }

  export type OrganizationUncheckedCreateWithoutOrg_adminsInput = {
    id?: number
    org_name: string
    org_email: string
    org_phone?: string | null
    org_address?: string | null
    org_city?: string | null
    org_state?: string | null
    org_zipCode?: string | null
    org_province?: string | null
    org_logo?: string | null
    org_password?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    org_members?: CustomersUncheckedCreateNestedManyWithoutOrg_memberOfInput
  }

  export type OrganizationCreateOrConnectWithoutOrg_adminsInput = {
    where: OrganizationWhereUniqueInput
    create: XOR<OrganizationCreateWithoutOrg_adminsInput, OrganizationUncheckedCreateWithoutOrg_adminsInput>
  }

  export type OrganizationCreateWithoutOrg_membersInput = {
    org_name: string
    org_email: string
    org_phone?: string | null
    org_address?: string | null
    org_city?: string | null
    org_state?: string | null
    org_zipCode?: string | null
    org_province?: string | null
    org_logo?: string | null
    org_password?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    org_admins?: CustomersCreateNestedManyWithoutOrg_adminOfInput
  }

  export type OrganizationUncheckedCreateWithoutOrg_membersInput = {
    id?: number
    org_name: string
    org_email: string
    org_phone?: string | null
    org_address?: string | null
    org_city?: string | null
    org_state?: string | null
    org_zipCode?: string | null
    org_province?: string | null
    org_logo?: string | null
    org_password?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    org_admins?: CustomersUncheckedCreateNestedManyWithoutOrg_adminOfInput
  }

  export type OrganizationCreateOrConnectWithoutOrg_membersInput = {
    where: OrganizationWhereUniqueInput
    create: XOR<OrganizationCreateWithoutOrg_membersInput, OrganizationUncheckedCreateWithoutOrg_membersInput>
  }

  export type HistoryCalculatorUpsertWithWhereUniqueWithoutCustomerInput = {
    where: HistoryCalculatorWhereUniqueInput
    update: XOR<HistoryCalculatorUpdateWithoutCustomerInput, HistoryCalculatorUncheckedUpdateWithoutCustomerInput>
    create: XOR<HistoryCalculatorCreateWithoutCustomerInput, HistoryCalculatorUncheckedCreateWithoutCustomerInput>
  }

  export type HistoryCalculatorUpdateWithWhereUniqueWithoutCustomerInput = {
    where: HistoryCalculatorWhereUniqueInput
    data: XOR<HistoryCalculatorUpdateWithoutCustomerInput, HistoryCalculatorUncheckedUpdateWithoutCustomerInput>
  }

  export type HistoryCalculatorUpdateManyWithWhereWithoutCustomerInput = {
    where: HistoryCalculatorScalarWhereInput
    data: XOR<HistoryCalculatorUpdateManyMutationInput, HistoryCalculatorUncheckedUpdateManyWithoutCustomerInput>
  }

  export type HistoryCalculatorScalarWhereInput = {
    AND?: HistoryCalculatorScalarWhereInput | HistoryCalculatorScalarWhereInput[]
    OR?: HistoryCalculatorScalarWhereInput[]
    NOT?: HistoryCalculatorScalarWhereInput | HistoryCalculatorScalarWhereInput[]
    id?: IntFilter<"HistoryCalculator"> | number
    customerId?: IntFilter<"HistoryCalculator"> | number
    calculation?: StringFilter<"HistoryCalculator"> | string
    result?: FloatFilter<"HistoryCalculator"> | number
    createdAt?: DateTimeFilter<"HistoryCalculator"> | Date | string
    updatedAt?: DateTimeFilter<"HistoryCalculator"> | Date | string
  }

  export type OrganizationUpsertWithWhereUniqueWithoutOrg_adminsInput = {
    where: OrganizationWhereUniqueInput
    update: XOR<OrganizationUpdateWithoutOrg_adminsInput, OrganizationUncheckedUpdateWithoutOrg_adminsInput>
    create: XOR<OrganizationCreateWithoutOrg_adminsInput, OrganizationUncheckedCreateWithoutOrg_adminsInput>
  }

  export type OrganizationUpdateWithWhereUniqueWithoutOrg_adminsInput = {
    where: OrganizationWhereUniqueInput
    data: XOR<OrganizationUpdateWithoutOrg_adminsInput, OrganizationUncheckedUpdateWithoutOrg_adminsInput>
  }

  export type OrganizationUpdateManyWithWhereWithoutOrg_adminsInput = {
    where: OrganizationScalarWhereInput
    data: XOR<OrganizationUpdateManyMutationInput, OrganizationUncheckedUpdateManyWithoutOrg_adminsInput>
  }

  export type OrganizationScalarWhereInput = {
    AND?: OrganizationScalarWhereInput | OrganizationScalarWhereInput[]
    OR?: OrganizationScalarWhereInput[]
    NOT?: OrganizationScalarWhereInput | OrganizationScalarWhereInput[]
    id?: IntFilter<"Organization"> | number
    org_name?: StringFilter<"Organization"> | string
    org_email?: StringFilter<"Organization"> | string
    org_phone?: StringNullableFilter<"Organization"> | string | null
    org_address?: StringNullableFilter<"Organization"> | string | null
    org_city?: StringNullableFilter<"Organization"> | string | null
    org_state?: StringNullableFilter<"Organization"> | string | null
    org_zipCode?: StringNullableFilter<"Organization"> | string | null
    org_province?: StringNullableFilter<"Organization"> | string | null
    org_logo?: StringNullableFilter<"Organization"> | string | null
    org_password?: StringNullableFilter<"Organization"> | string | null
    createdAt?: DateTimeFilter<"Organization"> | Date | string
    updatedAt?: DateTimeFilter<"Organization"> | Date | string
  }

  export type OrganizationUpsertWithWhereUniqueWithoutOrg_membersInput = {
    where: OrganizationWhereUniqueInput
    update: XOR<OrganizationUpdateWithoutOrg_membersInput, OrganizationUncheckedUpdateWithoutOrg_membersInput>
    create: XOR<OrganizationCreateWithoutOrg_membersInput, OrganizationUncheckedCreateWithoutOrg_membersInput>
  }

  export type OrganizationUpdateWithWhereUniqueWithoutOrg_membersInput = {
    where: OrganizationWhereUniqueInput
    data: XOR<OrganizationUpdateWithoutOrg_membersInput, OrganizationUncheckedUpdateWithoutOrg_membersInput>
  }

  export type OrganizationUpdateManyWithWhereWithoutOrg_membersInput = {
    where: OrganizationScalarWhereInput
    data: XOR<OrganizationUpdateManyMutationInput, OrganizationUncheckedUpdateManyWithoutOrg_membersInput>
  }

  export type CustomersCreateWithoutHistoryCalculatorInput = {
    username: string
    email: string
    password?: string | null
    phone?: string | null
    address?: string | null
    city?: string | null
    state?: string | null
    zipCode?: string | null
    province?: string | null
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: Date | string | null
    profilePicture?: string | null
    organizationId?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
    org_adminOf?: OrganizationCreateNestedManyWithoutOrg_adminsInput
    org_memberOf?: OrganizationCreateNestedManyWithoutOrg_membersInput
  }

  export type CustomersUncheckedCreateWithoutHistoryCalculatorInput = {
    id?: number
    username: string
    email: string
    password?: string | null
    phone?: string | null
    address?: string | null
    city?: string | null
    state?: string | null
    zipCode?: string | null
    province?: string | null
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: Date | string | null
    profilePicture?: string | null
    organizationId?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
    org_adminOf?: OrganizationUncheckedCreateNestedManyWithoutOrg_adminsInput
    org_memberOf?: OrganizationUncheckedCreateNestedManyWithoutOrg_membersInput
  }

  export type CustomersCreateOrConnectWithoutHistoryCalculatorInput = {
    where: CustomersWhereUniqueInput
    create: XOR<CustomersCreateWithoutHistoryCalculatorInput, CustomersUncheckedCreateWithoutHistoryCalculatorInput>
  }

  export type CustomersUpsertWithoutHistoryCalculatorInput = {
    update: XOR<CustomersUpdateWithoutHistoryCalculatorInput, CustomersUncheckedUpdateWithoutHistoryCalculatorInput>
    create: XOR<CustomersCreateWithoutHistoryCalculatorInput, CustomersUncheckedCreateWithoutHistoryCalculatorInput>
    where?: CustomersWhereInput
  }

  export type CustomersUpdateToOneWithWhereWithoutHistoryCalculatorInput = {
    where?: CustomersWhereInput
    data: XOR<CustomersUpdateWithoutHistoryCalculatorInput, CustomersUncheckedUpdateWithoutHistoryCalculatorInput>
  }

  export type CustomersUpdateWithoutHistoryCalculatorInput = {
    username?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    province?: NullableStringFieldUpdateOperationsInput | string | null
    isActive?: BoolFieldUpdateOperationsInput | boolean
    isVerified?: BoolFieldUpdateOperationsInput | boolean
    lastLogin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    profilePicture?: NullableStringFieldUpdateOperationsInput | string | null
    organizationId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    org_adminOf?: OrganizationUpdateManyWithoutOrg_adminsNestedInput
    org_memberOf?: OrganizationUpdateManyWithoutOrg_membersNestedInput
  }

  export type CustomersUncheckedUpdateWithoutHistoryCalculatorInput = {
    id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    province?: NullableStringFieldUpdateOperationsInput | string | null
    isActive?: BoolFieldUpdateOperationsInput | boolean
    isVerified?: BoolFieldUpdateOperationsInput | boolean
    lastLogin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    profilePicture?: NullableStringFieldUpdateOperationsInput | string | null
    organizationId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    org_adminOf?: OrganizationUncheckedUpdateManyWithoutOrg_adminsNestedInput
    org_memberOf?: OrganizationUncheckedUpdateManyWithoutOrg_membersNestedInput
  }

  export type CustomersCreateWithoutOrg_adminOfInput = {
    username: string
    email: string
    password?: string | null
    phone?: string | null
    address?: string | null
    city?: string | null
    state?: string | null
    zipCode?: string | null
    province?: string | null
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: Date | string | null
    profilePicture?: string | null
    organizationId?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
    HistoryCalculator?: HistoryCalculatorCreateNestedManyWithoutCustomerInput
    org_memberOf?: OrganizationCreateNestedManyWithoutOrg_membersInput
  }

  export type CustomersUncheckedCreateWithoutOrg_adminOfInput = {
    id?: number
    username: string
    email: string
    password?: string | null
    phone?: string | null
    address?: string | null
    city?: string | null
    state?: string | null
    zipCode?: string | null
    province?: string | null
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: Date | string | null
    profilePicture?: string | null
    organizationId?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
    HistoryCalculator?: HistoryCalculatorUncheckedCreateNestedManyWithoutCustomerInput
    org_memberOf?: OrganizationUncheckedCreateNestedManyWithoutOrg_membersInput
  }

  export type CustomersCreateOrConnectWithoutOrg_adminOfInput = {
    where: CustomersWhereUniqueInput
    create: XOR<CustomersCreateWithoutOrg_adminOfInput, CustomersUncheckedCreateWithoutOrg_adminOfInput>
  }

  export type CustomersCreateWithoutOrg_memberOfInput = {
    username: string
    email: string
    password?: string | null
    phone?: string | null
    address?: string | null
    city?: string | null
    state?: string | null
    zipCode?: string | null
    province?: string | null
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: Date | string | null
    profilePicture?: string | null
    organizationId?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
    HistoryCalculator?: HistoryCalculatorCreateNestedManyWithoutCustomerInput
    org_adminOf?: OrganizationCreateNestedManyWithoutOrg_adminsInput
  }

  export type CustomersUncheckedCreateWithoutOrg_memberOfInput = {
    id?: number
    username: string
    email: string
    password?: string | null
    phone?: string | null
    address?: string | null
    city?: string | null
    state?: string | null
    zipCode?: string | null
    province?: string | null
    isActive?: boolean
    isVerified?: boolean
    lastLogin?: Date | string | null
    profilePicture?: string | null
    organizationId?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
    HistoryCalculator?: HistoryCalculatorUncheckedCreateNestedManyWithoutCustomerInput
    org_adminOf?: OrganizationUncheckedCreateNestedManyWithoutOrg_adminsInput
  }

  export type CustomersCreateOrConnectWithoutOrg_memberOfInput = {
    where: CustomersWhereUniqueInput
    create: XOR<CustomersCreateWithoutOrg_memberOfInput, CustomersUncheckedCreateWithoutOrg_memberOfInput>
  }

  export type CustomersUpsertWithWhereUniqueWithoutOrg_adminOfInput = {
    where: CustomersWhereUniqueInput
    update: XOR<CustomersUpdateWithoutOrg_adminOfInput, CustomersUncheckedUpdateWithoutOrg_adminOfInput>
    create: XOR<CustomersCreateWithoutOrg_adminOfInput, CustomersUncheckedCreateWithoutOrg_adminOfInput>
  }

  export type CustomersUpdateWithWhereUniqueWithoutOrg_adminOfInput = {
    where: CustomersWhereUniqueInput
    data: XOR<CustomersUpdateWithoutOrg_adminOfInput, CustomersUncheckedUpdateWithoutOrg_adminOfInput>
  }

  export type CustomersUpdateManyWithWhereWithoutOrg_adminOfInput = {
    where: CustomersScalarWhereInput
    data: XOR<CustomersUpdateManyMutationInput, CustomersUncheckedUpdateManyWithoutOrg_adminOfInput>
  }

  export type CustomersScalarWhereInput = {
    AND?: CustomersScalarWhereInput | CustomersScalarWhereInput[]
    OR?: CustomersScalarWhereInput[]
    NOT?: CustomersScalarWhereInput | CustomersScalarWhereInput[]
    id?: IntFilter<"Customers"> | number
    username?: StringFilter<"Customers"> | string
    email?: StringFilter<"Customers"> | string
    password?: StringNullableFilter<"Customers"> | string | null
    phone?: StringNullableFilter<"Customers"> | string | null
    address?: StringNullableFilter<"Customers"> | string | null
    city?: StringNullableFilter<"Customers"> | string | null
    state?: StringNullableFilter<"Customers"> | string | null
    zipCode?: StringNullableFilter<"Customers"> | string | null
    province?: StringNullableFilter<"Customers"> | string | null
    isActive?: BoolFilter<"Customers"> | boolean
    isVerified?: BoolFilter<"Customers"> | boolean
    lastLogin?: DateTimeNullableFilter<"Customers"> | Date | string | null
    profilePicture?: StringNullableFilter<"Customers"> | string | null
    organizationId?: IntNullableFilter<"Customers"> | number | null
    createdAt?: DateTimeFilter<"Customers"> | Date | string
    updatedAt?: DateTimeFilter<"Customers"> | Date | string
  }

  export type CustomersUpsertWithWhereUniqueWithoutOrg_memberOfInput = {
    where: CustomersWhereUniqueInput
    update: XOR<CustomersUpdateWithoutOrg_memberOfInput, CustomersUncheckedUpdateWithoutOrg_memberOfInput>
    create: XOR<CustomersCreateWithoutOrg_memberOfInput, CustomersUncheckedCreateWithoutOrg_memberOfInput>
  }

  export type CustomersUpdateWithWhereUniqueWithoutOrg_memberOfInput = {
    where: CustomersWhereUniqueInput
    data: XOR<CustomersUpdateWithoutOrg_memberOfInput, CustomersUncheckedUpdateWithoutOrg_memberOfInput>
  }

  export type CustomersUpdateManyWithWhereWithoutOrg_memberOfInput = {
    where: CustomersScalarWhereInput
    data: XOR<CustomersUpdateManyMutationInput, CustomersUncheckedUpdateManyWithoutOrg_memberOfInput>
  }

  export type CarModelsCreateWithoutBrandInput = {
    name: string
    description?: string | null
    power_type?: string | null
    oil_type?: CarModelsCreateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: number | null
    electric_carbon_per_unit?: number | null
    cubic_centimeter?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CarModelsUncheckedCreateWithoutBrandInput = {
    id?: number
    name: string
    description?: string | null
    power_type?: string | null
    oil_type?: CarModelsCreateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: number | null
    electric_carbon_per_unit?: number | null
    cubic_centimeter?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CarModelsCreateOrConnectWithoutBrandInput = {
    where: CarModelsWhereUniqueInput
    create: XOR<CarModelsCreateWithoutBrandInput, CarModelsUncheckedCreateWithoutBrandInput>
  }

  export type CarModelsCreateManyBrandInputEnvelope = {
    data: CarModelsCreateManyBrandInput | CarModelsCreateManyBrandInput[]
    skipDuplicates?: boolean
  }

  export type CarModelsUpsertWithWhereUniqueWithoutBrandInput = {
    where: CarModelsWhereUniqueInput
    update: XOR<CarModelsUpdateWithoutBrandInput, CarModelsUncheckedUpdateWithoutBrandInput>
    create: XOR<CarModelsCreateWithoutBrandInput, CarModelsUncheckedCreateWithoutBrandInput>
  }

  export type CarModelsUpdateWithWhereUniqueWithoutBrandInput = {
    where: CarModelsWhereUniqueInput
    data: XOR<CarModelsUpdateWithoutBrandInput, CarModelsUncheckedUpdateWithoutBrandInput>
  }

  export type CarModelsUpdateManyWithWhereWithoutBrandInput = {
    where: CarModelsScalarWhereInput
    data: XOR<CarModelsUpdateManyMutationInput, CarModelsUncheckedUpdateManyWithoutBrandInput>
  }

  export type CarModelsScalarWhereInput = {
    AND?: CarModelsScalarWhereInput | CarModelsScalarWhereInput[]
    OR?: CarModelsScalarWhereInput[]
    NOT?: CarModelsScalarWhereInput | CarModelsScalarWhereInput[]
    id?: IntFilter<"CarModels"> | number
    brandId?: IntFilter<"CarModels"> | number
    name?: StringFilter<"CarModels"> | string
    description?: StringNullableFilter<"CarModels"> | string | null
    power_type?: StringNullableFilter<"CarModels"> | string | null
    oil_type?: EnumCarOilTypesNullableListFilter<"CarModels">
    oil_carbon_per_unit?: FloatNullableFilter<"CarModels"> | number | null
    electric_carbon_per_unit?: FloatNullableFilter<"CarModels"> | number | null
    cubic_centimeter?: IntNullableFilter<"CarModels"> | number | null
    createdAt?: DateTimeFilter<"CarModels"> | Date | string
    updatedAt?: DateTimeFilter<"CarModels"> | Date | string
  }

  export type CarBrandsCreateWithoutCarModelsInput = {
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CarBrandsUncheckedCreateWithoutCarModelsInput = {
    id?: number
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CarBrandsCreateOrConnectWithoutCarModelsInput = {
    where: CarBrandsWhereUniqueInput
    create: XOR<CarBrandsCreateWithoutCarModelsInput, CarBrandsUncheckedCreateWithoutCarModelsInput>
  }

  export type CarBrandsUpsertWithoutCarModelsInput = {
    update: XOR<CarBrandsUpdateWithoutCarModelsInput, CarBrandsUncheckedUpdateWithoutCarModelsInput>
    create: XOR<CarBrandsCreateWithoutCarModelsInput, CarBrandsUncheckedCreateWithoutCarModelsInput>
    where?: CarBrandsWhereInput
  }

  export type CarBrandsUpdateToOneWithWhereWithoutCarModelsInput = {
    where?: CarBrandsWhereInput
    data: XOR<CarBrandsUpdateWithoutCarModelsInput, CarBrandsUncheckedUpdateWithoutCarModelsInput>
  }

  export type CarBrandsUpdateWithoutCarModelsInput = {
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CarBrandsUncheckedUpdateWithoutCarModelsInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MotorcycleModelsCreateWithoutBrandInput = {
    name: string
    description?: string | null
    cubic_centimeter?: number | null
    power_type?: string | null
    electric_carbon_per_unit?: number | null
    oil_carbon_per_unit?: number | null
    oil_type?: MotorcycleModelsCreateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MotorcycleModelsUncheckedCreateWithoutBrandInput = {
    id?: number
    name: string
    description?: string | null
    cubic_centimeter?: number | null
    power_type?: string | null
    electric_carbon_per_unit?: number | null
    oil_carbon_per_unit?: number | null
    oil_type?: MotorcycleModelsCreateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MotorcycleModelsCreateOrConnectWithoutBrandInput = {
    where: MotorcycleModelsWhereUniqueInput
    create: XOR<MotorcycleModelsCreateWithoutBrandInput, MotorcycleModelsUncheckedCreateWithoutBrandInput>
  }

  export type MotorcycleModelsCreateManyBrandInputEnvelope = {
    data: MotorcycleModelsCreateManyBrandInput | MotorcycleModelsCreateManyBrandInput[]
    skipDuplicates?: boolean
  }

  export type MotorcycleModelsUpsertWithWhereUniqueWithoutBrandInput = {
    where: MotorcycleModelsWhereUniqueInput
    update: XOR<MotorcycleModelsUpdateWithoutBrandInput, MotorcycleModelsUncheckedUpdateWithoutBrandInput>
    create: XOR<MotorcycleModelsCreateWithoutBrandInput, MotorcycleModelsUncheckedCreateWithoutBrandInput>
  }

  export type MotorcycleModelsUpdateWithWhereUniqueWithoutBrandInput = {
    where: MotorcycleModelsWhereUniqueInput
    data: XOR<MotorcycleModelsUpdateWithoutBrandInput, MotorcycleModelsUncheckedUpdateWithoutBrandInput>
  }

  export type MotorcycleModelsUpdateManyWithWhereWithoutBrandInput = {
    where: MotorcycleModelsScalarWhereInput
    data: XOR<MotorcycleModelsUpdateManyMutationInput, MotorcycleModelsUncheckedUpdateManyWithoutBrandInput>
  }

  export type MotorcycleModelsScalarWhereInput = {
    AND?: MotorcycleModelsScalarWhereInput | MotorcycleModelsScalarWhereInput[]
    OR?: MotorcycleModelsScalarWhereInput[]
    NOT?: MotorcycleModelsScalarWhereInput | MotorcycleModelsScalarWhereInput[]
    id?: IntFilter<"MotorcycleModels"> | number
    brandId?: IntFilter<"MotorcycleModels"> | number
    name?: StringFilter<"MotorcycleModels"> | string
    description?: StringNullableFilter<"MotorcycleModels"> | string | null
    cubic_centimeter?: IntNullableFilter<"MotorcycleModels"> | number | null
    power_type?: StringNullableFilter<"MotorcycleModels"> | string | null
    electric_carbon_per_unit?: FloatNullableFilter<"MotorcycleModels"> | number | null
    oil_carbon_per_unit?: FloatNullableFilter<"MotorcycleModels"> | number | null
    oil_type?: EnumMotorBikeOilTypesNullableListFilter<"MotorcycleModels">
    createdAt?: DateTimeFilter<"MotorcycleModels"> | Date | string
    updatedAt?: DateTimeFilter<"MotorcycleModels"> | Date | string
  }

  export type MotorcycleBrandsCreateWithoutMotorcycleModelsInput = {
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MotorcycleBrandsUncheckedCreateWithoutMotorcycleModelsInput = {
    id?: number
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MotorcycleBrandsCreateOrConnectWithoutMotorcycleModelsInput = {
    where: MotorcycleBrandsWhereUniqueInput
    create: XOR<MotorcycleBrandsCreateWithoutMotorcycleModelsInput, MotorcycleBrandsUncheckedCreateWithoutMotorcycleModelsInput>
  }

  export type MotorcycleBrandsUpsertWithoutMotorcycleModelsInput = {
    update: XOR<MotorcycleBrandsUpdateWithoutMotorcycleModelsInput, MotorcycleBrandsUncheckedUpdateWithoutMotorcycleModelsInput>
    create: XOR<MotorcycleBrandsCreateWithoutMotorcycleModelsInput, MotorcycleBrandsUncheckedCreateWithoutMotorcycleModelsInput>
    where?: MotorcycleBrandsWhereInput
  }

  export type MotorcycleBrandsUpdateToOneWithWhereWithoutMotorcycleModelsInput = {
    where?: MotorcycleBrandsWhereInput
    data: XOR<MotorcycleBrandsUpdateWithoutMotorcycleModelsInput, MotorcycleBrandsUncheckedUpdateWithoutMotorcycleModelsInput>
  }

  export type MotorcycleBrandsUpdateWithoutMotorcycleModelsInput = {
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MotorcycleBrandsUncheckedUpdateWithoutMotorcycleModelsInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AirModelsCreateWithoutBrandInput = {
    name: string
    description?: string | null
    oil_type?: $Enums.AirOilTypes | null
    oil_carbon_per_unit?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AirModelsUncheckedCreateWithoutBrandInput = {
    id?: number
    name: string
    description?: string | null
    oil_type?: $Enums.AirOilTypes | null
    oil_carbon_per_unit?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AirModelsCreateOrConnectWithoutBrandInput = {
    where: AirModelsWhereUniqueInput
    create: XOR<AirModelsCreateWithoutBrandInput, AirModelsUncheckedCreateWithoutBrandInput>
  }

  export type AirModelsCreateManyBrandInputEnvelope = {
    data: AirModelsCreateManyBrandInput | AirModelsCreateManyBrandInput[]
    skipDuplicates?: boolean
  }

  export type AirModelsUpsertWithWhereUniqueWithoutBrandInput = {
    where: AirModelsWhereUniqueInput
    update: XOR<AirModelsUpdateWithoutBrandInput, AirModelsUncheckedUpdateWithoutBrandInput>
    create: XOR<AirModelsCreateWithoutBrandInput, AirModelsUncheckedCreateWithoutBrandInput>
  }

  export type AirModelsUpdateWithWhereUniqueWithoutBrandInput = {
    where: AirModelsWhereUniqueInput
    data: XOR<AirModelsUpdateWithoutBrandInput, AirModelsUncheckedUpdateWithoutBrandInput>
  }

  export type AirModelsUpdateManyWithWhereWithoutBrandInput = {
    where: AirModelsScalarWhereInput
    data: XOR<AirModelsUpdateManyMutationInput, AirModelsUncheckedUpdateManyWithoutBrandInput>
  }

  export type AirModelsScalarWhereInput = {
    AND?: AirModelsScalarWhereInput | AirModelsScalarWhereInput[]
    OR?: AirModelsScalarWhereInput[]
    NOT?: AirModelsScalarWhereInput | AirModelsScalarWhereInput[]
    id?: IntFilter<"AirModels"> | number
    brandId?: IntFilter<"AirModels"> | number
    name?: StringFilter<"AirModels"> | string
    description?: StringNullableFilter<"AirModels"> | string | null
    oil_type?: EnumAirOilTypesNullableFilter<"AirModels"> | $Enums.AirOilTypes | null
    oil_carbon_per_unit?: FloatNullableFilter<"AirModels"> | number | null
    createdAt?: DateTimeFilter<"AirModels"> | Date | string
    updatedAt?: DateTimeFilter<"AirModels"> | Date | string
  }

  export type AirBrandsCreateWithoutAirModelsInput = {
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AirBrandsUncheckedCreateWithoutAirModelsInput = {
    id?: number
    name: string
    country?: string | null
    description?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AirBrandsCreateOrConnectWithoutAirModelsInput = {
    where: AirBrandsWhereUniqueInput
    create: XOR<AirBrandsCreateWithoutAirModelsInput, AirBrandsUncheckedCreateWithoutAirModelsInput>
  }

  export type AirBrandsUpsertWithoutAirModelsInput = {
    update: XOR<AirBrandsUpdateWithoutAirModelsInput, AirBrandsUncheckedUpdateWithoutAirModelsInput>
    create: XOR<AirBrandsCreateWithoutAirModelsInput, AirBrandsUncheckedCreateWithoutAirModelsInput>
    where?: AirBrandsWhereInput
  }

  export type AirBrandsUpdateToOneWithWhereWithoutAirModelsInput = {
    where?: AirBrandsWhereInput
    data: XOR<AirBrandsUpdateWithoutAirModelsInput, AirBrandsUncheckedUpdateWithoutAirModelsInput>
  }

  export type AirBrandsUpdateWithoutAirModelsInput = {
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AirBrandsUncheckedUpdateWithoutAirModelsInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    country?: NullableStringFieldUpdateOperationsInput | string | null
    description?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HistoryCalculatorCreateManyCustomerInput = {
    id?: number
    calculation: string
    result: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type HistoryCalculatorUpdateWithoutCustomerInput = {
    calculation?: StringFieldUpdateOperationsInput | string
    result?: FloatFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HistoryCalculatorUncheckedUpdateWithoutCustomerInput = {
    id?: IntFieldUpdateOperationsInput | number
    calculation?: StringFieldUpdateOperationsInput | string
    result?: FloatFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type HistoryCalculatorUncheckedUpdateManyWithoutCustomerInput = {
    id?: IntFieldUpdateOperationsInput | number
    calculation?: StringFieldUpdateOperationsInput | string
    result?: FloatFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type OrganizationUpdateWithoutOrg_adminsInput = {
    org_name?: StringFieldUpdateOperationsInput | string
    org_email?: StringFieldUpdateOperationsInput | string
    org_phone?: NullableStringFieldUpdateOperationsInput | string | null
    org_address?: NullableStringFieldUpdateOperationsInput | string | null
    org_city?: NullableStringFieldUpdateOperationsInput | string | null
    org_state?: NullableStringFieldUpdateOperationsInput | string | null
    org_zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    org_province?: NullableStringFieldUpdateOperationsInput | string | null
    org_logo?: NullableStringFieldUpdateOperationsInput | string | null
    org_password?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    org_members?: CustomersUpdateManyWithoutOrg_memberOfNestedInput
  }

  export type OrganizationUncheckedUpdateWithoutOrg_adminsInput = {
    id?: IntFieldUpdateOperationsInput | number
    org_name?: StringFieldUpdateOperationsInput | string
    org_email?: StringFieldUpdateOperationsInput | string
    org_phone?: NullableStringFieldUpdateOperationsInput | string | null
    org_address?: NullableStringFieldUpdateOperationsInput | string | null
    org_city?: NullableStringFieldUpdateOperationsInput | string | null
    org_state?: NullableStringFieldUpdateOperationsInput | string | null
    org_zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    org_province?: NullableStringFieldUpdateOperationsInput | string | null
    org_logo?: NullableStringFieldUpdateOperationsInput | string | null
    org_password?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    org_members?: CustomersUncheckedUpdateManyWithoutOrg_memberOfNestedInput
  }

  export type OrganizationUncheckedUpdateManyWithoutOrg_adminsInput = {
    id?: IntFieldUpdateOperationsInput | number
    org_name?: StringFieldUpdateOperationsInput | string
    org_email?: StringFieldUpdateOperationsInput | string
    org_phone?: NullableStringFieldUpdateOperationsInput | string | null
    org_address?: NullableStringFieldUpdateOperationsInput | string | null
    org_city?: NullableStringFieldUpdateOperationsInput | string | null
    org_state?: NullableStringFieldUpdateOperationsInput | string | null
    org_zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    org_province?: NullableStringFieldUpdateOperationsInput | string | null
    org_logo?: NullableStringFieldUpdateOperationsInput | string | null
    org_password?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type OrganizationUpdateWithoutOrg_membersInput = {
    org_name?: StringFieldUpdateOperationsInput | string
    org_email?: StringFieldUpdateOperationsInput | string
    org_phone?: NullableStringFieldUpdateOperationsInput | string | null
    org_address?: NullableStringFieldUpdateOperationsInput | string | null
    org_city?: NullableStringFieldUpdateOperationsInput | string | null
    org_state?: NullableStringFieldUpdateOperationsInput | string | null
    org_zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    org_province?: NullableStringFieldUpdateOperationsInput | string | null
    org_logo?: NullableStringFieldUpdateOperationsInput | string | null
    org_password?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    org_admins?: CustomersUpdateManyWithoutOrg_adminOfNestedInput
  }

  export type OrganizationUncheckedUpdateWithoutOrg_membersInput = {
    id?: IntFieldUpdateOperationsInput | number
    org_name?: StringFieldUpdateOperationsInput | string
    org_email?: StringFieldUpdateOperationsInput | string
    org_phone?: NullableStringFieldUpdateOperationsInput | string | null
    org_address?: NullableStringFieldUpdateOperationsInput | string | null
    org_city?: NullableStringFieldUpdateOperationsInput | string | null
    org_state?: NullableStringFieldUpdateOperationsInput | string | null
    org_zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    org_province?: NullableStringFieldUpdateOperationsInput | string | null
    org_logo?: NullableStringFieldUpdateOperationsInput | string | null
    org_password?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    org_admins?: CustomersUncheckedUpdateManyWithoutOrg_adminOfNestedInput
  }

  export type OrganizationUncheckedUpdateManyWithoutOrg_membersInput = {
    id?: IntFieldUpdateOperationsInput | number
    org_name?: StringFieldUpdateOperationsInput | string
    org_email?: StringFieldUpdateOperationsInput | string
    org_phone?: NullableStringFieldUpdateOperationsInput | string | null
    org_address?: NullableStringFieldUpdateOperationsInput | string | null
    org_city?: NullableStringFieldUpdateOperationsInput | string | null
    org_state?: NullableStringFieldUpdateOperationsInput | string | null
    org_zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    org_province?: NullableStringFieldUpdateOperationsInput | string | null
    org_logo?: NullableStringFieldUpdateOperationsInput | string | null
    org_password?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CustomersUpdateWithoutOrg_adminOfInput = {
    username?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    province?: NullableStringFieldUpdateOperationsInput | string | null
    isActive?: BoolFieldUpdateOperationsInput | boolean
    isVerified?: BoolFieldUpdateOperationsInput | boolean
    lastLogin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    profilePicture?: NullableStringFieldUpdateOperationsInput | string | null
    organizationId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    HistoryCalculator?: HistoryCalculatorUpdateManyWithoutCustomerNestedInput
    org_memberOf?: OrganizationUpdateManyWithoutOrg_membersNestedInput
  }

  export type CustomersUncheckedUpdateWithoutOrg_adminOfInput = {
    id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    province?: NullableStringFieldUpdateOperationsInput | string | null
    isActive?: BoolFieldUpdateOperationsInput | boolean
    isVerified?: BoolFieldUpdateOperationsInput | boolean
    lastLogin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    profilePicture?: NullableStringFieldUpdateOperationsInput | string | null
    organizationId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    HistoryCalculator?: HistoryCalculatorUncheckedUpdateManyWithoutCustomerNestedInput
    org_memberOf?: OrganizationUncheckedUpdateManyWithoutOrg_membersNestedInput
  }

  export type CustomersUncheckedUpdateManyWithoutOrg_adminOfInput = {
    id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    province?: NullableStringFieldUpdateOperationsInput | string | null
    isActive?: BoolFieldUpdateOperationsInput | boolean
    isVerified?: BoolFieldUpdateOperationsInput | boolean
    lastLogin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    profilePicture?: NullableStringFieldUpdateOperationsInput | string | null
    organizationId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CustomersUpdateWithoutOrg_memberOfInput = {
    username?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    province?: NullableStringFieldUpdateOperationsInput | string | null
    isActive?: BoolFieldUpdateOperationsInput | boolean
    isVerified?: BoolFieldUpdateOperationsInput | boolean
    lastLogin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    profilePicture?: NullableStringFieldUpdateOperationsInput | string | null
    organizationId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    HistoryCalculator?: HistoryCalculatorUpdateManyWithoutCustomerNestedInput
    org_adminOf?: OrganizationUpdateManyWithoutOrg_adminsNestedInput
  }

  export type CustomersUncheckedUpdateWithoutOrg_memberOfInput = {
    id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    province?: NullableStringFieldUpdateOperationsInput | string | null
    isActive?: BoolFieldUpdateOperationsInput | boolean
    isVerified?: BoolFieldUpdateOperationsInput | boolean
    lastLogin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    profilePicture?: NullableStringFieldUpdateOperationsInput | string | null
    organizationId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    HistoryCalculator?: HistoryCalculatorUncheckedUpdateManyWithoutCustomerNestedInput
    org_adminOf?: OrganizationUncheckedUpdateManyWithoutOrg_adminsNestedInput
  }

  export type CustomersUncheckedUpdateManyWithoutOrg_memberOfInput = {
    id?: IntFieldUpdateOperationsInput | number
    username?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    password?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zipCode?: NullableStringFieldUpdateOperationsInput | string | null
    province?: NullableStringFieldUpdateOperationsInput | string | null
    isActive?: BoolFieldUpdateOperationsInput | boolean
    isVerified?: BoolFieldUpdateOperationsInput | boolean
    lastLogin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    profilePicture?: NullableStringFieldUpdateOperationsInput | string | null
    organizationId?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CarModelsCreateManyBrandInput = {
    id?: number
    name: string
    description?: string | null
    power_type?: string | null
    oil_type?: CarModelsCreateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: number | null
    electric_carbon_per_unit?: number | null
    cubic_centimeter?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CarModelsUpdateWithoutBrandInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: CarModelsUpdateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CarModelsUncheckedUpdateWithoutBrandInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: CarModelsUpdateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CarModelsUncheckedUpdateManyWithoutBrandInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: CarModelsUpdateoil_typeInput | $Enums.CarOilTypes[]
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MotorcycleModelsCreateManyBrandInput = {
    id?: number
    name: string
    description?: string | null
    cubic_centimeter?: number | null
    power_type?: string | null
    electric_carbon_per_unit?: number | null
    oil_carbon_per_unit?: number | null
    oil_type?: MotorcycleModelsCreateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MotorcycleModelsUpdateWithoutBrandInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_type?: MotorcycleModelsUpdateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MotorcycleModelsUncheckedUpdateWithoutBrandInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_type?: MotorcycleModelsUpdateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MotorcycleModelsUncheckedUpdateManyWithoutBrandInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    cubic_centimeter?: NullableIntFieldUpdateOperationsInput | number | null
    power_type?: NullableStringFieldUpdateOperationsInput | string | null
    electric_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    oil_type?: MotorcycleModelsUpdateoil_typeInput | $Enums.MotorBikeOilTypes[]
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AirModelsCreateManyBrandInput = {
    id?: number
    name: string
    description?: string | null
    oil_type?: $Enums.AirOilTypes | null
    oil_carbon_per_unit?: number | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AirModelsUpdateWithoutBrandInput = {
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: NullableEnumAirOilTypesFieldUpdateOperationsInput | $Enums.AirOilTypes | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AirModelsUncheckedUpdateWithoutBrandInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: NullableEnumAirOilTypesFieldUpdateOperationsInput | $Enums.AirOilTypes | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AirModelsUncheckedUpdateManyWithoutBrandInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    description?: NullableStringFieldUpdateOperationsInput | string | null
    oil_type?: NullableEnumAirOilTypesFieldUpdateOperationsInput | $Enums.AirOilTypes | null
    oil_carbon_per_unit?: NullableFloatFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}